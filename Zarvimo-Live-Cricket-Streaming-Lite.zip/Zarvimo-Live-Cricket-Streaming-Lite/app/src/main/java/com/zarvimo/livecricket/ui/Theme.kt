package com.zarvimo.livecricket.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Blue = Color(0xFF3B82F6)

private val DarkColors = darkColorScheme(
    primary = Blue,
    background = Color(0xFF0B1220),
    surface = Color(0xFF121A2B),
    surfaceVariant = Color(0xFF1A2438),
    onBackground = Color.White,
    onSurface = Color.White,
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1D4ED8),
    background = Color(0xFFF4F6FB),
    surface = Color.White,
)

@Composable
fun ZarvimoTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, content = content)
}
