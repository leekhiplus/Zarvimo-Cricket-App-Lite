package com.zarvimo.livecricket.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.livecricket.AppViewModel

@Composable
fun TemplatesScreen(vm: AppViewModel, onBack: () -> Unit) {
    val data = vm.boardData()
    ScreenScaffold("Scoreboard Templates", onBack, scroll = false) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            itemsIndexed(Templates) { i, style ->
                val selected = vm.templateIndex == i
                val shape = RoundedCornerShape(12.dp)
                Column(
                    Modifier.clip(shape).clickable { vm.selectTemplate(i) }
                        .border(if (selected) 3.dp else 1.dp, if (selected) Palette.Blue else Color(0x443B82F6), shape),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(Modifier.fillMaxWidth().stadiumBackground()) {
                        Scoreboard(data, style, portrait = false, modifier = Modifier.fillMaxWidth())
                    }
                    Text(
                        "${i + 1}. ${style.name}" + if (selected) "  \u2713" else "",
                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(6.dp),
                    )
                }
            }
        }
    }
}
