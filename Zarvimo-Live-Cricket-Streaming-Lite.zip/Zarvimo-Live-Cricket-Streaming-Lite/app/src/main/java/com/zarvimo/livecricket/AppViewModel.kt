package com.zarvimo.livecricket

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.zarvimo.livecricket.data.SQUAD_SIZE
import com.zarvimo.livecricket.data.SavedMatch
import com.zarvimo.livecricket.data.ScoreboardData
import com.zarvimo.livecricket.data.SetupDraft
import com.zarvimo.livecricket.data.Store
import com.zarvimo.livecricket.data.TeamInfo
import com.zarvimo.livecricket.engine.Action
import com.zarvimo.livecricket.engine.CricketMatch
import com.zarvimo.livecricket.engine.Delivery
import com.zarvimo.livecricket.engine.Side
import java.io.File
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var draft by mutableStateOf(SetupDraft())
    var meta by mutableStateOf<SavedMatch?>(null)
        private set
    var match by mutableStateOf<CricketMatch?>(null)
        private set
    var message by mutableStateOf<String?>(null)
    var paused by mutableStateOf(false)
    var history by mutableStateOf<List<SavedMatch>>(emptyList())
        private set
    var templateIndex by mutableStateOf(store.templateIndex)
        private set
    var themeMode by mutableStateOf(store.themeMode)
        private set
    var savedTeams by mutableStateOf(store.savedTeams())
        private set

    // Broadcast options (wired to real audio/video in later stages).
    var showLogo by mutableStateOf(true)
    var musicOn by mutableStateOf(true)
    var commentaryOn by mutableStateOf(true)

    // Streaming settings. The stream key is kept in memory only until secure (Keystore) storage is added.
    var rtmpUrl by mutableStateOf(store.rtmpUrl)
        private set
    var resolution by mutableStateOf(store.resolution)
        private set
    var streamKey by mutableStateOf("")

    fun updateRtmpUrl(v: String) { rtmpUrl = v; store.rtmpUrl = v }
    fun updateResolution(v: String) { resolution = v; store.resolution = v }

    init {
        store.lastMatchId?.let { id -> store.load(id)?.let { runCatching { open(it) } } }
    }

    // ---- setup -----------------------------------------------------------------------------

    fun updateTeam(side: Side, f: (TeamInfo) -> TeamInfo) {
        draft = if (side == Side.A) draft.copy(teamA = f(draft.teamA)) else draft.copy(teamB = f(draft.teamB))
    }

    fun importLogo(uri: Uri, side: Side) {
        val ctx = getApplication<Application>()
        runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: error("unreadable")
            val dir = File(ctx.filesDir, "logos").apply { mkdirs() }
            val file = File(dir, "team_${UUID.randomUUID()}.png")
            file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            updateTeam(side) { it.copy(logoPath = file.absolutePath) }
        }.onFailure { message = "Could not load that image." }
    }

    fun startMatch(): Boolean {
        val d = draft
        val cfg = d.config()
        if (cfg == null) { message = "Enter a valid number of overs (1-100)."; return false }
        if (d.teamA.name.isBlank() || d.teamB.name.isBlank()) { message = "Enter both team names."; return false }
        val title = d.title.ifBlank { "${d.teamA.name} vs ${d.teamB.name}" }
        val base = SavedMatch(
            id = UUID.randomUUID().toString(), title = title, venue = d.venue, date = d.date,
            format = d.format, overs = if (d.oversEditable) d.overs.toIntOrNull() else null,
            teamA = d.teamA, teamB = d.teamB, battingFirst = d.battingFirst,
            innings = emptyList(), manualResult = null, updatedAt = System.currentTimeMillis(),
        )
        return runCatching {
            val m = base.toMatch().startNextInnings()
            meta = base
            paused = false
            commit(m)
        }.onFailure { message = it.message }.isSuccess
    }

    // ---- scoring ---------------------------------------------------------------------------

    private fun commit(m: CricketMatch) {
        val base = meta ?: return
        val saved = base.copy(
            innings = m.innings.map { it.actions },
            manualResult = m.manualResult,
            updatedAt = System.currentTimeMillis(),
        )
        meta = saved
        match = m
        store.save(saved)
        store.lastMatchId = saved.id
    }

    private fun mutate(block: (CricketMatch) -> CricketMatch) {
        val m = match ?: return
        try {
            commit(block(m))
        } catch (e: IllegalArgumentException) {
            message = e.message ?: "Invalid action"
        } catch (e: IllegalStateException) {
            message = e.message ?: "Invalid action"
        }
    }

    fun perform(a: Action) {
        if (paused) { message = "Match is paused. Resume to continue scoring."; return }
        mutate { m -> m.updateCurrent((m.current ?: error("No innings")).perform(a)) }
    }

    fun undo() = mutate { m -> m.updateCurrent((m.current ?: error("No innings")).undoLastBall()) }

    fun editBall(index: Int, d: Delivery) =
        mutate { m -> m.updateCurrent((m.current ?: error("No innings")).editBall(index, d)) }

    fun nextInnings() = mutate { it.startNextInnings() }

    fun declareDraw() = mutate { it.withManualResult("Match drawn") }

    fun boardData(): ScoreboardData {
        val m = match
        val md = meta
        return if (m != null && md != null && m.innings.isNotEmpty()) ScoreboardData.from(md, m) else ScoreboardData.sample()
    }

    // ---- history, teams, settings ----------------------------------------------------------

    fun open(saved: SavedMatch) {
        val m = saved.toMatch()
        meta = saved
        match = m
        paused = false
        store.lastMatchId = saved.id
    }

    fun refreshHistory() { history = store.list() }

    fun deleteMatch(id: String) {
        store.delete(id)
        if (meta?.id == id) { meta = null; match = null }
        refreshHistory()
    }

    fun saveTeam(t: TeamInfo) {
        if (t.name.isBlank()) { message = "Enter a team name before saving."; return }
        savedTeams = (savedTeams.filterNot { it.name.equals(t.name, ignoreCase = true) } + t).sortedBy { it.name }
        store.writeSavedTeams(savedTeams)
    }

    fun deleteSavedTeam(name: String) {
        savedTeams = savedTeams.filterNot { it.name == name }
        store.writeSavedTeams(savedTeams)
    }

    fun selectTemplate(i: Int) { templateIndex = i; store.templateIndex = i }

    fun setTheme(mode: String) { themeMode = mode; store.themeMode = mode }

    companion object { const val MAX_PLAYERS = SQUAD_SIZE }
}
