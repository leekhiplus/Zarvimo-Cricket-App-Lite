package com.zarvimo.livecricket.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zarvimo.livecricket.engine.MatchConfig
import com.zarvimo.livecricket.engine.MatchFormat

private fun defaultOvers(f: MatchFormat): String = when (f) {
    MatchFormat.T10 -> "10"
    MatchFormat.T20 -> "20"
    MatchFormat.ODI -> "50"
    MatchFormat.CUSTOM -> "20"
    else -> ""
}

@Composable
fun MatchSetupScreen(onBack: () -> Unit) {
    var teamA by rememberSaveable { mutableStateOf("") }
    var teamB by rememberSaveable { mutableStateOf("") }
    var title by rememberSaveable { mutableStateOf("") }
    var venue by rememberSaveable { mutableStateOf("") }
    var format by rememberSaveable { mutableStateOf(MatchFormat.T20) }
    var oversText by rememberSaveable { mutableStateOf("20") }

    val oversEditable = format != MatchFormat.TEST && format != MatchFormat.THE_HUNDRED
    val config = runCatching {
        MatchConfig.forFormat(format, if (oversEditable) oversText.toIntOrNull() else null)
    }.getOrNull()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Create New Match", style = MaterialTheme.typography.headlineSmall)

        OutlinedTextField(teamA, { teamA = it }, label = { Text("Team A name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(teamB, { teamB = it }, label = { Text("Team B name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(title, { title = it }, label = { Text("Match title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(venue, { venue = it }, label = { Text("Venue (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        Text("Match format", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MatchFormat.values().forEach { f ->
                FilterChip(
                    selected = format == f,
                    onClick = { format = f; oversText = defaultOvers(f) },
                    label = { Text(f.label) },
                )
            }
        }

        if (oversEditable) {
            OutlinedTextField(
                value = oversText,
                onValueChange = { oversText = it.filter(Char::isDigit).take(3) },
                label = { Text("Overs per innings") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        val summary = when {
            config == null -> "Enter overs between 1 and 100"
            config.ballsPerInnings == null -> "Test: no over limit, ${config.maxInnings} innings"
            else -> "Legal deliveries per innings: ${config.ballsPerInnings} " +
                "(${config.ballsPerOver} per over, ${config.maxInnings} innings)"
        }
        Text(summary, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)

        Text(
            "Flags, Playing XI and saving matches arrive in Stage 2.",
            style = MaterialTheme.typography.bodySmall,
        )

        Button(onClick = onBack, enabled = config != null && teamA.isNotBlank() && teamB.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text("Done")
        }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}
