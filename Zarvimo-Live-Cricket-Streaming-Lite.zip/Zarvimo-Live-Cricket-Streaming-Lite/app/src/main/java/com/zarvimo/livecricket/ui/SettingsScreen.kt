package com.zarvimo.livecricket.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zarvimo.livecricket.AppViewModel

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val version = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"
    ScreenScaffold("Settings", onBack) {
        Text("Theme", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("system" to "System", "dark" to "Dark", "light" to "Light").forEach { (k, label) ->
                FilterChip(selected = vm.themeMode == k, onClick = { vm.setTheme(k) }, label = { Text(label) })
            }
        }
        Text("Default scoreboard template", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Templates.forEachIndexed { i, t ->
                FilterChip(selected = vm.templateIndex == i, onClick = { vm.selectTemplate(i) }, label = { Text(t.name) })
            }
        }
        Text(
            "Orientation, resolution, audio, background, logo and backup settings arrive with the streaming stages.",
            style = MaterialTheme.typography.bodySmall,
        )
        Text("Zarvimo Live Cricket Streaming Lite", style = MaterialTheme.typography.titleSmall)
        Text("Version $version")
    }
}
