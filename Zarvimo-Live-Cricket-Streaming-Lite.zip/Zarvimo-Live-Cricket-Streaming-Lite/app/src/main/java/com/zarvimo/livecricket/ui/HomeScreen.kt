package com.zarvimo.livecricket.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private data class Tile(val title: String, val subtitle: String, val ready: Boolean = false)

private val tiles = listOf(
    Tile("Create New Match", "Teams, format and overs", ready = true),
    Tile("Live Scoring", "Ball-by-ball scoring"),
    Tile("Scoreboard Templates", "10 broadcast designs"),
    Tile("Background Settings", "Custom stream background"),
    Tile("Channel Logo Settings", "Your YouTube branding"),
    Tile("Audio Studio", "Music and commentary mix"),
    Tile("Live Preview", "Exact stream composition"),
    Tile("YouTube Streaming", "RTMP go-live"),
    Tile("Match History", "Saved and resumable matches"),
    Tile("Settings", "Theme and defaults"),
)

@Composable
fun HomeScreen(onCreateMatch: () -> Unit) {
    var notice by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(Modifier.padding(vertical = 8.dp)) {
                Text("Zarvimo", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                Text("Live Cricket Streaming Lite", style = MaterialTheme.typography.titleMedium)
            }
        }
        items(tiles) { tile ->
            Card(
                onClick = { if (tile.ready) onCreateMatch() else notice = tile.title },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(tile.title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (tile.ready) tile.subtitle else tile.subtitle + " (coming in a later stage)",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
    }

    notice?.let { title ->
        AlertDialog(
            onDismissRequest = { notice = null },
            confirmButton = { TextButton(onClick = { notice = null }) { Text("OK") } },
            title = { Text(title) },
            text = { Text("This screen is not built yet. Stage 1 covers the scoring engine and match setup.") },
        )
    }
}
