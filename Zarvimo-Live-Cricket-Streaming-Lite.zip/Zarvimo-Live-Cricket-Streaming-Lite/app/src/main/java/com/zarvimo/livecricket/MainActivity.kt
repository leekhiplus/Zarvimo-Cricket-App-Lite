package com.zarvimo.livecricket

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.zarvimo.livecricket.ui.AppBackground
import com.zarvimo.livecricket.ui.HistoryScreen
import com.zarvimo.livecricket.ui.HomeScreen
import com.zarvimo.livecricket.ui.PreviewScreen
import com.zarvimo.livecricket.ui.Screen
import com.zarvimo.livecricket.ui.ScoringScreen
import com.zarvimo.livecricket.ui.SettingsScreen
import com.zarvimo.livecricket.ui.SetupScreen
import com.zarvimo.livecricket.ui.SplashContent
import com.zarvimo.livecricket.ui.StreamScreen
import com.zarvimo.livecricket.ui.TemplatesScreen
import com.zarvimo.livecricket.ui.XiScreen
import com.zarvimo.livecricket.ui.ZarvimoTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = when (vm.themeMode) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }
            ZarvimoTheme(darkTheme = dark) {
                AppBackground { AppRoot(vm) }
            }
        }
    }
}

@Composable
private fun AppRoot(vm: AppViewModel) {
    var splashDone by rememberSaveable { mutableStateOf(false) }
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }

    if (!splashDone) {
        LaunchedEffect(Unit) { delay(1600); splashDone = true }
        SplashContent()
        return
    }

    val goHome = { screen = Screen.HOME }
    BackHandler(enabled = screen != Screen.HOME) {
        screen = if (screen == Screen.XI) Screen.SETUP else Screen.HOME
    }
    when (screen) {
        Screen.HOME -> HomeScreen(onNavigate = { screen = it })
        Screen.SETUP -> SetupScreen(vm, onBack = goHome, onNext = { screen = Screen.XI })
        Screen.XI -> XiScreen(vm, onBack = { screen = Screen.SETUP }, onStart = { screen = Screen.SCORING })
        Screen.SCORING -> ScoringScreen(vm, onBack = goHome)
        Screen.TEMPLATES -> TemplatesScreen(vm, onBack = goHome)
        Screen.PREVIEW -> PreviewScreen(vm, onBack = goHome)
        Screen.HISTORY -> HistoryScreen(vm, onBack = goHome, onOpen = { screen = Screen.SCORING })
        Screen.SETTINGS -> SettingsScreen(vm, onBack = goHome)
        Screen.STREAM -> StreamScreen(vm, onBack = goHome)
    }
    vm.message?.let { msg ->
        AlertDialog(
            onDismissRequest = { vm.message = null },
            confirmButton = { TextButton(onClick = { vm.message = null }) { Text("OK") } },
            text = { Text(msg) },
        )
    }
}
