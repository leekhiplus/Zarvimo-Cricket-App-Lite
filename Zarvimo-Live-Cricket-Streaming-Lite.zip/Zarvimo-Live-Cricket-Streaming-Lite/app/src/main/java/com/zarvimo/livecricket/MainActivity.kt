package com.zarvimo.livecricket

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.zarvimo.livecricket.ui.HomeScreen
import com.zarvimo.livecricket.ui.MatchSetupScreen
import com.zarvimo.livecricket.ui.ZarvimoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ZarvimoTheme {
                Surface(color = MaterialTheme.colorScheme.background) { AppRoot() }
            }
        }
    }
}

private enum class Screen { HOME, MATCH_SETUP }

@Composable
private fun AppRoot() {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }
    when (screen) {
        Screen.HOME -> HomeScreen(onCreateMatch = { screen = Screen.MATCH_SETUP })
        Screen.MATCH_SETUP -> MatchSetupScreen(onBack = { screen = Screen.HOME })
    }
}
