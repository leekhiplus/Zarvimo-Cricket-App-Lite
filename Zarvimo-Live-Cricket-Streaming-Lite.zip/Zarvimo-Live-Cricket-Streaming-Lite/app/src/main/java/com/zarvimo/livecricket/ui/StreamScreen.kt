package com.zarvimo.livecricket.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.livecricket.AppViewModel

/** Streaming settings UI. The RTMP/encoding engine itself is added in the streaming stage. */
@Composable
fun StreamScreen(vm: AppViewModel, onBack: () -> Unit) {
    var showKey by remember { mutableStateOf(false) }
    val notReady = "The live streaming engine (video + audio encoding and RTMP) is added in the next stage."

    ScreenScaffold("YouTube Streaming", onBack) {
        Text("RTMP URL", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = vm.rtmpUrl, onValueChange = { vm.updateRtmpUrl(it) }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Stream Key", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = vm.streamKey, onValueChange = { vm.streamKey = it }, singleLine = true,
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") } },
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Resolution", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("480p", "720p", "1080p").forEach { r ->
                FilterChip(selected = vm.resolution == r, onClick = { vm.updateResolution(r) }, label = { Text(r) })
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("\u25CF", color = Color(0xFF9AA5BD), fontSize = 16.sp)
                Spacer(Modifier.width(8.dp))
                Text("Not connected", fontWeight = FontWeight.Bold)
            }
        }
        PrimaryButton("Connect", Palette.Blue) { vm.message = notReady }
        PrimaryButton("Start Live", Palette.Red) { vm.message = notReady }
        PrimaryButton("Stop", Color(0xFF1B2A55), enabled = false) {}
        Text("Live Time: 00:00:00", modifier = Modifier.fillMaxWidth(), fontSize = 13.sp)
        Text(
            "Your stream key is kept in memory only for now. Secure encrypted storage arrives with the streaming engine.",
            fontSize = 12.sp,
        )
    }
}
