package com.zarvimo.livecricket.data

import android.content.Context
import org.json.JSONArray
import java.io.File

/** Local-only persistence: one JSON file per match plus a few preferences. No network, no cloud. */
class Store(ctx: Context) {
    private val dir = File(ctx.filesDir, "matches").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("zarvimo", Context.MODE_PRIVATE)

    fun save(m: SavedMatch) {
        val tmp = File(dir, "${m.id}.json.tmp")
        tmp.writeText(MatchJson.toJson(m))
        tmp.copyTo(File(dir, "${m.id}.json"), overwrite = true)
        tmp.delete()
    }

    fun load(id: String): SavedMatch? {
        val f = File(dir, "$id.json")
        return if (f.exists()) runCatching { MatchJson.fromJson(f.readText()) }.getOrNull() else null
    }

    fun list(): List<SavedMatch> =
        (dir.listFiles { f -> f.name.endsWith(".json") } ?: emptyArray())
            .mapNotNull { f -> runCatching { MatchJson.fromJson(f.readText()) }.getOrNull() }
            .sortedByDescending { it.updatedAt }

    fun delete(id: String) {
        File(dir, "$id.json").delete()
        if (lastMatchId == id) lastMatchId = null
    }

    var themeMode: String
        get() = prefs.getString("theme", "system") ?: "system"
        set(v) = prefs.edit().putString("theme", v).apply()

    var templateIndex: Int
        get() = prefs.getInt("template", 0)
        set(v) = prefs.edit().putInt("template", v).apply()

    var rtmpUrl: String
        get() = prefs.getString("rtmpUrl", "rtmp://a.rtmp.youtube.com/live2") ?: "rtmp://a.rtmp.youtube.com/live2"
        set(v) = prefs.edit().putString("rtmpUrl", v).apply()

    var resolution: String
        get() = prefs.getString("resolution", "720p") ?: "720p"
        set(v) = prefs.edit().putString("resolution", v).apply()

    var lastMatchId: String?
        get() = prefs.getString("lastMatch", null)
        set(v) = prefs.edit().putString("lastMatch", v).apply()

    fun savedTeams(): List<TeamInfo> {
        val text = prefs.getString("savedTeams", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(text)
            List(arr.length()) { MatchJson.teamFromJson(arr.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    fun writeSavedTeams(teams: List<TeamInfo>) {
        val arr = JSONArray()
        teams.forEach { arr.put(MatchJson.teamToJson(it)) }
        prefs.edit().putString("savedTeams", arr.toString()).apply()
    }
}
