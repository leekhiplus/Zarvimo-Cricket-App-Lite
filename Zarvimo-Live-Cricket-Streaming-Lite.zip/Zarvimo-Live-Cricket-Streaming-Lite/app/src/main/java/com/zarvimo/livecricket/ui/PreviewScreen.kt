package com.zarvimo.livecricket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.livecricket.AppViewModel

@Composable
private fun Stage(vm: AppViewModel, portrait: Boolean, modifier: Modifier) {
    val data = vm.boardData()
    val style = Templates[vm.templateIndex.coerceIn(0, Templates.lastIndex)]
    Box(modifier.stadiumBackground()) {
        Scoreboard(data, style, portrait, Modifier.fillMaxSize())
        if (vm.showLogo) {
            Column(Modifier.align(Alignment.TopEnd).padding(10.dp), horizontalAlignment = Alignment.End) {
                Text("ZARVIMO", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("\u25B6", color = Palette.Red, fontSize = 12.sp)
                    Spacer(Modifier.width(4.dp))
                    Text("LIVE", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun PreviewScreen(vm: AppViewModel, onBack: () -> Unit) {
    var portrait by rememberSaveable { mutableStateOf(false) }
    var full by rememberSaveable { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val style = Templates[vm.templateIndex.coerceIn(0, Templates.lastIndex)]

    if (full) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable { full = false }, contentAlignment = Alignment.Center) {
            Stage(
                vm, portrait,
                Modifier.then(if (portrait) Modifier.fillMaxHeight() else Modifier.fillMaxWidth())
                    .aspectRatio(if (portrait) 9f / 16f else 16f / 9f),
            )
        }
        return
    }

    ScreenScaffold(
        "Live Preview", onBack,
        actions = { Text("\u26F6", fontSize = 24.sp, modifier = Modifier.clickable { full = true }.padding(8.dp)) },
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !portrait, onClick = { portrait = false }, label = { Text("Landscape 16:9") })
            FilterChip(selected = portrait, onClick = { portrait = true }, label = { Text("Portrait 9:16") })
        }
        Stage(
            vm, portrait,
            Modifier.then(if (portrait) Modifier.height(460.dp) else Modifier.fillMaxWidth())
                .aspectRatio(if (portrait) 9f / 16f else 16f / 9f)
                .clip(RoundedCornerShape(16.dp)),
        )

        GlassCard(Modifier.fillMaxWidth()) {
            Box {
                OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Template: ${style.name}  \u25BE")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    Templates.forEachIndexed { i, t ->
                        DropdownMenuItem(text = { Text("${i + 1}. ${t.name}") }, onClick = { vm.selectTemplate(i); menu = false })
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Logo", Modifier.weight(1f), fontSize = 16.sp)
                Switch(checked = vm.showLogo, onCheckedChange = { vm.showLogo = it })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Music", Modifier.weight(1f), fontSize = 16.sp)
                Switch(checked = vm.musicOn, onCheckedChange = { vm.musicOn = it })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Commentary", Modifier.weight(1f), fontSize = 16.sp)
                Switch(checked = vm.commentaryOn, onCheckedChange = { vm.commentaryOn = it })
            }
        }
        PrimaryButton("Switch Template", Palette.Blue) { vm.selectTemplate((vm.templateIndex + 1) % Templates.size) }
        Text(
            "Music and commentary switches take effect when the audio and streaming stages are added.",
            fontSize = 12.sp,
        )
    }
}
