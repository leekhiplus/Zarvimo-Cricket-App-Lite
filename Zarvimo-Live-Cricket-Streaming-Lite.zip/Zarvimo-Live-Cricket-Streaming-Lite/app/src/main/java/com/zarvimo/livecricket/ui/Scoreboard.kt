package com.zarvimo.livecricket.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.livecricket.data.ScoreboardData

enum class BoardLayout { BAR, CARD }

data class TemplateStyle(
    val name: String,
    val panel: Color,
    val panelAlt: Color,
    val accent: Color,
    val text: Color,
    val sub: Color,
    val layout: BoardLayout,
)

/** The 10 scoreboard templates. All render from the same [ScoreboardData]. */
val Templates = listOf(
    TemplateStyle("Blue Classic", Color(0xFF0D2B5E), Color(0xFF14418F), Color(0xFF4DA3FF), Color.White, Color(0xFFB8C7E0), BoardLayout.BAR),
    TemplateStyle("Neon Dark", Color(0xFF0A0A12), Color(0xFF14142B), Color(0xFF00F0FF), Color.White, Color(0xFF8E9BB5), BoardLayout.CARD),
    TemplateStyle("Green Pro", Color(0xFF0B3D2E), Color(0xFF14634A), Color(0xFF3DDC84), Color.White, Color(0xFFB7DCCB), BoardLayout.BAR),
    TemplateStyle("Red Sports", Color(0xFF5A0F14), Color(0xFF8E1B22), Color(0xFFFF4D4D), Color.White, Color(0xFFF0C4C6), BoardLayout.BAR),
    TemplateStyle("White Minimal", Color(0xFFFFFFFF), Color(0xFFEDEFF3), Color(0xFF1D4ED8), Color(0xFF111827), Color(0xFF6B7280), BoardLayout.CARD),
    TemplateStyle("Purple Night", Color(0xFF1E0F3D), Color(0xFF35206B), Color(0xFFB388FF), Color.White, Color(0xFFCDBBEA), BoardLayout.CARD),
    TemplateStyle("Orange Pro", Color(0xFF3A1A00), Color(0xFF7A3A00), Color(0xFFFF9800), Color.White, Color(0xFFF2D2A8), BoardLayout.BAR),
    TemplateStyle("Silver Elite", Color(0xFF2B2F36), Color(0xFF454B55), Color(0xFFC9D1DC), Color.White, Color(0xFFAAB2BF), BoardLayout.CARD),
    TemplateStyle("TV Broadcast", Color(0xFF101820), Color(0xFF1B2733), Color(0xFFFFC107), Color.White, Color(0xFF9FB0C0), BoardLayout.BAR),
    TemplateStyle("Mobile Vertical", Color(0xFF0B1220), Color(0xFF1A2438), Color(0xFF3B82F6), Color.White, Color(0xFF9DB0CF), BoardLayout.CARD),
)

/** Layout unit: the board is a 160 x 90 grid in landscape and 90 x 160 in portrait. */
private class Sc(val u: Float) {
    fun dp(x: Float) = (x * u).dp
    fun sp(x: Float) = (x * u).sp
}

@Composable
fun Scoreboard(data: ScoreboardData, style: TemplateStyle, portrait: Boolean, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier.aspectRatio(if (portrait) 9f / 16f else 16f / 9f)) {
        val sc = Sc(maxWidth.value / (if (portrait) 90f else 160f))
        when {
            portrait -> StackBoard(data, style, sc)
            style.layout == BoardLayout.BAR -> BarBoard(data, style, sc)
            else -> CardBoard(data, style, sc)
        }
    }
}

@Composable
private fun T(
    text: String,
    size: TextUnit,
    color: Color,
    modifier: Modifier = Modifier,
    bold: Boolean = false,
    align: TextAlign? = null,
) {
    Text(
        text, modifier = modifier, color = color, fontSize = size,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1, overflow = TextOverflow.Ellipsis, softWrap = false, textAlign = align,
    )
}

private fun onAccent(s: TemplateStyle): Color = if (s.accent.luminance() > 0.5f) Color.Black else Color.White

@Composable
private fun Score(runs: Int, wickets: Int, s: TemplateStyle, sc: Sc, size: Float) {
    Row(verticalAlignment = Alignment.Bottom) {
        AnimatedContent(
            targetState = runs,
            transitionSpec = { (slideInVertically { it } + fadeIn()) togetherWith (slideOutVertically { -it } + fadeOut()) },
            label = "runs",
        ) { r -> T(r.toString(), sc.sp(size), s.text, bold = true) }
        T("/$wickets", sc.sp(size * 0.6f), s.sub)
    }
}

private fun ballColor(label: String): Color = when {
    label.endsWith("W") -> Color(0xFFE53935)
    label == "4" -> Color(0xFF1E88E5)
    label == "6" -> Color(0xFF2E7D32)
    label.startsWith("Wd") || label.startsWith("Nb") -> Color(0xFFF57C00)
    else -> Color(0xFF546E7A)
}

@Composable
private fun Balls(labels: List<String>, sc: Sc) {
    Row(horizontalArrangement = Arrangement.spacedBy(sc.dp(1f))) {
        labels.forEach { l ->
            Box(
                Modifier
                    .defaultMinSize(minWidth = sc.dp(5f), minHeight = sc.dp(5f))
                    .clip(RoundedCornerShape(sc.dp(2.5f)))
                    .background(ballColor(l))
                    .padding(horizontal = sc.dp(0.8f)),
                contentAlignment = Alignment.Center,
            ) { T(l, sc.sp(2.4f), Color.White, bold = true) }
        }
    }
}

@Composable
private fun PlayerLine(name: String, stat: String, s: TemplateStyle, sc: Sc, size: Float, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        T(name, sc.sp(size), s.text, Modifier.weight(1f), bold = bold)
        Spacer(Modifier.width(sc.dp(1.5f)))
        T(stat, sc.sp(size), s.text, bold = bold)
    }
}

@Composable
private fun Rule(s: TemplateStyle, sc: Sc) {
    Box(Modifier.fillMaxWidth().height(sc.dp(0.3f)).background(s.sub.copy(alpha = 0.3f)))
}

@Composable
private fun BarBoard(d: ScoreboardData, s: TemplateStyle, sc: Sc) {
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = sc.dp(4f), vertical = sc.dp(4f)),
        ) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(topStart = sc.dp(2f), topEnd = sc.dp(2f)))
                    .background(s.accent)
                    .padding(horizontal = sc.dp(2.5f), vertical = sc.dp(0.8f)),
            ) { T(d.title.uppercase() + "  \u2022  " + d.inningsLabel, sc.sp(3f), onAccent(s), bold = true) }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topEnd = sc.dp(2f), bottomStart = sc.dp(2f), bottomEnd = sc.dp(2f)))
                    .background(s.panel.copy(alpha = 0.95f))
                    .padding(sc.dp(2.5f)),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(Modifier.weight(1.3f), verticalAlignment = Alignment.CenterVertically) {
                    TeamBadge(d.battingCode, d.battingLogo, sc.dp(9f), fallback = d.battingName)
                    Spacer(Modifier.width(sc.dp(2f)))
                    Column {
                        T(d.battingName, sc.sp(5f), s.text, bold = true)
                        T("vs ${d.bowlingName}", sc.sp(2.8f), s.sub)
                    }
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Score(d.runs, d.wickets, s, sc, 11f)
                    T("(${d.overs} ov)", sc.sp(3.4f), s.sub)
                }
                Column(Modifier.weight(1.5f)) {
                    PlayerLine(d.striker, d.strikerStat, s, sc, 3.4f, bold = true)
                    PlayerLine(d.nonStriker, d.nonStrikerStat, s, sc, 3.4f)
                    PlayerLine(d.bowler, d.bowlerStat, s, sc, 3.4f)
                }
                Spacer(Modifier.width(sc.dp(2f)))
                Column(Modifier.weight(1.1f), horizontalAlignment = Alignment.End) {
                    T("CRR ${d.crr}", sc.sp(3.4f), s.text, bold = true)
                    d.rrr?.let { T("RRR $it", sc.sp(3.4f), s.accent, bold = true) }
                    d.needText?.let { T(it, sc.sp(3f), s.sub) }
                    Spacer(Modifier.height(sc.dp(1f)))
                    Balls(d.lastSix, sc)
                }
            }
        }
    }
}

@Composable
private fun CardBoard(d: ScoreboardData, s: TemplateStyle, sc: Sc) {
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.align(Alignment.TopStart).padding(sc.dp(4f)).width(sc.dp(62f))) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(topStart = sc.dp(2f), topEnd = sc.dp(2f)))
                    .background(s.accent)
                    .padding(horizontal = sc.dp(2.5f), vertical = sc.dp(0.8f)),
            ) { T(d.title.uppercase() + "  \u2022  " + d.inningsLabel, sc.sp(2.8f), onAccent(s), bold = true) }
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = sc.dp(2f), bottomEnd = sc.dp(2f)))
                    .background(s.panel.copy(alpha = 0.95f))
                    .padding(sc.dp(2.5f)),
                verticalArrangement = Arrangement.spacedBy(sc.dp(1f)),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TeamBadge(d.battingCode, d.battingLogo, sc.dp(7f), fallback = d.battingName)
                    Spacer(Modifier.width(sc.dp(2f)))
                    T(d.battingName, sc.sp(4.6f), s.text, Modifier.weight(1f), bold = true)
                    Score(d.runs, d.wickets, s, sc, 8.5f)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    T("Overs ${d.overs}", sc.sp(3f), s.sub)
                    T("CRR ${d.crr}", sc.sp(3f), s.sub)
                    d.rrr?.let { T("RRR $it", sc.sp(3f), s.accent, bold = true) }
                }
                d.needText?.let { T(it, sc.sp(3.2f), s.accent, bold = true) }
                Rule(s, sc)
                PlayerLine(d.striker, d.strikerStat, s, sc, 3.2f, bold = true)
                PlayerLine(d.nonStriker, d.nonStrikerStat, s, sc, 3.2f)
                PlayerLine(d.bowler, d.bowlerStat, s, sc, 3.2f)
                Rule(s, sc)
                Balls(d.lastSix, sc)
            }
        }
    }
}

@Composable
private fun StackBoard(d: ScoreboardData, s: TemplateStyle, sc: Sc) {
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(sc.dp(5f))) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = sc.dp(3f), topEnd = sc.dp(3f)))
                    .background(s.accent)
                    .padding(horizontal = sc.dp(3f), vertical = sc.dp(1.2f)),
                horizontalArrangement = Arrangement.Center,
            ) { T(d.title.uppercase() + "  \u2022  " + d.inningsLabel, sc.sp(3.6f), onAccent(s), bold = true) }
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = sc.dp(3f), bottomEnd = sc.dp(3f)))
                    .background(s.panel.copy(alpha = 0.95f))
                    .padding(sc.dp(4f)),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(sc.dp(1.5f)),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TeamBadge(d.battingCode, d.battingLogo, sc.dp(11f), fallback = d.battingName)
                    Spacer(Modifier.width(sc.dp(3f)))
                    Column {
                        T(d.battingName, sc.sp(6f), s.text, bold = true)
                        T("vs ${d.bowlingName}", sc.sp(3.6f), s.sub)
                    }
                }
                Score(d.runs, d.wickets, s, sc, 24f)
                T("Overs ${d.overs}   CRR ${d.crr}" + (d.rrr?.let { "   RRR $it" } ?: ""), sc.sp(3.8f), s.sub)
                d.needText?.let { T(it, sc.sp(4.4f), s.accent, bold = true) }
                Rule(s, sc)
                PlayerLine(d.striker, d.strikerStat, s, sc, 4f, bold = true)
                PlayerLine(d.nonStriker, d.nonStrikerStat, s, sc, 4f)
                PlayerLine(d.bowler, d.bowlerStat, s, sc, 4f)
                Rule(s, sc)
                Balls(d.lastSix, sc)
            }
        }
    }
}
