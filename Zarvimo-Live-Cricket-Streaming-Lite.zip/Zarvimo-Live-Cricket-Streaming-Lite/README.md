# Zarvimo Live Cricket Streaming Lite — Stage 2

Stage 2 + UI redesign (matches the supplied reference mock-ups): splash, colourful home grid, create-match with team cards, side-by-side Playing XI, live scoring pad with last-6 circles and Batting/Bowling tabs, template grid, live preview with toggles, country grid, YouTube streaming settings screen (engine arrives in the streaming stage). Offline flags (254 incl. West Indies badge), local match saving/history/export, theme settings.
scoring engine with unit tests, and the Home + Match Setup screens.

**Not built yet (later stages):** flags, Playing XI, Room storage, history, scoreboard
templates, backgrounds, logo, Audio Studio, preview, RTMP streaming. Nothing here streams yet.

## Verification status (honest)
- Written without network access: **nothing has been compiled and no test has been run yet.**
- The first GitHub Actions run is the first real compile + unit-test run. If it fails, send me
  the log and I will fix it.
- No Gradle wrapper is included (it can't be generated offline). The workflow installs Gradle 8.9
  itself. To use Android Studio, open the project and let it create the wrapper, or run `gradle wrapper`.

## First build on GitHub (no renaming, no extraction)
1. Create a GitHub repository (default branch `main`).
2. Upload `build-android.yml` once to `.github/workflows/build-android.yml`
   (Add file > Create new file > type the path > paste contents). Replace it when a new version is supplied.
3. Upload the ZIP to the repository root with **any file name** (for example `Zarvimo-Live-Cricket-Streaming-Lite (1).zip`).
4. The upload triggers **Build Android APK** automatically (or run it from the Actions tab).
   The workflow picks the newest ZIP in the root, builds it, and after a successful build deletes older ZIPs
   and renames the newest to `Zarvimo-Live-Cricket-Streaming-Lite.zip`, so the repo always holds one ZIP.
5. Download **zarvimo-debug-apk** from the run's Artifacts. Test reports are in **unit-test-reports**.

If the build fails, the old ZIPs are left untouched.

## Release signing (optional)
Set env vars `KEYSTORE_PATH`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` (from GitHub
Secrets) when running a release build. Debug builds need none.

## Permissions
Stage 1 declares none. Later stages add INTERNET, RECORD_AUDIO and a foreground service for streaming.

## Engine notes and known simplifications
- Package `com.zarvimo.livecricket.engine`; state is derived by replaying an action list, so
  undo and edit-previous-delivery are replays.
- No ball: bat runs only (byes/leg byes off a no ball are not modelled yet).
- Test: 4 innings, declaration supported, no follow-on; draws via manual result.
- The Hundred: 5-ball sets, ends change every 10 balls, consecutive sets allowed.
- Bowler credited for bowled, caught, LBW, stumped, hit wicket only.
