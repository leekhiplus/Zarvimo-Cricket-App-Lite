# Zarvimo Live Cricket Streaming Lite — Stage 1

Stage 1 contains: Gradle/Compose skeleton, GitHub Actions APK build, a pure-Kotlin cricket
scoring engine with unit tests, and the Home + Match Setup screens.

**Not built yet (later stages):** flags, Playing XI, Room storage, history, scoreboard
templates, backgrounds, logo, Audio Studio, preview, RTMP streaming. Nothing here streams yet.

## Verification status (honest)
- Written without network access: **nothing has been compiled and no test has been run yet.**
- The first GitHub Actions run is the first real compile + unit-test run. If it fails, send me
  the log and I will fix it.
- No Gradle wrapper is included (it can't be generated offline). The workflow installs Gradle 8.9
  itself. To use Android Studio, open the project and let it create the wrapper, or run `gradle wrapper`.

## First build on GitHub (no extraction needed)
1. Create a GitHub repository (default branch `main`).
2. Upload **Zarvimo-Live-Cricket-Streaming-Lite.zip** to the repository root.
3. Upload `build-android.yml` to `.github/workflows/build-android.yml`
   (GitHub web: Add file > Create new file > type the path, paste the contents).
4. Open **Actions > Build Android APK > Run workflow** (a push to `main` also triggers it).
5. When finished, download **zarvimo-debug-apk** from the run's Artifacts
   (`app/build/outputs/apk/debug/app-debug.apk`). Test reports are in **unit-test-reports**.

The workflow unzips the archive into a temp directory itself. If you instead upload the
unzipped project files to the repo root, it builds those.

## Release signing (optional)
Set env vars `KEYSTORE_PATH`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` (from GitHub
Secrets) when running a release build. Debug builds need none.

## Permissions
Stage 1 declares none. Later stages add INTERNET, RECORD_AUDIO and a foreground service for streaming.

## Engine notes and known simplifications
- Package `com.zarvimo.livecricket.engine`; state is derived by replaying an action list, so
  undo and edit-previous-delivery are replays.
- No ball: bat runs only (byes/leg byes off a no ball are not modelled yet).
- Test: 4 innings, declaration supported, no follow-on; draws via manual result.
- The Hundred: 5-ball sets, ends change every 10 balls, consecutive sets allowed.
- Bowler credited for bowled, caught, LBW, stumped, hit wicket only.
