# Third-party notices
Stage 1 uses AndroidX, Jetpack Compose, Material 3 and Kotlin (Apache License 2.0) and JUnit 4
(Eclipse Public License 1.0, tests only). Later stages will list the RTMP library and flag assets here.
