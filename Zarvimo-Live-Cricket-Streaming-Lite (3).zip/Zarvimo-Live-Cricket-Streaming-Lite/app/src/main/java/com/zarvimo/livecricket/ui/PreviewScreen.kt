package com.zarvimo.livecricket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.livecricket.AppViewModel

@Composable
fun PreviewScreen(vm: AppViewModel, onBack: () -> Unit, onLogo: () -> Unit) {
    var full by rememberSaveable { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val portrait = vm.stream.portrait
    val style = Templates[vm.templateIndex.coerceIn(0, Templates.lastIndex)]

    if (full) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable { full = false }, contentAlignment = Alignment.Center) {
            BoardImage(
                vm, portrait,
                Modifier.then(if (portrait) Modifier.fillMaxHeight() else Modifier.fillMaxWidth()),
            )
        }
        return
    }

    ScreenScaffold(
        "Live Preview", onBack,
        actions = { Icon(Icons.Filled.Fullscreen, contentDescription = "Full screen", modifier = Modifier.size(40.dp).clip(CircleShape).clickable { full = true }.padding(8.dp)) },
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !portrait, onClick = { vm.updateStream { it.copy(portrait = false) } }, label = { Text("Landscape 16:9") })
            FilterChip(selected = portrait, onClick = { vm.updateStream { it.copy(portrait = true) } }, label = { Text("Portrait 9:16") })
        }
        BoardImage(
            vm, portrait,
            Modifier.then(if (portrait) Modifier.height(460.dp) else Modifier.fillMaxWidth()).clip(RoundedCornerShape(16.dp)),
        )

        GlassCard(Modifier.fillMaxWidth()) {
            Box {
                OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Template: ${style.name}  \u25BE")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    Templates.forEachIndexed { i, t ->
                        DropdownMenuItem(text = { Text("${i + 1}. ${t.name}") }, onClick = { vm.selectTemplate(i); menu = false })
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Logo", Modifier.weight(1f), fontSize = 16.sp)
                TextButton(onClick = onLogo) { Text("Edit logo") }
                Switch(checked = vm.media.logo.visible, onCheckedChange = { on -> vm.updateLogo { it.copy(visible = on) } })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Music", Modifier.weight(1f), fontSize = 16.sp)
                Switch(checked = !vm.media.audio.musicMuted, onCheckedChange = { on -> vm.updateAudio { it.copy(musicMuted = !on) } })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Commentary", Modifier.weight(1f), fontSize = 16.sp)
                Switch(checked = vm.media.audio.micEnabled, onCheckedChange = { on -> vm.updateAudio { it.copy(micEnabled = on) } })
            }
        }
        PrimaryButton("Switch Template", Palette.Blue) { vm.selectTemplate((vm.templateIndex + 1) % Templates.size) }
    }
}
