package com.zarvimo.livecricket.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Navy broadcast backdrop with floodlight glows (dark theme); plain background in light theme. */
@Composable
fun AppBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    Box(
        modifier.fillMaxSize().then(
            if (dark) Modifier.drawBehind {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF040A1C), Color(0xFF0A1C52), Color(0xFF071236))))
                val r = size.width * 0.7f
                drawCircle(Brush.radialGradient(listOf(Color(0x552F8CFF), Color.Transparent), Offset(size.width * 0.05f, 0f), r), r, Offset(size.width * 0.05f, 0f))
                drawCircle(Brush.radialGradient(listOf(Color(0x552F8CFF), Color.Transparent), Offset(size.width * 0.95f, 0f), r), r, Offset(size.width * 0.95f, 0f))
            } else Modifier.background(MaterialTheme.colorScheme.background),
        ),
        content = content,
    )
}

/** Stadium-style picture used behind scoreboards: sky, floodlights, green field and pitch strip. */
fun Modifier.stadiumBackground(): Modifier = this.drawBehind {
    drawRect(
        Brush.verticalGradient(
            0f to Color(0xFF071235), 0.5f to Color(0xFF123A7A), 0.52f to Color(0xFF1F7A3A), 1f to Color(0xFF0E4A25),
        ),
    )
    val r = size.width * 0.28f
    listOf(0.12f, 0.88f).forEach { fx ->
        val c = Offset(size.width * fx, size.height * 0.1f)
        drawCircle(Brush.radialGradient(listOf(Color(0xDDFFFFFF), Color.Transparent), c, r), r, c)
    }
    val pitch = Path().apply {
        moveTo(size.width * 0.46f, size.height * 0.55f)
        lineTo(size.width * 0.54f, size.height * 0.55f)
        lineTo(size.width * 0.66f, size.height)
        lineTo(size.width * 0.34f, size.height)
        close()
    }
    drawPath(pitch, Color(0x33FFFFFF))
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
            .border(1.dp, Color(0x443B82F6), shape)
            .padding(12.dp),
        content = content,
    )
}

@Composable
fun GradientTile(title: String, icon: ImageVector, top: Color, bottom: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .border(1.dp, Color(0x55FFFFFF), shape)
            .clickable(onClick = onClick)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
    }
}

@Composable
fun PrimaryButton(text: String, color: Color, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(52.dp),
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
}

@Composable
fun ZarvimoLogo(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Palette.Red),
            contentAlignment = Alignment.Center,
        ) { Text("\u25B6", color = Color.White, fontSize = 22.sp) }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("ZARVIMO", color = MaterialTheme.colorScheme.onBackground, fontSize = 26.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
            Text("Live Cricket Streaming Lite", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f), fontSize = 12.sp)
        }
    }
}

@Composable
fun CricketBall(size: Dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFFFF6B5E), Color(0xFFB71C1C)), Offset(w * 0.35f, w * 0.3f), w * 0.8f),
        )
        val seam = Stroke(width = w * 0.025f)
        drawArc(Color.White.copy(alpha = 0.9f), -60f, 120f, false, Offset(-w * 0.55f, w * 0.1f), Size(w * 1.0f, w * 0.8f), style = seam)
        drawArc(Color.White.copy(alpha = 0.9f), 120f, 120f, false, Offset(w * 0.55f, w * 0.1f), Size(w * 1.0f, w * 0.8f), style = seam)
    }
}

@Composable
fun SplashContent() {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CricketBall(110.dp)
        Spacer(Modifier.height(24.dp))
        Text("ZARVIMO", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
        Text(
            "Live Cricket\nStreaming Lite", color = Palette.Yellow, fontSize = 28.sp,
            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(16.dp))
        Box(Modifier.clip(CircleShape).background(Palette.Red).padding(horizontal = 16.dp, vertical = 6.dp)) {
            Text("Live Score \u2022 Live Stream \u2022 Grow Your Channel", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(40.dp))
        androidx.compose.material3.CircularProgressIndicator(color = Palette.Blue)
        Spacer(Modifier.height(8.dp))
        Text("Loading...", color = Color.White)
    }
}
