package com.zarvimo.livecricket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Tile(val title: String, val icon: ImageVector, val top: Color, val bottom: Color, val target: Screen)

private val tiles = listOf(
    Tile("Create\nNew Match", Icons.Filled.Add, Color(0xFF3B7BFF), Color(0xFF1B3FBF), Screen.SETUP),
    Tile("Live\nScoring", Icons.Filled.Calculate, Color(0xFF3DBE4B), Color(0xFF1E8A32), Screen.SCORING),
    Tile("Templates", Icons.Filled.Palette, Color(0xFF9A4DEB), Color(0xFF5B25B5), Screen.TEMPLATES),
    Tile("Background", Icons.Filled.Image, Color(0xFFFFA726), Color(0xFFE06A00), Screen.BACKGROUND),
    Tile("Audio\nStudio", Icons.Filled.MusicNote, Color(0xFF2AA7C9), Color(0xFF1C6E96), Screen.AUDIO),
    Tile("Live\nPreview", Icons.Filled.LiveTv, Color(0xFF3B8BFF), Color(0xFF1B49C9), Screen.PREVIEW),
    Tile("YouTube\nStreaming", Icons.Filled.Sensors, Color(0xFFE53935), Color(0xFFA81C1C), Screen.STREAM),
    Tile("Match\nHistory", Icons.Filled.History, Color(0xFF3DBE4B), Color(0xFF1E8A32), Screen.HISTORY),
)

/** Home dashboard laid out like the reference: header, 2 x 4 tile grid that fills the screen, App Settings bar. */
@Composable
fun HomeScreen(onNavigate: (Screen) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            ZarvimoLogo(Modifier.weight(1f))
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Color(0x332F8CFF))
                    .border(1.dp, Color(0x663B82F6), CircleShape).clickable { onNavigate(Screen.SETTINGS) },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = Color(0xFF7FB2FF), modifier = Modifier.size(24.dp)) }
        }
        tiles.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { tile ->
                    GradientTile(tile.title, tile.icon, tile.top, tile.bottom, Modifier.weight(1f).fillMaxHeight()) {
                        onNavigate(tile.target)
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(14.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF2F7BFF), Color(0xFF1B49C9))))
                .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(14.dp))
                .clickable { onNavigate(Screen.SETTINGS) },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(Icons.Filled.Settings, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Text("App Settings", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
