package com.zarvimo.livecricket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.livecricket.AppViewModel
import com.zarvimo.livecricket.data.TeamInfo
import com.zarvimo.livecricket.engine.Action
import com.zarvimo.livecricket.engine.Delivery
import com.zarvimo.livecricket.engine.DeliveryType
import com.zarvimo.livecricket.engine.Innings
import com.zarvimo.livecricket.engine.InningsStatus
import com.zarvimo.livecricket.engine.Side
import com.zarvimo.livecricket.engine.Slot
import com.zarvimo.livecricket.engine.Team
import com.zarvimo.livecricket.engine.WicketType
import java.util.Locale

private enum class Pick { NONE, BATTER, BOWLER, RETIRE }

private fun Team.nameOf(id: Int?): String = players.firstOrNull { it.id == id }?.name ?: "-"
private fun fmt(x: Double): String = String.format(Locale.US, "%.2f", x)
private fun shortName(n: String): String = n.trim().take(3).uppercase()

private fun tagged(info: TeamInfo, id: Int, name: String): String {
    val tags = listOfNotNull(if (info.captain == id - 1) "C" else null, if (info.keeper == id - 1) "WK" else null)
    return if (tags.isEmpty()) name else "$name (${tags.joinToString(", ")})"
}

private fun maidens(inn: Innings, id: Int): Int {
    val bpo = inn.config.ballsPerOver
    return inn.state.balls.filter { it.bowlerId == id }.groupBy { it.overIndex }.count { (_, bs) ->
        bs.count { it.legal } == bpo && bs.sumOf { r ->
            when (r.delivery.type) {
                DeliveryType.NORMAL -> r.delivery.runs
                DeliveryType.WIDE, DeliveryType.NO_BALL -> 1 + r.delivery.runs
                else -> 0
            }
        } == 0
    }
}

private fun circleColor(l: String): Color = when {
    l.endsWith("W") -> Color(0xFFD32F2F)
    l == "0" -> Color(0xFF1E5BD8)
    l == "1" -> Color(0xFF1B7F3B)
    l == "2" || l == "3" -> Color(0xFFE08A00)
    l == "4" -> Color(0xFF22B14C)
    l == "6" -> Color(0xFFD32F2F)
    else -> Color(0xFF7E57C2)
}

@Composable
private fun BallCircle(label: String) {
    Box(Modifier.size(38.dp).clip(CircleShape).background(circleColor(label)), contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (label.length > 2) 11.sp else 15.sp, maxLines = 1)
    }
}

@Composable
private fun PadButton(label: String, top: Color, bottom: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(58.dp).clip(RoundedCornerShape(14.dp))
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun Pill(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(44.dp).clip(RoundedCornerShape(12.dp))
            .background(if (selected) Palette.Blue else Color(0xFF1B2A55))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
fun ScoringScreen(vm: AppViewModel, onBack: () -> Unit) {
    val m = vm.match
    val meta = vm.meta
    val inn = m?.current
    var mode by remember { mutableStateOf(DeliveryType.NORMAL) }
    var pick by remember { mutableStateOf(Pick.NONE) }
    var showWicket by remember { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var editIndex by remember { mutableStateOf<Int?>(null) }
    var tab by remember { mutableStateOf(0) }

    ScreenScaffold(
        "Live Scoring", onBack,
        actions = { Icon(Icons.Filled.Home, contentDescription = "Home", modifier = Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onBack).padding(8.dp)) },
    ) {
        if (m == null || inn == null || meta == null) {
            Text("No active match. Create a new match or open one from Match History.")
            return@ScreenScaffold
        }
        val s = inn.state
        val status = inn.status
        val batSide = m.battingSide(m.innings.size - 1)
        val batInfo = if (batSide == Side.A) meta.teamA else meta.teamB
        val bowlInfo = if (batSide == Side.A) meta.teamB else meta.teamA
        val chase = inn.chase

        // Score header
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassCard(Modifier.weight(1f).fillMaxHeight()) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    TeamBadge(batInfo.countryCode, batInfo.logoPath, 34.dp, fallback = inn.battingTeam.name)
                    Text(shortName(inn.battingTeam.name), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("${s.runs}/${s.wickets}", fontWeight = FontWeight.Black, fontSize = 34.sp)
                    Text("${inn.oversText} Overs", fontSize = 13.sp)
                }
            }
            GlassCard(Modifier.weight(1f).fillMaxHeight()) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    TeamBadge(bowlInfo.countryCode, bowlInfo.logoPath, 34.dp, fallback = inn.bowlingTeam.name)
                    Text(shortName(inn.bowlingTeam.name), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    if (chase != null) {
                        Text("Target", fontSize = 14.sp)
                        Text("${chase.target}", fontWeight = FontWeight.Black, fontSize = 28.sp)
                    } else {
                        Text("Innings ${m.innings.size}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(if (m.config.ballsPerInnings != null) "${m.config.ballsPerInnings / m.config.ballsPerOver} overs" else "Test", fontSize = 13.sp)
                    }
                }
            }
        }
        Text(
            "CRR: ${fmt(inn.currentRunRate)}" + (chase?.requiredRate?.let { "     RRR: ${fmt(it)}" } ?: "") +
                (chase?.let { c -> "     Need ${c.runsNeeded}" + (c.ballsRemaining?.let { " off $it" } ?: "") } ?: ""),
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
        )

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Last 6 Balls", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (inn.lastSix.isEmpty()) Text("No deliveries yet.", fontSize = 13.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                inn.lastSix.forEach { BallCircle(it) }
            }
        }

        m.result?.let { r ->
            GlassCard(Modifier.fillMaxWidth()) { Text(r.text, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        }
        if (status != InningsStatus.IN_PROGRESS && m.result == null) {
            Text("Innings complete: ${status.name.replace('_', ' ')}", fontWeight = FontWeight.SemiBold)
            if (m.innings.size < m.config.maxInnings) {
                PrimaryButton("Start innings ${m.innings.size + 1}", Palette.Blue) { vm.nextInnings() }
            }
        }
        if (m.config.maxInnings == 4 && m.result == null) {
            OutlinedButton(onClick = { vm.declareDraw() }) { Text("Declare draw") }
        }
        if (vm.paused) Text("Match is paused", color = Palette.Orange, fontWeight = FontWeight.Bold)

        // Batting / Bowling tabs
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF16275A))) {
            Pill("Batting", tab == 0, Modifier.weight(1f)) { tab = 0 }
            Pill("Bowling", tab == 1, Modifier.weight(1f)) { tab = 1 }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            if (tab == 0) {
                listOf(s.striker to true, s.nonStriker to false).forEach { (id, isStriker) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        val name = if (id == null) "-" else tagged(batInfo, id, inn.battingTeam.nameOf(id)) + if (isStriker) " *" else ""
                        Text(name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        val st = id?.let { s.batters[it] }
                        Text(if (st != null) "${st.runs} (${st.balls})" else "", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                if (s.bowlers.isEmpty()) Text("No bowler yet.")
                s.bowlers.forEach { (id, b) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        val cur = if (id == s.bowler) " *" else ""
                        Text(tagged(bowlInfo, id, inn.bowlingTeam.nameOf(id)) + cur, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        val bpo = m.config.ballsPerOver
                        Text("${b.legalBalls / bpo}.${b.legalBalls % bpo} - ${maidens(inn, id)} - ${b.runs} - ${b.wickets}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        val needText: String? = if (status != InningsStatus.IN_PROGRESS) null else when {
            s.striker == null -> "Select striker"
            s.nonStriker == null -> "Select non-striker"
            s.bowler == null -> "Select bowler"
            else -> null
        }

        if (status == InningsStatus.IN_PROGRESS) {
            if (needText != null) {
                PrimaryButton(needText, Palette.Blue) {
                    pick = if (s.striker == null || s.nonStriker == null) Pick.BATTER else Pick.BOWLER
                }
            } else {
                val blueTop = Color(0xFF2F7BFF)
                val blueBottom = Color(0xFF123FA8)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 1, 2, 3).forEach { n ->
                        PadButton("$n", blueTop, blueBottom, Modifier.weight(1f)) {
                            vm.perform(Action.Ball(Delivery(mode, n))); mode = DeliveryType.NORMAL
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(4, 5, 6).forEach { n ->
                        PadButton("$n", blueTop, blueBottom, Modifier.weight(1f)) {
                            vm.perform(Action.Ball(Delivery(mode, n))); mode = DeliveryType.NORMAL
                        }
                    }
                    PadButton("W", Color(0xFFFF4D4D), Color(0xFFB71C1C), Modifier.weight(1f)) { showWicket = true }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        DeliveryType.WIDE to "Wide", DeliveryType.NO_BALL to "No Ball",
                        DeliveryType.BYE to "Bye", DeliveryType.LEG_BYE to "Leg Bye",
                    ).forEach { (t, label) ->
                        Pill(label, mode == t, Modifier.weight(1f)) { mode = if (mode == t) DeliveryType.NORMAL else t }
                    }
                }
                if (mode != DeliveryType.NORMAL) {
                    Text(
                        when (mode) {
                            DeliveryType.WIDE -> "Wide selected: tap extra runs run (0 = just the wide)."
                            DeliveryType.NO_BALL -> "No ball selected: tap runs scored off the bat."
                            DeliveryType.BYE -> "Bye selected: tap byes run."
                            DeliveryType.LEG_BYE -> "Leg bye selected: tap leg byes run."
                            DeliveryType.PENALTY -> "Penalty selected: tap penalty runs (1-6)."
                            else -> ""
                        },
                        fontSize = 12.sp, color = Palette.Orange,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Undo", false, Modifier.weight(1f)) { vm.undo() }
                    Pill("Swap", false, Modifier.weight(1f)) { vm.perform(Action.SwapStrike) }
                    Pill("More", false, Modifier.weight(1f)) { showMore = true }
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Undo", false, Modifier.weight(1f)) { vm.undo() }
                Pill("History", false, Modifier.weight(1f)) { showHistory = true }
            }
        }

        // ---- dialogs ----
        if (showMore) {
            AlertDialog(
                onDismissRequest = { showMore = false },
                title = { Text("More") },
                text = {
                    Column {
                        @Composable
                        fun Item(label: String, onClick: () -> Unit) {
                            TextButton(onClick = { showMore = false; onClick() }, modifier = Modifier.fillMaxWidth()) {
                                Text(label, modifier = Modifier.fillMaxWidth())
                            }
                        }
                        Item("Penalty runs") { mode = DeliveryType.PENALTY }
                        Item("Dead ball") { vm.perform(Action.Ball(Delivery(DeliveryType.DEAD))) }
                        Item("Retire out") { pick = Pick.RETIRE }
                        Item("Change bowler") { pick = Pick.BOWLER }
                        if (m.config.maxInnings == 4) Item("Declare innings") { vm.perform(Action.Declare) }
                        Item("Ball-by-ball history / edit") { showHistory = true }
                        Item(if (vm.paused) "Resume match" else "Pause match") { vm.paused = !vm.paused }
                    }
                },
                confirmButton = { TextButton(onClick = { showMore = false }) { Text("Close") } },
            )
        }

        if (showHistory) {
            AlertDialog(
                onDismissRequest = { showHistory = false },
                title = { Text("Ball by ball") },
                text = {
                    Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                        if (s.balls.isEmpty()) Text("No deliveries yet.")
                        s.balls.withIndex().toList().takeLast(60).reversed().forEach { (i, r) ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "Ov ${r.overIndex + 1}  ${r.label}  (+${r.runsAdded})  ${inn.bowlingTeam.nameOf(r.bowlerId)} to ${inn.battingTeam.nameOf(r.strikerId)}",
                                    modifier = Modifier.weight(1f), fontSize = 13.sp,
                                )
                                if (r.delivery.type != DeliveryType.PENALTY && r.delivery.type != DeliveryType.DEAD) {
                                    TextButton(onClick = { showHistory = false; editIndex = i }) { Text("Edit") }
                                }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showHistory = false }) { Text("Close") } },
            )
        }

        when (pick) {
            Pick.BATTER -> {
                val slot = if (s.striker == null) Slot.STRIKER else Slot.NON_STRIKER
                val eligible = inn.battingTeam.players.filter {
                    s.batters[it.id]?.isOut != true && it.id != s.striker && it.id != s.nonStriker
                }
                PlayerPickerDialog(
                    if (slot == Slot.STRIKER) "Select striker" else "Select non-striker", eligible,
                    onPick = { id -> pick = Pick.NONE; vm.perform(Action.SetBatter(id, slot)) },
                    onDismiss = { pick = Pick.NONE },
                )
            }
            Pick.BOWLER -> {
                val eligible = inn.bowlingTeam.players.filter { m.config.allowConsecutiveOvers || it.id != s.lastOverBowler }
                PlayerPickerDialog(
                    "Select bowler", eligible,
                    onPick = { id -> pick = Pick.NONE; vm.perform(Action.SetBowler(id)) },
                    onDismiss = { pick = Pick.NONE },
                )
            }
            Pick.RETIRE -> {
                val atCrease = inn.battingTeam.players.filter { it.id == s.striker || it.id == s.nonStriker }
                PlayerPickerDialog(
                    "Retire out", atCrease,
                    onPick = { id -> pick = Pick.NONE; vm.perform(Action.RetireOut(id)) },
                    onDismiss = { pick = Pick.NONE },
                )
            }
            Pick.NONE -> {}
        }

        if (showWicket) {
            WicketDialog(
                strikerName = inn.battingTeam.nameOf(s.striker),
                nonStrikerName = inn.battingTeam.nameOf(s.nonStriker),
                nonStrikerId = s.nonStriker,
                mode = mode,
                onConfirm = { d -> showWicket = false; vm.perform(Action.Ball(d)); mode = DeliveryType.NORMAL },
                onDismiss = { showWicket = false },
            )
        }

        editIndex?.let { idx ->
            val rec = s.balls.getOrNull(idx)
            if (rec != null) {
                EditBallDialog(
                    rec.delivery,
                    onConfirm = { d -> editIndex = null; vm.editBall(idx, d) },
                    onDismiss = { editIndex = null },
                )
            }
        }
    }
}

@Composable
private fun WicketDialog(
    strikerName: String,
    nonStrikerName: String,
    nonStrikerId: Int?,
    mode: DeliveryType,
    onConfirm: (Delivery) -> Unit,
    onDismiss: () -> Unit,
) {
    var type by remember { mutableStateOf(WicketType.BOWLED) }
    var nonOut by remember { mutableStateOf(false) }
    var runs by remember { mutableStateOf(0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Wicket") },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                WicketType.values().filter { it != WicketType.RETIRED_OUT }.forEach { w ->
                    Row(Modifier.fillMaxWidth().clickable { type = w }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = type == w, onClick = { type = w })
                        Text(w.label)
                    }
                }
                if (type == WicketType.RUN_OUT) {
                    Text("Who is out?", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = !nonOut, onClick = { nonOut = false }, label = { Text(strikerName) })
                        FilterChip(selected = nonOut, onClick = { nonOut = true }, label = { Text(nonStrikerName) })
                    }
                    Text("Runs completed", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (0..3).forEach { n -> FilterChip(selected = runs == n, onClick = { runs = n }, label = { Text("$n") }) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val runOut = type == WicketType.RUN_OUT
                onConfirm(Delivery(mode, if (runOut) runs else 0, type, if (runOut && nonOut) nonStrikerId else null))
            }) { Text("Confirm") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun EditBallDialog(d: Delivery, onConfirm: (Delivery) -> Unit, onDismiss: () -> Unit) {
    var type by remember { mutableStateOf(d.type) }
    var runs by remember { mutableStateOf(d.runs) }
    val types = listOf(
        DeliveryType.NORMAL to "Normal", DeliveryType.WIDE to "Wide", DeliveryType.NO_BALL to "No ball",
        DeliveryType.BYE to "Bye", DeliveryType.LEG_BYE to "Leg bye",
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit delivery") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    types.forEach { (t, l) -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(l) }) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (0..7).forEach { n -> FilterChip(selected = runs == n, onClick = { runs = n }, label = { Text("$n") }) }
                }
                if (d.wicket != null) Text("The wicket on this ball is kept.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(Delivery(type, runs, d.wicket, d.dismissed)) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
