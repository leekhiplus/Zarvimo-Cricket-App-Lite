# Zarvimo Live Cricket Streaming Lite

All stages are now in the project: scoring engine, offline flags (254), Playing XI, 10 scoreboard templates,
custom background, channel logo/watermark, Audio Studio (music + microphone mixer), live preview,
and RTMP streaming to YouTube with a foreground service. See USAGE.md and PERMISSIONS.md.

## UI
The app follows the supplied reference design (dark navy theme, 2 x 4 tile home with App Settings bar, vector icons). Dark is the default theme; Channel Logo settings open from Background and Live Preview.

## Verification status (honest)
- Written without network access, so **nothing has been compiled or run by me**. The GitHub Actions run is the first
  real compile + unit-test run; send the log if it fails.
- **Streaming is untested against a real YouTube account.** It uses the RootEncoder RTMP client
  (`com.github.pedroSG94.RootEncoder:rtmp:2.5.5` from JitPack; only `RtmpClient` and `ConnectChecker` are used)
  while encoding is done with Android `MediaCodec`. The library API was written from knowledge of the library, not
  checked offline, so the first compile may need a small signature fix. Final live verification needs your stream key.
- Preview and stream use the same renderer (`render/BoardPainter.kt`), so what you see is what is sent.
- Room/DataStore were replaced by JSON files + SharedPreferences to reduce build risk (data stays local).
- No Gradle wrapper is included; the workflow installs Gradle 8.9.

## How streaming works
`BoardPainter` -> H.264 `MediaCodec` input Surface; microphone + decoded music -> mixer -> AAC `MediaCodec`;
both -> `RtmpClient`. Connect opens the RTMP session; Start Live begins sending. A foreground service keeps it
running with the screen locked. Network loss triggers reconnect attempts; scoring continues and is auto-saved.

## Known limits
- Microphone audio focus / other apps taking the mic are not specially handled.
- The Hundred uses 5-ball sets with end change every 10 balls; Test has no follow-on.
- No ball: bat runs only (no byes off a no ball).

## First build on GitHub (no renaming, no extraction)
1. Create a GitHub repository (default branch `main`).
2. Upload `build-android.yml` once to `.github/workflows/build-android.yml`
   (Add file > Create new file > type the path > paste contents). Replace it when a new version is supplied.
3. Upload the ZIP to the repository root with **any file name** (for example `Zarvimo-Live-Cricket-Streaming-Lite (1).zip`).
4. The upload triggers **Build Android APK** automatically (or run it from the Actions tab).
   The workflow picks the newest ZIP in the root, builds it, and after a successful build deletes older ZIPs
   and renames the newest to `Zarvimo-Live-Cricket-Streaming-Lite.zip`, so the repo always holds one ZIP.
5. Download **zarvimo-debug-apk** from the run's Artifacts. Test reports are in **unit-test-reports**.

If the build fails, the old ZIPs are left untouched.

## Release signing (optional)
Set env vars `KEYSTORE_PATH`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` (from GitHub
Secrets) when running a release build. Debug builds need none.

## Permissions
Stage 1 declares none. Later stages add INTERNET, RECORD_AUDIO and a foreground service for streaming.

## Engine notes and known simplifications
- Package `com.zarvimo.livecricket.engine`; state is derived by replaying an action list, so
  undo and edit-previous-delivery are replays.
- No ball: bat runs only (byes/leg byes off a no ball are not modelled yet).
- Test: 4 innings, declaration supported, no follow-on; draws via manual result.
- The Hundred: 5-ball sets, ends change every 10 balls, consecutive sets allowed.
- Bowler credited for bowled, caught, LBW, stumped, hit wicket only.
