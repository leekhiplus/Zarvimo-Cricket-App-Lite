# Stage 1: no custom rules needed. Streaming/Room rules are added in later stages.
