package com.zarvimo.livecricket.data

import org.junit.Assert.assertEquals
import org.junit.Test

class MediaJsonTest {
    @Test fun mediaSettingsRoundTrip() {
        val m = MediaSettings(
            bgLandscape = BgSettings("custom", "/a/bg.jpg", "fit", 1.5f, -0.25f, 0.5f),
            bgPortrait = BgSettings("dark"),
            logo = LogoSettings("/a/logo.png", false, "BOTTOM_LEFT", 20, 70, "My Channel"),
            audio = AudioSettings("/a/m.mp3", "m.mp3", false, 35, true, false, 80),
        )
        assertEquals(m, MediaJson.mediaFromJson(MediaJson.mediaToJson(m)))
    }

    @Test fun emptyJsonGivesDefaults() {
        assertEquals(MediaSettings(), MediaJson.mediaFromJson("{}"))
        assertEquals(StreamSettings(), MediaJson.streamFromJson("{}"))
    }

    @Test fun streamSettingsRoundTrip() {
        val s = StreamSettings(portrait = true, fps = 24, videoKbps = 4000, audioKbps = 192)
        assertEquals(s, MediaJson.streamFromJson(MediaJson.streamToJson(s)))
    }
}
