package com.zarvimo.livecricket.stream

import org.junit.Assert.assertEquals
import org.junit.Test

class StreamProfilesTest {
    @Test fun portraitSwapsDimensions() {
        val p = StreamProfiles.byLabel("720p")
        assertEquals(1280, StreamProfiles.width(p, false))
        assertEquals(720, StreamProfiles.height(p, false))
        assertEquals(720, StreamProfiles.width(p, true))
        assertEquals(1280, StreamProfiles.height(p, true))
    }

    @Test fun unknownLabelFallsBackTo720p() {
        assertEquals("720p", StreamProfiles.byLabel("nonsense").label)
    }

    @Test fun bitrateAutoAndManual() {
        val p = StreamProfiles.byLabel("720p")
        assertEquals(2_500_000, StreamProfiles.videoBitrateBps(p, 0, 30))
        assertEquals(4_000_000, StreamProfiles.videoBitrateBps(p, 4000, 30))
        assertEquals(3_750_000, StreamProfiles.videoBitrateBps(p, 0, 60))
        assertEquals(5_000_000, StreamProfiles.videoBitrateBps(StreamProfiles.byLabel("1080p"), 0, 30))
    }
}
