package com.zarvimo.livecricket.stream

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class AudioMathTest {
    @Test fun mixAddsMicToBothChannelsWithGains() {
        val out = ShortArray(2)
        AudioMath.mix(shortArrayOf(1000), 1f, shortArrayOf(2000, -2000), 0.5f, out, 1)
        assertEquals(2000, out[0].toInt())
        assertEquals(0, out[1].toInt())
    }

    @Test fun mixClipsInsteadOfOverflowing() {
        val out = ShortArray(2)
        AudioMath.mix(shortArrayOf(30000), 1f, shortArrayOf(30000, -30000), 1f, out, 1)
        assertEquals(32767, out[0].toInt())
        assertEquals(0, out[1].toInt()) // -30000 + 30000
        AudioMath.mix(shortArrayOf(-30000), 1f, shortArrayOf(-30000, -30000), 1f, out, 1)
        assertEquals(-32768, out[0].toInt())
    }

    @Test fun mixWithoutMicPassesMusic() {
        val out = ShortArray(4)
        AudioMath.mix(null, 1f, shortArrayOf(1, 2, 3, 4), 1f, out, 2)
        assertArrayEquals(shortArrayOf(1, 2, 3, 4), out)
        AudioMath.mix(null, 1f, shortArrayOf(100, 200, 300, 400), 0f, out, 2) // muted music
        assertArrayEquals(shortArrayOf(0, 0, 0, 0), out)
    }

    @Test fun percentToGainIsClamped() {
        assertEquals(1f, AudioMath.percentToGain(150), 0.0001f)
        assertEquals(0f, AudioMath.percentToGain(-5), 0.0001f)
        assertEquals(0.6f, AudioMath.percentToGain(60), 0.0001f)
    }

    @Test fun resamplerPassthroughIsContinuousAcrossChunks() {
        val r = StereoResampler(SAMPLE_RATE, 2)
        val a = r.process(shortArrayOf(1, 2, 3, 4, 5, 6, 7, 8), 4)
        val b = r.process(shortArrayOf(9, 10, 11, 12, 13, 14, 15, 16), 4)
        assertArrayEquals(shortArrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14), a + b)
    }

    @Test fun resamplerDuplicatesMono() {
        val r = StereoResampler(SAMPLE_RATE, 1)
        val out = r.process(shortArrayOf(10, 20, 30), 3)
        assertArrayEquals(shortArrayOf(10, 10, 20, 20), out)
    }

    @Test fun resamplerDownsamplesByTwo() {
        val r = StereoResampler(88200, 2)
        val src = ShortArray(16) { (it / 2 * 100).toShort() } // frame n = (n*100, n*100)
        val out = r.process(src, 8)
        assertEquals(8, out.size)
        assertEquals(0, out[0].toInt())
        assertEquals(200, out[2].toInt())
        assertEquals(400, out[4].toInt())
        assertEquals(600, out[6].toInt())
    }

    @Test fun resamplerUpsamplesByInterpolating() {
        val r = StereoResampler(22050, 1)
        val out = r.process(shortArrayOf(0, 100, 200), 3)
        val left = out.filterIndexed { i, _ -> i % 2 == 0 }
        assertEquals(listOf<Short>(0, 50, 100, 150), left)
    }

    @Test fun ringBufferWrapsAndLimits() {
        val ring = ShortRing(4)
        assertEquals(3, ring.write(shortArrayOf(1, 2, 3), 0, 3))
        assertEquals(1, ring.write(shortArrayOf(4, 5), 0, 2)) // only one slot free
        val dst = ShortArray(4)
        assertEquals(2, ring.read(dst, 0, 2))
        assertEquals(1, dst[0].toInt()); assertEquals(2, dst[1].toInt())
        assertEquals(1, ring.write(shortArrayOf(9), 0, 1)) // wraps around
        assertEquals(3, ring.read(dst, 0, 4))
        assertArrayEquals(shortArrayOf(3, 4, 9), dst.copyOf(3))
        assertEquals(0, ring.available())
    }
}
