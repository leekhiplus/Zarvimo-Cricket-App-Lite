package com.zarvimo.livecricket.data

import com.zarvimo.livecricket.engine.Action
import com.zarvimo.livecricket.engine.Delivery
import com.zarvimo.livecricket.engine.DeliveryType
import com.zarvimo.livecricket.engine.MatchFormat
import com.zarvimo.livecricket.engine.Side
import com.zarvimo.livecricket.engine.Slot
import com.zarvimo.livecricket.engine.WicketType
import org.junit.Assert.assertEquals
import org.junit.Test

class MatchJsonTest {
    private fun info(n: String) = TeamInfo(n, "PK", null, List(11) { if (it < 3) "$n ${it + 1}" else "" }, 0, 1)

    @Test fun savedMatchRoundTripsAndReplaysToSameScore() {
        var saved = SavedMatch("id1", "Final", "Lahore", "2026-11-16", MatchFormat.CUSTOM, 1,
            info("Alpha"), info("Bravo"), Side.A, emptyList(), null, 1L)
        var m = saved.toMatch().startNextInnings()
        val inn = m.current!!
            .perform(Action.SetBatter(1, Slot.STRIKER))
            .perform(Action.SetBatter(2, Slot.NON_STRIKER))
            .perform(Action.SetBowler(1))
            .perform(Action.Ball(Delivery(DeliveryType.NORMAL, 4)))
            .perform(Action.Ball(Delivery(DeliveryType.WIDE, 0)))
            .perform(Action.Ball(Delivery(DeliveryType.NORMAL, 0, WicketType.CAUGHT)))
        m = m.updateCurrent(inn)
        saved = saved.copy(innings = m.innings.map { it.actions })

        val back = MatchJson.fromJson(MatchJson.toJson(saved))
        assertEquals(saved, back)
        val replayed = back.toMatch().current!!
        assertEquals(5, replayed.state.runs)
        assertEquals(1, replayed.state.wickets)
        assertEquals(2, replayed.state.legalBalls)
    }

    @Test fun teamJsonRoundTrip() {
        val t = TeamInfo("Pakistan", "PK", "/tmp/logo.png", List(11) { "P$it" }, 3, 4)
        assertEquals(t, MatchJson.teamFromJson(MatchJson.teamToJson(t)))
        val bare = TeamInfo("X", null, null, List(11) { "" }, null, null)
        assertEquals(bare, MatchJson.teamFromJson(MatchJson.teamToJson(bare)))
    }

    @Test fun blankSlotsBecomeNumberedPlayers() {
        val names = info("Alpha").finalNames()
        assertEquals(11, names.size)
        assertEquals("Alpha 1", names[0])
        assertEquals("Player 4", names[3])
        assertEquals(11, info("Alpha").toTeam().players.size)
    }

    @Test fun everyActionTypeSurvivesJson() {
        val all = listOf(
            Action.Ball(Delivery(DeliveryType.NORMAL, 1, WicketType.RUN_OUT, 5)),
            Action.SetBowler(3), Action.SetBatter(4, Slot.NON_STRIKER),
            Action.SwapStrike, Action.RetireOut(2), Action.Declare,
        )
        all.forEach { assertEquals(it, MatchJson.actionFromJson(MatchJson.actionToJson(it))) }
    }
}
