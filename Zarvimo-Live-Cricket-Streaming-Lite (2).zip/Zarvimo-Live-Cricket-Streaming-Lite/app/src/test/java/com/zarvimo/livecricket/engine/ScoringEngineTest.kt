package com.zarvimo.livecricket.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ScoringEngineTest {

    private fun team(name: String, firstId: Int) =
        Team(name, (0 until 11).map { Player(firstId + it, "$name ${it + 1}") })

    private val teamA = team("Alpha", 1)
    private val teamB = team("Bravo", 101)
    private val oneOver = MatchConfig.forFormat(MatchFormat.CUSTOM, 1)
    private val t20 = MatchConfig.forFormat(MatchFormat.T20)

    /** Innings with openers selected (batting team players 0 and 1). */
    private fun opened(config: MatchConfig = t20, bat: Team = teamA, bowl: Team = teamB, target: Int? = null): Innings =
        Innings.start(config, bat, bowl, target)
            .perform(Action.SetBatter(bat.players[0].id, Slot.STRIKER))
            .perform(Action.SetBatter(bat.players[1].id, Slot.NON_STRIKER))

    /** Bowls a delivery, choosing an eligible bowler automatically when none is set. */
    private fun Innings.next(d: Delivery): Innings {
        var i = this
        if (i.state.bowler == null) {
            val b = i.bowlingTeam.players.first { it.id != i.state.lastOverBowler }.id
            i = i.perform(Action.SetBowler(b))
        }
        return i.perform(Action.Ball(d))
    }

    private fun Innings.runs(n: Int) = next(Delivery(DeliveryType.NORMAL, n))

    private fun expectFailure(block: () -> Unit) {
        try {
            block()
            fail("Expected IllegalArgumentException")
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test fun formatsComputeLegalDeliveries() {
        assertEquals(60, MatchConfig.forFormat(MatchFormat.T10).ballsPerInnings)
        assertEquals(120, t20.ballsPerInnings)
        assertEquals(300, MatchConfig.forFormat(MatchFormat.ODI).ballsPerInnings)
        assertEquals(42, MatchConfig.forFormat(MatchFormat.CUSTOM, 7).ballsPerInnings)
        assertEquals(30, MatchConfig.forFormat(MatchFormat.T20, 5).ballsPerInnings)
        val hundred = MatchConfig.forFormat(MatchFormat.THE_HUNDRED)
        assertEquals(100, hundred.ballsPerInnings)
        assertEquals(5, hundred.ballsPerOver)
        assertEquals(10, hundred.endChangeBalls)
        val test = MatchConfig.forFormat(MatchFormat.TEST)
        assertNull(test.ballsPerInnings)
        assertEquals(4, test.maxInnings)
        expectFailure { MatchConfig.forFormat(MatchFormat.CUSTOM) }
        expectFailure { MatchConfig.forFormat(MatchFormat.CUSTOM, 0) }
    }

    @Test fun teamNeedsTwoPlayers() {
        expectFailure { Team("Solo", listOf(Player(1, "A"))) }
    }

    @Test fun sixDotsCompleteOverAndRotateStrike() {
        var i = opened()
        repeat(6) { i = i.runs(0) }
        assertEquals("1.0", i.oversText)
        assertEquals(6, i.state.legalBalls)
        assertNull(i.state.bowler)
        assertEquals(teamB.players[0].id, i.state.lastOverBowler)
        assertEquals(teamA.players[1].id, i.state.striker)
        assertEquals(teamA.players[0].id, i.state.nonStriker)
    }

    @Test fun sameBowlerCannotBowlConsecutiveOvers() {
        var i = opened()
        repeat(6) { i = i.runs(0) }
        expectFailure { i.perform(Action.SetBowler(teamB.players[0].id)) }
        i = i.perform(Action.SetBowler(teamB.players[1].id))
        assertEquals(teamB.players[1].id, i.state.bowler)
    }

    @Test fun oddRunsRotateStrikeEvenRunsDoNot() {
        val a = teamA.players[0].id
        val b = teamA.players[1].id
        var i = opened().runs(1)
        assertEquals(b, i.state.striker)
        i = i.runs(2)
        assertEquals(b, i.state.striker)
        i = i.runs(3)
        assertEquals(a, i.state.striker)
        i = i.runs(4)
        assertEquals(a, i.state.striker)
        assertEquals(10, i.state.runs)
    }

    @Test fun wideIsNotLegalAndAddsPenaltyPlusRuns() {
        val i = opened().next(Delivery(DeliveryType.WIDE, 2))
        assertEquals(3, i.state.runs)
        assertEquals(0, i.state.legalBalls)
        assertEquals(3, i.state.extras.wides)
        assertEquals(0, i.state.batters[teamA.players[0].id]!!.balls)
        assertEquals(3, i.state.bowlers[teamB.players[0].id]!!.runs)
        assertEquals(teamA.players[0].id, i.state.striker) // 2 additional runs: even, no rotation
        val odd = opened().next(Delivery(DeliveryType.WIDE, 1))
        assertEquals(teamA.players[1].id, odd.state.striker)
    }

    @Test fun noBallWithBatRuns() {
        val i = opened().next(Delivery(DeliveryType.NO_BALL, 4))
        assertEquals(5, i.state.runs)
        assertEquals(0, i.state.legalBalls)
        assertEquals(1, i.state.extras.noBalls)
        val bat = i.state.batters[teamA.players[0].id]!!
        assertEquals(4, bat.runs)
        assertEquals(1, bat.balls)
        assertEquals(1, bat.fours)
        assertEquals(5, i.state.bowlers[teamB.players[0].id]!!.runs)
        assertEquals(1, i.state.bowlers[teamB.players[0].id]!!.noBalls)
    }

    @Test fun byesAndLegByesAreLegalExtrasNotChargedToBowler() {
        var i = opened().next(Delivery(DeliveryType.BYE, 1))
        i = i.next(Delivery(DeliveryType.LEG_BYE, 2))
        assertEquals(3, i.state.runs)
        assertEquals(2, i.state.legalBalls)
        assertEquals(1, i.state.extras.byes)
        assertEquals(2, i.state.extras.legByes)
        assertEquals(0, i.state.bowlers[teamB.players[0].id]!!.runs)
        assertEquals(0, i.state.batters[teamA.players[0].id]!!.runs)
        assertEquals(1, i.state.batters[teamA.players[0].id]!!.balls)
        assertEquals(3, i.state.extras.total)
    }

    @Test fun penaltyRunsAddToTotalWithoutABall() {
        val i = opened().perform(Action.Ball(Delivery(DeliveryType.PENALTY, 5)))
        assertEquals(5, i.state.runs)
        assertEquals(0, i.state.legalBalls)
        assertEquals(5, i.state.extras.penalty)
    }

    @Test fun deadBallChangesNothing() {
        val i = opened().perform(Action.Ball(Delivery(DeliveryType.DEAD)))
        assertEquals(0, i.state.runs)
        assertEquals(0, i.state.legalBalls)
        assertEquals(1, i.state.balls.size)
        assertFalse(i.state.balls[0].legal)
        expectFailure { opened().perform(Action.Ball(Delivery(DeliveryType.DEAD, 1))) }
    }

    @Test fun bowledWicketVacatesStrikerAndNeedsNewBatter() {
        val bowler = teamB.players[0].id
        var i = opened().runs(2).next(Delivery(DeliveryType.NORMAL, 0, WicketType.BOWLED))
        assertEquals(1, i.state.wickets)
        assertNull(i.state.striker)
        assertEquals(1, i.state.bowlers[bowler]!!.wickets)
        assertEquals(WicketType.BOWLED, i.state.batters[teamA.players[0].id]!!.dismissal)
        assertEquals(1, i.state.fall.size)
        assertEquals(2, i.state.fall[0].score)
        assertEquals(0, i.state.partnershipRuns)
        val before = i
        expectFailure { before.next(Delivery(DeliveryType.NORMAL, 1)) }
        i = i.perform(Action.SetBatter(teamA.players[2].id, Slot.STRIKER))
        assertEquals(teamA.players[2].id, i.state.striker)
        expectFailure { i.perform(Action.SetBatter(teamA.players[0].id, Slot.NON_STRIKER)) } // slot not vacant
    }

    @Test fun runOutIsNotCreditedToBowlerAndCanDismissNonStriker() {
        val striker = teamA.players[0].id
        val non = teamA.players[1].id
        val i = opened().next(Delivery(DeliveryType.NORMAL, 1, WicketType.RUN_OUT, dismissed = non))
        assertEquals(0, i.state.bowlers[teamB.players[0].id]!!.wickets)
        assertEquals(WicketType.RUN_OUT, i.state.batters[non]!!.dismissal)
        assertEquals(striker, i.state.nonStriker) // crossed once, then non-striker out at the other end
        assertNull(i.state.striker)
        expectFailure { opened().next(Delivery(DeliveryType.NORMAL, 0, WicketType.BOWLED, dismissed = non)) }
    }

    @Test fun invalidDismissalsOnWideAndNoBallRejected() {
        expectFailure { opened().next(Delivery(DeliveryType.WIDE, 0, WicketType.CAUGHT)) }
        expectFailure { opened().next(Delivery(DeliveryType.NO_BALL, 0, WicketType.BOWLED)) }
        expectFailure { opened().next(Delivery(DeliveryType.NORMAL, 0, WicketType.RETIRED_OUT)) }
        val stumped = opened().next(Delivery(DeliveryType.WIDE, 0, WicketType.STUMPED))
        assertEquals(1, stumped.state.wickets)
        assertEquals(0, stumped.state.legalBalls)
        val ro = opened().next(Delivery(DeliveryType.NO_BALL, 0, WicketType.RUN_OUT))
        assertEquals(1, ro.state.wickets)
    }

    @Test fun retireOutCountsAsWicket() {
        val i = opened().perform(Action.RetireOut(teamA.players[1].id))
        assertEquals(1, i.state.wickets)
        assertNull(i.state.nonStriker)
        assertEquals(WicketType.RETIRED_OUT, i.state.batters[teamA.players[1].id]!!.dismissal)
    }

    @Test fun inningsEndsWhenAllOut() {
        var i = opened()
        for (k in 1..10) {
            i = i.next(Delivery(DeliveryType.NORMAL, 0, WicketType.BOWLED))
            if (k < 10) {
                val slot = if (i.state.striker == null) Slot.STRIKER else Slot.NON_STRIKER
                i = i.perform(Action.SetBatter(teamA.players[k + 1].id, slot))
            }
        }
        assertEquals(InningsStatus.ALL_OUT, i.status)
        assertEquals(10, i.state.wickets)
        expectFailure { i.perform(Action.Ball(Delivery())) }
    }

    @Test fun inningsEndsWhenOversComplete() {
        var i = opened(oneOver).next(Delivery(DeliveryType.WIDE))
        repeat(5) { i = i.runs(1) }
        assertEquals(InningsStatus.IN_PROGRESS, i.status)
        i = i.runs(1)
        assertEquals(InningsStatus.OVERS_COMPLETE, i.status)
        assertEquals(6, i.state.legalBalls)
        assertEquals(7, i.state.runs) // 1 wide + 6 singles
    }

    @Test fun runRateAndLastSix() {
        var i = opened()
        repeat(6) { i = i.runs(2) }
        assertEquals(12.0, i.currentRunRate, 0.0001)
        var j = opened()
        for (d in listOf(
            Delivery(DeliveryType.NORMAL, 1), Delivery(DeliveryType.WIDE), Delivery(DeliveryType.NORMAL, 4),
            Delivery(DeliveryType.NORMAL, 0), Delivery(DeliveryType.NORMAL, 6), Delivery(DeliveryType.NORMAL, 2),
            Delivery(DeliveryType.NORMAL, 3),
        )) j = j.next(d)
        assertEquals(listOf("Wd", "4", "0", "6", "2", "3"), j.lastSix)
    }

    @Test fun partnershipTracksRunsAndBalls() {
        var i = opened().runs(1).runs(4)
        assertEquals(5, i.state.partnershipRuns)
        assertEquals(2, i.state.partnershipBalls)
        i = i.next(Delivery(DeliveryType.WIDE))
        assertEquals(6, i.state.partnershipRuns)
        assertEquals(2, i.state.partnershipBalls)
    }

    @Test fun undoRemovesLastBallOnly() {
        val base = opened().runs(1)
        val after = base.runs(4)
        val undone = after.undoLastBall()
        assertEquals(1, undone.state.runs)
        assertEquals(1, undone.state.balls.size)
        assertEquals(base.state.striker, undone.state.striker)
        expectFailure { opened().undoLastBall() }
    }

    @Test fun editPreviousDeliveryReplaysScore() {
        val i = opened().runs(1).runs(1).runs(1)
        val edited = i.editBall(0, Delivery(DeliveryType.NORMAL, 4))
        assertEquals(6, edited.state.runs)
        assertEquals(3, edited.state.balls.size)
        assertEquals("4", edited.state.balls[0].label)
        expectFailure { i.editBall(5, Delivery()) }
    }

    @Test fun chaseInfoShowsTargetRemainingAndRequiredRate() {
        var i = opened(oneOver, teamB, teamA, target = 7).runs(4)
        val c = i.chase!!
        assertEquals(7, c.target)
        assertEquals(3, c.runsNeeded)
        assertEquals(5, c.ballsRemaining)
        assertEquals(3.6, c.requiredRate!!, 0.0001)
        i = i.runs(3)
        assertEquals(InningsStatus.TARGET_ACHIEVED, i.status)
    }

    @Test fun limitedOversMatchFlowAndResults() {
        var m = CricketMatch.create(oneOver, teamA, teamB)
        m = m.startNextInnings()
        var first = m.current!!
            .perform(Action.SetBatter(teamA.players[0].id, Slot.STRIKER))
            .perform(Action.SetBatter(teamA.players[1].id, Slot.NON_STRIKER))
        repeat(6) { first = first.runs(1) }
        m = m.updateCurrent(first)
        assertNull(m.result)
        m = m.startNextInnings()
        assertEquals(7, m.current!!.target)
        assertEquals(teamB.name, m.current!!.battingTeam.name)

        // chase succeeds
        var chase = m.current!!
            .perform(Action.SetBatter(teamB.players[0].id, Slot.STRIKER))
            .perform(Action.SetBatter(teamB.players[1].id, Slot.NON_STRIKER))
            .runs(4).runs(3)
        val won = m.updateCurrent(chase).result!!
        assertEquals(Side.B, won.winner)
        assertEquals("Bravo won by 10 wickets", won.text)

        // chase falls one short: tie
        chase = m.current!!
            .perform(Action.SetBatter(teamB.players[0].id, Slot.STRIKER))
            .perform(Action.SetBatter(teamB.players[1].id, Slot.NON_STRIKER))
        repeat(6) { chase = chase.runs(1) }
        val tie = m.updateCurrent(chase).result!!
        assertNull(tie.winner)
        assertEquals("Match tied", tie.text)

        // chase falls short: first team wins by runs
        chase = m.current!!
            .perform(Action.SetBatter(teamB.players[0].id, Slot.STRIKER))
            .perform(Action.SetBatter(teamB.players[1].id, Slot.NON_STRIKER))
        repeat(6) { chase = chase.runs(0) }
        val lost = m.updateCurrent(chase).result!!
        assertEquals(Side.A, lost.winner)
        assertEquals("Alpha won by 6 runs", lost.text)
    }

    @Test fun testMatchFourthInningsTarget() {
        val cfg = MatchConfig.forFormat(MatchFormat.TEST)
        var m = CricketMatch.create(cfg, teamA, teamB)
        val scores = listOf(4, 2, 6)
        for (k in scores.indices) {
            m = m.startNextInnings()
            val cur = m.current!!
            val bat = cur.battingTeam
            val inn = cur
                .perform(Action.SetBatter(bat.players[0].id, Slot.STRIKER))
                .perform(Action.SetBatter(bat.players[1].id, Slot.NON_STRIKER))
                .runs(scores[k])
                .perform(Action.Declare)
            assertEquals(InningsStatus.DECLARED, inn.status)
            m = m.updateCurrent(inn)
        }
        m = m.startNextInnings()
        assertEquals(4 + 6 - 2 + 1, m.current!!.target)
        assertEquals(teamB.name, m.current!!.battingTeam.name)
        assertNotNull(m.current!!.chase)
        assertNull(m.current!!.chase!!.ballsRemaining)
        expectFailure { opened().perform(Action.Declare) }
    }

    @Test fun cannotStartNextInningsWhileInProgress() {
        var m = CricketMatch.create(oneOver, teamA, teamB).startNextInnings()
        expectFailure { m.startNextInnings() }
        assertTrue(m.current!!.status == InningsStatus.IN_PROGRESS)
    }

    @Test fun mustSelectPlayersBeforeBall() {
        expectFailure { Innings.start(t20, teamA, teamB).perform(Action.Ball(Delivery())) }
        val noBowler = Innings.start(t20, teamA, teamB)
            .perform(Action.SetBatter(1, Slot.STRIKER)).perform(Action.SetBatter(2, Slot.NON_STRIKER))
        expectFailure { noBowler.perform(Action.Ball(Delivery())) }
        expectFailure { Innings.start(t20, teamA, teamB).perform(Action.SetBatter(999, Slot.STRIKER)) }
    }

    @Test fun hundredUsesFiveBallSetsAndChangesEndsEveryTenBalls() {
        val cfg = MatchConfig.forFormat(MatchFormat.THE_HUNDRED)
        var i = opened(cfg)
        repeat(5) { i = i.runs(0) }
        assertNull(i.state.bowler)              // set complete after 5 balls
        assertEquals(teamA.players[0].id, i.state.striker) // no end change yet
        i = i.perform(Action.SetBowler(teamB.players[0].id)) // same bowler may continue
        repeat(5) { i = i.runs(0) }
        assertEquals(teamA.players[1].id, i.state.striker) // ends change after 10
    }
}
