package com.zarvimo.livecricket.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import java.io.File

/** Size-limited cache of decoded images (backgrounds, logos), shared by the preview and the stream renderer. */
object MediaCache {
    private val cache = object : LruCache<String, Bitmap>(64 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun load(path: String, maxDim: Int): Bitmap? {
        val f = File(path)
        if (!f.exists()) return null
        val key = "$path@$maxDim@${f.lastModified()}"
        cache.get(key)?.let { return it }
        val bmp = decode(path, maxDim) ?: return null
        cache.put(key, bmp)
        return bmp
    }

    private fun decode(path: String, maxDim: Int): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxDim || bounds.outHeight / (sample * 2) >= maxDim) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull()

    fun clear() = cache.evictAll()
}
