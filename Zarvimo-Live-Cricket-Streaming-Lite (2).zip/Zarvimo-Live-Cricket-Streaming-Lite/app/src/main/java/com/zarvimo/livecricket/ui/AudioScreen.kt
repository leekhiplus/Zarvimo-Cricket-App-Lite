package com.zarvimo.livecricket.ui

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.zarvimo.livecricket.AppViewModel

/** Local preview of the selected music (phone speaker). The stream mixes the music itself in the engine. */
private class MusicPreview(private val audioManager: AudioManager) {
    private var player: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null
    var playing by mutableStateOf(false)
        private set

    fun play(path: String, loop: Boolean, volume: Float) {
        stop()
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setOnAudioFocusChangeListener { change -> if (change == AudioManager.AUDIOFOCUS_LOSS) stop() }
            .build()
        focus = req
        audioManager.requestAudioFocus(req)
        runCatching {
            player = MediaPlayer().apply {
                setDataSource(path)
                isLooping = loop
                setVolume(volume, volume)
                setOnCompletionListener { if (!isLooping) { this@MusicPreview.playing = false } }
                prepare()
                start()
            }
            playing = true
        }.onFailure { stop() }
    }

    fun pause() { runCatching { player?.pause() }; playing = false }
    fun resume() { runCatching { player?.start(); playing = player != null } }
    fun hasPlayer() = player != null
    fun setVolume(v: Float) { runCatching { player?.setVolume(v, v) } }
    fun setLoop(l: Boolean) { runCatching { player?.isLooping = l } }

    fun stop() {
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
        focus?.let { audioManager.abandonAudioFocusRequest(it) }
        focus = null
        playing = false
    }
}

@Composable
fun AudioScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val audio = vm.media.audio
    val preview = remember { MusicPreview(ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager) }
    DisposableEffect(Unit) { onDispose { preview.stop() } }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { preview.stop(); vm.importMusic(uri) }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.updateAudio { it.copy(micEnabled = true) }
        else { vm.updateAudio { it.copy(micEnabled = false) }; vm.message = "Microphone permission was denied. Commentary stays off." }
    }
    val micGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    ScreenScaffold("Audio Studio", onBack) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Background music", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(audio.musicName ?: "No music selected (MP3, WAV, AAC or M4A)")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { musicPicker.launch(arrayOf("audio/mpeg", "audio/wav", "audio/x-wav", "audio/aac", "audio/mp4", "audio/x-m4a", "audio/*")) }) {
                    Text(if (audio.musicPath == null) "Select" else "Replace")
                }
                if (audio.musicPath != null) TextButton(onClick = { preview.stop(); vm.removeMusic() }) { Text("Remove") }
            }
            if (audio.musicPath != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Button(onClick = {
                        if (preview.hasPlayer() && !preview.playing) preview.resume()
                        else preview.play(audio.musicPath, audio.loop, audio.musicVol / 100f)
                    }) { Text("Play") }
                    OutlinedButton(onClick = { preview.pause() }) { Text("Pause") }
                    OutlinedButton(onClick = { preview.stop() }) { Text("Stop") }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Loop", Modifier.weight(1f))
                Switch(checked = audio.loop, onCheckedChange = { on -> preview.setLoop(on); vm.updateAudio { it.copy(loop = on) } })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Mute music", Modifier.weight(1f))
                Switch(checked = audio.musicMuted, onCheckedChange = { on -> vm.updateAudio { it.copy(musicMuted = on) } })
            }
            Text("Music volume ${audio.musicVol}%")
            Slider(
                value = audio.musicVol.toFloat(),
                onValueChange = { v -> preview.setVolume(v / 100f); vm.updateAudio { it.copy(musicVol = v.toInt()) } },
                valueRange = 0f..100f,
            )
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Live commentary (microphone)", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Microphone on", Modifier.weight(1f))
                Switch(
                    checked = audio.micEnabled && micGranted,
                    onCheckedChange = { on ->
                        if (on && !micGranted) micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        else vm.updateAudio { it.copy(micEnabled = on) }
                    },
                )
            }
            Text("Microphone volume ${audio.micVol}%")
            Slider(
                value = audio.micVol.toFloat(),
                onValueChange = { v -> vm.updateAudio { it.copy(micVol = v.toInt()) } },
                valueRange = 0f..100f,
            )
            Text(
                "Music and microphone are mixed into the live stream. Use headphones while testing to avoid echo. " +
                    "Music and microphone volumes are separate and can be changed while live.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}
