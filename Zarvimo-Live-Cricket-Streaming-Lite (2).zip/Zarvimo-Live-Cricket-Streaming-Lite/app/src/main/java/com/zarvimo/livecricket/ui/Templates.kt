package com.zarvimo.livecricket.ui

import androidx.compose.ui.graphics.Color

enum class BoardLayout { BAR, CARD }

data class TemplateStyle(
    val name: String,
    val panel: Color,
    val panelAlt: Color,
    val accent: Color,
    val text: Color,
    val sub: Color,
    val layout: BoardLayout,
)

/** The 10 scoreboard templates. All render from the same [ScoreboardData]. */
val Templates = listOf(
    TemplateStyle("Blue Classic", Color(0xFF0D2B5E), Color(0xFF14418F), Color(0xFF4DA3FF), Color.White, Color(0xFFB8C7E0), BoardLayout.BAR),
    TemplateStyle("Neon Dark", Color(0xFF0A0A12), Color(0xFF14142B), Color(0xFF00F0FF), Color.White, Color(0xFF8E9BB5), BoardLayout.CARD),
    TemplateStyle("Green Pro", Color(0xFF0B3D2E), Color(0xFF14634A), Color(0xFF3DDC84), Color.White, Color(0xFFB7DCCB), BoardLayout.BAR),
    TemplateStyle("Red Sports", Color(0xFF5A0F14), Color(0xFF8E1B22), Color(0xFFFF4D4D), Color.White, Color(0xFFF0C4C6), BoardLayout.BAR),
    TemplateStyle("White Minimal", Color(0xFFFFFFFF), Color(0xFFEDEFF3), Color(0xFF1D4ED8), Color(0xFF111827), Color(0xFF6B7280), BoardLayout.CARD),
    TemplateStyle("Purple Night", Color(0xFF1E0F3D), Color(0xFF35206B), Color(0xFFB388FF), Color.White, Color(0xFFCDBBEA), BoardLayout.CARD),
    TemplateStyle("Orange Pro", Color(0xFF3A1A00), Color(0xFF7A3A00), Color(0xFFFF9800), Color.White, Color(0xFFF2D2A8), BoardLayout.BAR),
    TemplateStyle("Silver Elite", Color(0xFF2B2F36), Color(0xFF454B55), Color(0xFFC9D1DC), Color.White, Color(0xFFAAB2BF), BoardLayout.CARD),
    TemplateStyle("TV Broadcast", Color(0xFF101820), Color(0xFF1B2733), Color(0xFFFFC107), Color.White, Color(0xFF9FB0C0), BoardLayout.BAR),
    TemplateStyle("Mobile Vertical", Color(0xFF0B1220), Color(0xFF1A2438), Color(0xFF3B82F6), Color.White, Color(0xFF9DB0CF), BoardLayout.CARD),
)

