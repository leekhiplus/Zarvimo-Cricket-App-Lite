package com.zarvimo.livecricket.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Blue = Color(0xFF1E7BFF)
    val Green = Color(0xFF1DB954)
    val Red = Color(0xFFD32F2F)
    val Orange = Color(0xFFFF9F1C)
    val Yellow = Color(0xFFFFD21F)
}

private val DarkColors = darkColorScheme(
    primary = Palette.Blue,
    background = Color(0xFF050B1F),
    surface = Color(0xFF0E1B40),
    surfaceVariant = Color(0xFF16275A),
    onBackground = Color.White,
    onSurface = Color.White,
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1D4ED8),
    background = Color(0xFFF4F6FB),
    surface = Color.White,
)

@Composable
fun ZarvimoTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, content = content)
}
