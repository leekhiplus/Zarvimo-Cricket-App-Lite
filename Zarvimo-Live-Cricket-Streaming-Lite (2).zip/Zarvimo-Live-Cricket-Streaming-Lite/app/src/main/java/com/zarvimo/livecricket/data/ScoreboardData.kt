package com.zarvimo.livecricket.data

import com.zarvimo.livecricket.engine.CricketMatch
import com.zarvimo.livecricket.engine.Side
import com.zarvimo.livecricket.engine.Team
import java.util.Locale

/** Everything a scoreboard template needs, derived from the match. Shared by preview and (later) the stream. */
data class ScoreboardData(
    val title: String,
    val inningsLabel: String,
    val battingName: String,
    val battingCode: String?,
    val battingLogo: String?,
    val bowlingName: String,
    val bowlingCode: String?,
    val bowlingLogo: String?,
    val runs: Int,
    val wickets: Int,
    val overs: String,
    val crr: String,
    val rrr: String?,
    val target: Int?,
    val needText: String?,
    val striker: String,
    val strikerStat: String,
    val nonStriker: String,
    val nonStrikerStat: String,
    val bowler: String,
    val bowlerStat: String,
    val lastSix: List<String>,
) {
    companion object {
        private fun ordinal(n: Int) = when (n) { 1 -> "1st"; 2 -> "2nd"; 3 -> "3rd"; else -> "${n}th" }

        fun from(meta: SavedMatch, m: CricketMatch): ScoreboardData {
            val idx = m.innings.size - 1
            val inn = m.innings[idx]
            val batSide = m.battingSide(idx)
            val batInfo = if (batSide == Side.A) meta.teamA else meta.teamB
            val bowlInfo = if (batSide == Side.A) meta.teamB else meta.teamA
            val s = inn.state
            fun nameOf(team: Team, id: Int?): String = team.players.firstOrNull { it.id == id }?.name ?: "-"
            fun batStat(id: Int?): String = id?.let { s.batters[it] }?.let { "${it.runs} (${it.balls})" } ?: ""
            val bowlerStat = s.bowler?.let { s.bowlers[it] }?.let {
                "${it.wickets}/${it.runs} (${it.legalBalls / inn.config.ballsPerOver}.${it.legalBalls % inn.config.ballsPerOver})"
            } ?: ""
            val chase = inn.chase
            return ScoreboardData(
                title = meta.title,
                inningsLabel = "${ordinal(idx + 1)} innings",
                battingName = inn.battingTeam.name,
                battingCode = batInfo.countryCode,
                battingLogo = batInfo.logoPath,
                bowlingName = inn.bowlingTeam.name,
                bowlingCode = bowlInfo.countryCode,
                bowlingLogo = bowlInfo.logoPath,
                runs = s.runs,
                wickets = s.wickets,
                overs = inn.oversText,
                crr = String.format(Locale.US, "%.2f", inn.currentRunRate),
                rrr = chase?.requiredRate?.let { String.format(Locale.US, "%.2f", it) },
                target = chase?.target,
                needText = chase?.let { c ->
                    if (c.ballsRemaining != null) "Need ${c.runsNeeded} off ${c.ballsRemaining}" else "Need ${c.runsNeeded} runs"
                },
                striker = nameOf(inn.battingTeam, s.striker) + if (s.striker != null) "*" else "",
                strikerStat = batStat(s.striker),
                nonStriker = nameOf(inn.battingTeam, s.nonStriker),
                nonStrikerStat = batStat(s.nonStriker),
                bowler = nameOf(inn.bowlingTeam, s.bowler),
                bowlerStat = bowlerStat,
                lastSix = inn.lastSix,
            )
        }

        fun sample() = ScoreboardData(
            title = "Zarvimo Cup Final", inningsLabel = "2nd innings",
            battingName = "Pakistan", battingCode = "PK", battingLogo = null,
            bowlingName = "India", bowlingCode = "IN", bowlingLogo = null,
            runs = 142, wickets = 3, overs = "16.2", crr = "8.69", rrr = "9.89",
            target = 180, needText = "Need 38 off 22",
            striker = "Babar Azam*", strikerStat = "64 (41)", nonStriker = "M. Rizwan", nonStrikerStat = "31 (22)",
            bowler = "J. Bumrah", bowlerStat = "1/24 (3.2)",
            lastSix = listOf("1", "4", "Wd", "0", "6", "W"),
        )
    }
}
