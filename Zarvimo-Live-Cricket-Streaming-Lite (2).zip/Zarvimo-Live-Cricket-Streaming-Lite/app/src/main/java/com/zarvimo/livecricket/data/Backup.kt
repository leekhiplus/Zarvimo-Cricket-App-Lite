package com.zarvimo.livecricket.data

import android.content.Context
import android.net.Uri
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Local backup/restore of saved matches, saved teams and stream settings (never the stream key or media files). */
object Backup {
    fun export(ctx: Context, store: Store, out: Uri): Int {
        var count = 0
        ctx.contentResolver.openOutputStream(out)?.use { os ->
            ZipOutputStream(os).use { zip ->
                for (f in store.matchFiles()) {
                    zip.putNextEntry(ZipEntry("matches/${f.name}"))
                    zip.write(f.readBytes())
                    zip.closeEntry()
                    count++
                }
                store.rawTeams()?.let {
                    zip.putNextEntry(ZipEntry("teams.json")); zip.write(it.toByteArray()); zip.closeEntry()
                }
                zip.putNextEntry(ZipEntry("stream.json"))
                zip.write(MediaJson.streamToJson(store.loadStream()).toByteArray())
                zip.closeEntry()
            }
        } ?: error("Cannot write the backup file")
        return count
    }

    fun restore(ctx: Context, store: Store, input: Uri): Int {
        var count = 0
        ctx.contentResolver.openInputStream(input)?.use { ins ->
            ZipInputStream(ins).use { zip ->
                while (true) {
                    val e = zip.nextEntry ?: break
                    val bytes = zip.readBytes()
                    when {
                        e.name.startsWith("matches/") && e.name.endsWith(".json") -> {
                            val name = e.name.substringAfterLast('/')
                            if (name.matches(Regex("[A-Za-z0-9._-]+"))) {
                                // validate before accepting
                                MatchJson.fromJson(String(bytes))
                                java.io.File(store.matchDir(), name).writeBytes(bytes)
                                count++
                            }
                        }
                        e.name == "teams.json" -> store.setRawTeams(String(bytes))
                        e.name == "stream.json" -> runCatching { store.saveStream(MediaJson.streamFromJson(String(bytes))) }
                    }
                    zip.closeEntry()
                }
            }
        } ?: error("Cannot read the backup file")
        return count
    }
}
