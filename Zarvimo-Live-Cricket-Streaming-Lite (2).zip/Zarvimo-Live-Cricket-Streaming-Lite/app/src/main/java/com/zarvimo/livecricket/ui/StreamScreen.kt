package com.zarvimo.livecricket.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.zarvimo.livecricket.AppViewModel
import com.zarvimo.livecricket.stream.StreamConfig
import com.zarvimo.livecricket.stream.StreamController
import com.zarvimo.livecricket.stream.StreamProfiles
import com.zarvimo.livecricket.stream.StreamService
import com.zarvimo.livecricket.stream.StreamStatus

private fun hms(sec: Long): String = "%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60)

@Composable
fun StreamScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var showKey by remember { mutableStateOf(false) }
    val portrait = vm.stream.portrait
    val profiles = remember(portrait) { StreamProfiles.supported(portrait) }
    val running = StreamStatus.running

    LaunchedEffect(profiles) {
        if (profiles.isNotEmpty() && profiles.none { it.label == vm.resolution }) vm.updateResolution(profiles.first().label)
    }

    fun beginConnect() {
        val p = StreamProfiles.byLabel(vm.resolution)
        val fps = vm.stream.fps
        StreamController.config = StreamConfig(
            url = vm.rtmpUrl,
            key = vm.streamKey,
            width = StreamProfiles.width(p, portrait),
            height = StreamProfiles.height(p, portrait),
            fps = fps,
            videoBps = StreamProfiles.videoBitrateBps(p, vm.stream.videoKbps, fps),
            audioBps = vm.stream.audioKbps * 1000,
        )
        val snapshotPortrait = portrait
        StreamController.renderProvider = { vm.renderState(snapshotPortrait, vm.templateIndex, null) }
        StreamController.audioProvider = { vm.media.audio }
        ContextCompat.startForegroundService(ctx, Intent(ctx, StreamService::class.java).setAction(StreamService.ACTION_START))
    }

    val permissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.RECORD_AUDIO] == false) vm.message = "Microphone permission denied: streaming without commentary."
        beginConnect()
    }

    fun connect() {
        if (vm.rtmpUrl.isBlank() || !vm.rtmpUrl.startsWith("rtmp")) { vm.message = "Enter a valid RTMP URL (rtmp://...)."; return }
        if (vm.streamKey.isBlank()) { vm.message = "Enter your YouTube stream key."; return }
        if (profiles.isEmpty()) { vm.message = "This device cannot encode H.264 video at the supported sizes."; return }
        val needed = mutableListOf<String>()
        if (vm.media.audio.micEnabled &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isEmpty()) beginConnect() else permissions.launch(needed.toTypedArray())
    }

    ScreenScaffold("YouTube Streaming", onBack) {
        Text("RTMP URL", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = vm.rtmpUrl, onValueChange = { vm.updateRtmpUrl(it) }, singleLine = true,
            enabled = !running, modifier = Modifier.fillMaxWidth(),
        )
        Text("Stream Key", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = vm.streamKey, onValueChange = { vm.updateStreamKey(it) }, singleLine = true, enabled = !running,
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") } },
            modifier = Modifier.fillMaxWidth(),
        )
        Text("The key is stored encrypted with the Android Keystore and is never logged.", fontSize = 12.sp)

        Text("Orientation", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !portrait, enabled = !running, onClick = { vm.updateStream { it.copy(portrait = false) } }, label = { Text("Landscape") })
            FilterChip(selected = portrait, enabled = !running, onClick = { vm.updateStream { it.copy(portrait = true) } }, label = { Text("Portrait") })
        }
        Text("Resolution", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StreamProfiles.all.forEach { p ->
                val ok = profiles.any { it.label == p.label }
                FilterChip(
                    selected = vm.resolution == p.label, enabled = ok && !running,
                    onClick = { vm.updateResolution(p.label) }, label = { Text(p.label) },
                )
            }
        }
        Text("Frames per second", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(24, 30).forEach { f ->
                FilterChip(selected = vm.stream.fps == f, enabled = !running, onClick = { vm.updateStream { it.copy(fps = f) } }, label = { Text("$f") })
            }
        }
        Text("Video bitrate (kbps)", fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0, 1500, 2500, 4000, 6000).forEach { k ->
                FilterChip(
                    selected = vm.stream.videoKbps == k, enabled = !running,
                    onClick = { vm.updateStream { it.copy(videoKbps = k) } }, label = { Text(if (k == 0) "Auto" else "$k") },
                )
            }
        }
        Text("Audio bitrate (kbps)", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(96, 128, 192).forEach { k ->
                FilterChip(selected = vm.stream.audioKbps == k, enabled = !running, onClick = { vm.updateStream { it.copy(audioKbps = k) } }, label = { Text("$k") })
            }
        }

        val state = StreamStatus.state
        val color = when {
            StreamStatus.error != null && state == "Error" -> Color(0xFFE53935)
            state == "Live" || state == "Connected" -> Palette.Green
            state in setOf("Connecting", "Reconnecting", "Preparing", "Starting", "Network lost, waiting") -> Palette.Orange
            else -> Color(0xFF9AA5BD)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("\u25CF", color = color, fontSize = 18.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    when (state) {
                        "Connected" -> "Connected to YouTube"
                        "Live" -> "Live"
                        else -> state
                    },
                    fontWeight = FontWeight.Bold,
                )
            }
            StreamStatus.error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp) }
            Spacer(Modifier.height(6.dp))
            Text("Live Time: ${hms(StreamStatus.elapsedSec)}", fontSize = 13.sp)
            Text("Bitrate: ${StreamStatus.bitrateKbps} kbps    Frame rate: ${StreamStatus.fps} fps    Dropped: ${StreamStatus.dropped}", fontSize = 13.sp)
        }

        PrimaryButton("Connect", Palette.Blue, enabled = !running) { connect() }
        PrimaryButton("Start Live", Palette.Red, enabled = StreamStatus.connected && !StreamStatus.live) {
            StreamController.engine?.goLive()
        }
        PrimaryButton("Stop", Color(0xFF3A4A7A), enabled = running) {
            ctx.startService(Intent(ctx, StreamService::class.java).setAction(StreamService.ACTION_STOP))
        }
        Text(
            "Connect opens the RTMP session. Start Live then sends the scoreboard picture and mixed audio. " +
                "In YouTube Studio press Go Live when the stream preview appears. Scoring keeps working if the connection drops.",
            fontSize = 12.sp,
        )
    }
}
