package com.zarvimo.livecricket.render

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import com.zarvimo.livecricket.data.BgSettings
import com.zarvimo.livecricket.data.Countries
import com.zarvimo.livecricket.data.MediaCache
import com.zarvimo.livecricket.data.MediaSettings
import com.zarvimo.livecricket.data.ScoreboardData
import com.zarvimo.livecricket.ui.BoardLayout
import com.zarvimo.livecricket.ui.TemplateStyle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Everything needed to draw one frame. The preview and the RTMP encoder both draw this same state. */
class RenderState(
    val data: ScoreboardData,
    val style: TemplateStyle,
    val portrait: Boolean,
    val media: MediaSettings,
)

/**
 * Single rendering pipeline for the broadcast picture (background, scoreboard, branding).
 * It draws with android.graphics only, so the same code feeds the on-screen preview (software Canvas)
 * and the video encoder (hardware Canvas on the encoder input Surface).
 * Layout units: the frame is a 160x90 grid in landscape and a 90x160 grid in portrait.
 */
class BoardPainter(private val ctx: Context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val src = Rect()
    private val path = Path()

    private var lastRuns = -1
    private var prevRuns = 0
    private var animStart = 0L

    fun draw(c: Canvas, w: Int, h: Int, st: RenderState) {
        val now = SystemClock.uptimeMillis()
        if (st.data.runs != lastRuns) {
            prevRuns = if (lastRuns < 0) st.data.runs else lastRuns
            lastRuns = st.data.runs
            animStart = now
        }
        val prog = if (prevRuns == st.data.runs) 1f else ((now - animStart) / 350f).coerceIn(0f, 1f)

        drawBackground(c, w, h, if (st.portrait) st.media.bgPortrait else st.media.bgLandscape)
        if (st.portrait) {
            val u = w / 90f
            card(c, u, 5f * u, 5f * u, 80f * u, 80f / 62f, st, prog)
        } else {
            val u = w / 160f
            if (st.style.layout == BoardLayout.BAR) bar(c, w, h, u, st, prog)
            else card(c, u, 4f * u, 4f * u, 62f * u, 1f, st, prog)
        }
        drawBranding(c, w, h, st)
    }

    // ---------------------------------------------------------------- background

    private fun drawBackground(c: Canvas, w: Int, h: Int, bg: BgSettings) {
        when {
            bg.style == "custom" && bg.path != null -> {
                val bmp = MediaCache.load(bg.path, 1920)
                if (bmp != null) drawCustomBackground(c, w, h, bmp, bg) else stadium(c, w, h)
            }
            bg.style == "dark" -> gradient(c, w, h, 0xFF05070F.toInt(), 0xFF141E3A.toInt())
            bg.style == "light" -> gradient(c, w, h, 0xFFF4F6FB.toInt(), 0xFFD5DCEC.toInt())
            else -> stadium(c, w, h)
        }
    }

    private fun gradient(c: Canvas, w: Int, h: Int, top: Int, bottom: Int) {
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = null
    }

    private fun stadium(c: Canvas, w: Int, h: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        p.shader = LinearGradient(
            0f, 0f, 0f, hf,
            intArrayOf(0xFF071235.toInt(), 0xFF123A7A.toInt(), 0xFF1F7A3A.toInt(), 0xFF0E4A25.toInt()),
            floatArrayOf(0f, 0.5f, 0.52f, 1f), Shader.TileMode.CLAMP,
        )
        c.drawRect(0f, 0f, wf, hf, p)
        val r = wf * 0.28f
        for (fx in floatArrayOf(0.12f, 0.88f)) {
            val cx = wf * fx
            val cy = hf * 0.1f
            p.shader = RadialGradient(cx, cy, r, 0xDDFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p)
        }
        p.shader = null
        path.reset()
        path.moveTo(wf * 0.46f, hf * 0.55f)
        path.lineTo(wf * 0.54f, hf * 0.55f)
        path.lineTo(wf * 0.66f, hf)
        path.lineTo(wf * 0.34f, hf)
        path.close()
        p.color = 0x33FFFFFF
        c.drawPath(path, p)
    }

    private fun drawCustomBackground(c: Canvas, w: Int, h: Int, bmp: Bitmap, bg: BgSettings) {
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        val base = if (bg.fit == "fit") min(w / bw, h / bh) else max(w / bw, h / bh)
        val s = base * bg.zoom.coerceIn(0.5f, 4f)
        val dw = bw * s
        val dh = bh * s
        val rx = abs(dw - w) / 2f
        val ry = abs(dh - h) / 2f
        val x = (w - dw) / 2f + bg.offX.coerceIn(-1f, 1f) * rx
        val y = (h - dh) / 2f + bg.offY.coerceIn(-1f, 1f) * ry
        if (bg.fit == "fit" || dw < w || dh < h) c.drawColor(0xFF05070F.toInt())
        rect.set(x, y, x + dw, y + dh)
        c.drawBitmap(bmp, null, rect, bmpPaint)
    }

    // ---------------------------------------------------------------- branding (logo + watermark)

    private fun drawBranding(c: Canvas, w: Int, h: Int, st: RenderState) {
        val lg = st.media.logo
        if (!lg.visible) return
        val margin = min(w, h) * 0.03f
        val left = lg.corner.endsWith("LEFT")
        val top = lg.corner.startsWith("TOP")
        var blockBottomOrTop = if (top) margin else h - margin

        val bmp = lg.path?.let { MediaCache.load(it, 512) }
        if (bmp != null) {
            val lw = w * lg.sizePct.coerceIn(3, 40) / 100f
            var lh = lw * bmp.height / bmp.width
            var lw2 = lw
            val maxH = h * 0.3f
            if (lh > maxH) { lw2 = lw * maxH / lh; lh = maxH }
            val x = if (left) margin else w - margin - lw2
            val y = if (top) margin else h - margin - lh
            rect.set(x, y, x + lw2, y + lh)
            bmpPaint.alpha = (lg.opacity.coerceIn(0, 100) * 255 / 100)
            c.drawBitmap(bmp, null, rect, bmpPaint)
            bmpPaint.alpha = 255
            blockBottomOrTop = if (top) y + lh + margin * 0.4f else y - margin * 0.4f
        }

        val mark = lg.watermark.trim()
        if (mark.isNotEmpty()) {
            val size = min(w, h) * 0.04f
            tp.textSize = size
            tp.typeface = Typeface.DEFAULT_BOLD
            tp.color = Color.WHITE
            tp.alpha = (lg.opacity.coerceIn(0, 100) * 255 / 100)
            tp.setShadowLayer(size * 0.15f, 0f, 0f, 0xFF000000.toInt())
            val maxW = w * 0.4f
            val shown = TextUtils.ellipsize(mark, tp, maxW, TextUtils.TruncateAt.END).toString()
            val tw = tp.measureText(shown)
            val x = if (left) margin else w - margin - tw
            val topY = if (top) blockBottomOrTop else blockBottomOrTop - size * 1.2f
            c.drawText(shown, x, topY - tp.ascent(), tp)
            tp.clearShadowLayer()
            tp.alpha = 255
        }
    }

    // ---------------------------------------------------------------- scoreboard primitives

    private fun withAlpha(color: Int, a: Float): Int =
        (color and 0x00FFFFFF) or ((255 * a.coerceIn(0f, 1f)).toInt() shl 24)

    private fun onAccent(s: TemplateStyle): Int =
        if (s.accent.luminance() > 0.5f) Color.BLACK else Color.WHITE

    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT, maxW: Float = Float.MAX_VALUE,
    ) {
        tp.textSize = size
        tp.color = color
        tp.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        tp.textAlign = align
        val out = if (maxW < Float.MAX_VALUE) TextUtils.ellipsize(s, tp, max(maxW, 1f), TextUtils.TruncateAt.END).toString() else s
        c.drawText(out, x, y - tp.ascent(), tp)
    }

    private fun measure(s: String, size: Float, bold: Boolean): Float {
        tp.textSize = size
        tp.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        return tp.measureText(s)
    }

    private fun rrect(c: Canvas, l: Float, t: Float, r: Float, b: Float, tl: Float, tr: Float, br: Float, bl: Float, color: Int) {
        rect.set(l, t, r, b)
        path.reset()
        path.addRoundRect(rect, floatArrayOf(tl, tl, tr, tr, br, br, bl, bl), Path.Direction.CW)
        p.color = color
        c.drawPath(path, p)
    }

    private fun rule(c: Canvas, l: Float, r: Float, y: Float, s: Float, color: Int) {
        p.color = withAlpha(color, 0.3f)
        c.drawRect(l, y, r, y + max(1f, 0.3f * s), p)
    }

    private fun badge(c: Canvas, code: String?, logo: String?, x: Float, y: Float, hh: Float, fallback: String): Float {
        val lb = logo?.let { MediaCache.load(it, 256) }
        if (lb != null) {
            val side = min(lb.width, lb.height)
            src.set((lb.width - side) / 2, (lb.height - side) / 2, (lb.width + side) / 2, (lb.height + side) / 2)
            rect.set(x, y, x + hh, y + hh)
            c.save()
            path.reset()
            path.addCircle(x + hh / 2, y + hh / 2, hh / 2, Path.Direction.CW)
            c.clipPath(path)
            c.drawBitmap(lb, src, rect, bmpPaint)
            c.restore()
            return hh
        }
        val fb = code?.let { Countries.flagBitmap(ctx, it) }
        if (fb != null) {
            val bw = hh * fb.width / fb.height
            rect.set(x, y, x + bw, y + hh)
            c.drawBitmap(fb, null, rect, bmpPaint)
            return bw
        }
        p.color = 0xFF3B82F6.toInt()
        c.drawCircle(x + hh / 2, y + hh / 2, hh / 2, p)
        text(c, fallback.trim().take(1).uppercase(), x + hh / 2, y + hh * 0.22f, hh * 0.5f, Color.WHITE, true, Paint.Align.CENTER)
        return hh
    }

    private fun chipColor(l: String): Int = when {
        l.endsWith("W") -> 0xFFE53935.toInt()
        l == "4" -> 0xFF1E88E5.toInt()
        l == "6" -> 0xFF2E7D32.toInt()
        l.startsWith("Wd") || l.startsWith("Nb") -> 0xFFF57C00.toInt()
        else -> 0xFF546E7A.toInt()
    }

    private fun chips(c: Canvas, labels: List<String>, anchorX: Float, y: Float, s: Float, rightAlign: Boolean) {
        if (labels.isEmpty()) return
        val h = 4.6f * s
        val gap = 1f * s
        val widths = labels.map { max(5f * s, measure(it, 2.4f * s, true) + 1.8f * s) }
        val total = widths.sum() + gap * (labels.size - 1)
        var x = if (rightAlign) anchorX - total else anchorX
        labels.forEachIndexed { i, l ->
            rrect(c, x, y, x + widths[i], y + h, h / 2, h / 2, h / 2, h / 2, chipColor(l))
            text(c, l, x + widths[i] / 2, y + (h - 2.4f * s * 1.17f) / 2, 2.4f * s, Color.WHITE, true, Paint.Align.CENTER)
            x += widths[i] + gap
        }
    }

    /** Animated "runs/wickets". Returns total width. [anchorX] is the left, centre or right edge per [align]. */
    private fun score(c: Canvas, anchorX: Float, y: Float, size: Float, d: ScoreboardData, st: TemplateStyle, prog: Float, align: Paint.Align): Float {
        val runsStr = d.runs.toString()
        val slash = "/${d.wickets}"
        val rw = measure(runsStr, size, true)
        val sw = measure(slash, size * 0.6f, false)
        val total = rw + sw
        val x0 = when (align) {
            Paint.Align.RIGHT -> anchorX - total
            Paint.Align.CENTER -> anchorX - total / 2
            else -> anchorX
        }
        val textColor = st.text.toArgb()
        if (prog < 1f) {
            val shift = size * 0.6f
            text(c, prevRuns.toString(), x0, y - prog * shift, size, withAlpha(textColor, 1f - prog), true)
            text(c, runsStr, x0, y + (1f - prog) * shift, size, withAlpha(textColor, prog), true)
        } else {
            text(c, runsStr, x0, y, size, textColor, true)
        }
        text(c, slash, x0 + rw, y + size * 0.38f, size * 0.6f, st.sub.toArgb())
        return total
    }

    private fun playerLine(c: Canvas, left: Float, right: Float, y: Float, size: Float, name: String, stat: String, bold: Boolean, color: Int) {
        val sw = measure(stat, size, bold)
        text(c, name, left, y, size, color, bold, maxW = right - left - sw - size * 0.6f)
        text(c, stat, right, y, size, color, bold, Paint.Align.RIGHT)
    }

    // ---------------------------------------------------------------- layouts

    private fun bar(c: Canvas, w: Int, h: Int, u: Float, st: RenderState, prog: Float) {
        val d = st.data
        val sty = st.style
        val textC = sty.text.toArgb()
        val sub = sty.sub.toArgb()
        val accent = sty.accent.toArgb()
        val left = 4f * u
        val right = w - 4f * u
        val bottom = h - 4f * u
        val panelH = 18f * u
        val top = bottom - panelH
        val stripH = 4.8f * u

        val title = d.title.uppercase() + "  \u2022  " + d.inningsLabel
        val stripW = min(measure(title, 3f * u, true) + 5f * u, (right - left) * 0.7f)
        rrect(c, left, top - stripH, left + stripW, top, 2f * u, 2f * u, 0f, 0f, accent)
        text(c, title, left + 2.5f * u, top - stripH + 0.9f * u, 3f * u, onAccent(sty), true, maxW = stripW - 5f * u)
        rrect(c, left, top, right, bottom, 0f, 2f * u, 2f * u, 2f * u, withAlpha(sty.panel.toArgb(), 0.95f))

        val pad = 2.5f * u
        val unit = (right - left - 2 * pad) / 4.9f
        var x = left + pad
        val midY = top + panelH / 2

        // column 1: team
        val w1 = unit * 1.3f
        val bw = badge(c, d.battingCode, d.battingLogo, x, midY - 4.5f * u, 9f * u, d.battingName)
        text(c, d.battingName, x + bw + 2f * u, midY - 5.4f * u, 5f * u, textC, true, maxW = w1 - bw - 2.5f * u)
        text(c, "vs ${d.bowlingName}", x + bw + 2f * u, midY + 1.2f * u, 2.8f * u, sub, maxW = w1 - bw - 2.5f * u)
        x += w1

        // column 2: score
        val w2 = unit
        score(c, x + w2 / 2, midY - 8f * u, 11f * u, d, sty, prog, Paint.Align.CENTER)
        text(c, "(${d.overs} ov)", x + w2 / 2, midY + 5.6f * u, 3.4f * u, sub, align = Paint.Align.CENTER, maxW = w2)
        x += w2

        // column 3: batters + bowler
        val w3 = unit * 1.5f - 1f * u
        playerLine(c, x, x + w3, midY - 6.2f * u, 3.4f * u, d.striker, d.strikerStat, true, textC)
        playerLine(c, x, x + w3, midY - 2.3f * u, 3.4f * u, d.nonStriker, d.nonStrikerStat, false, textC)
        playerLine(c, x, x + w3, midY + 1.6f * u, 3.4f * u, d.bowler, d.bowlerStat, false, textC)
        x += unit * 1.5f + 1f * u

        // column 4: rates + last six
        val xr = right - pad
        val w4 = unit * 1.1f
        text(c, "CRR ${d.crr}", xr, top + 1.4f * u, 3.4f * u, textC, true, Paint.Align.RIGHT, w4)
        d.rrr?.let { text(c, "RRR $it", xr, top + 5.4f * u, 3.4f * u, accent, true, Paint.Align.RIGHT, w4) }
        d.needText?.let { text(c, it, xr, top + 9.2f * u, 3f * u, sub, align = Paint.Align.RIGHT, maxW = w4) }
        chips(c, d.lastSix, xr, bottom - pad - 4.6f * u, u, true)
    }

    private fun card(c: Canvas, u: Float, x0: Float, y0: Float, cw: Float, k: Float, st: RenderState, prog: Float) {
        val s = u * k
        val d = st.data
        val sty = st.style
        val textC = sty.text.toArgb()
        val sub = sty.sub.toArgb()
        val accent = sty.accent.toArgb()
        val pad = 2.5f * s
        val stripH = 4.4f * s
        val hasNeed = d.needText != null
        val bodyH = pad + 9f * s + 4f * s + (if (hasNeed) 4.2f * s else 0f) + 2.5f * s + 12f * s + 2f * s + 5f * s + pad

        val title = d.title.uppercase() + "  \u2022  " + d.inningsLabel
        rrect(c, x0, y0, x0 + cw, y0 + stripH, 2f * s, 2f * s, 0f, 0f, accent)
        text(c, title, x0 + 2.5f * s, y0 + 0.7f * s, 2.8f * s, onAccent(sty), true, maxW = cw - 5f * s)
        val top = y0 + stripH
        rrect(c, x0, top, x0 + cw, top + bodyH, 0f, 0f, 2f * s, 2f * s, withAlpha(sty.panel.toArgb(), 0.95f))

        val left = x0 + pad
        val right = x0 + cw - pad
        var y = top + pad

        val bw = badge(c, d.battingCode, d.battingLogo, left, y, 7f * s, d.battingName)
        val scoreW = score(c, right, y - 0.5f * s, 8.5f * s, d, sty, prog, Paint.Align.RIGHT)
        text(c, d.battingName, left + bw + 2f * s, y + 1f * s, 4.6f * s, textC, true, maxW = right - left - bw - 2f * s - scoreW - 2f * s)
        y += 9f * s

        text(c, "Overs ${d.overs}", left, y, 3f * s, sub)
        text(c, "CRR ${d.crr}", (left + right) / 2, y, 3f * s, sub, align = Paint.Align.CENTER)
        d.rrr?.let { text(c, "RRR $it", right, y, 3f * s, accent, true, Paint.Align.RIGHT) }
        y += 4f * s
        d.needText?.let {
            text(c, it, left, y, 3.2f * s, accent, true, maxW = right - left)
            y += 4.2f * s
        }
        y += 0.5f * s
        rule(c, left, right, y, s, sty.sub.toArgb())
        y += 2f * s

        playerLine(c, left, right, y, 3.2f * s, d.striker, d.strikerStat, true, textC)
        y += 4f * s
        playerLine(c, left, right, y, 3.2f * s, d.nonStriker, d.nonStrikerStat, false, textC)
        y += 4f * s
        playerLine(c, left, right, y, 3.2f * s, d.bowler, d.bowlerStat, false, textC)
        y += 4f * s

        y += 0.5f * s
        rule(c, left, right, y, s, sty.sub.toArgb())
        y += 1.5f * s
        chips(c, d.lastSix, left, y, s, false)
    }
}
