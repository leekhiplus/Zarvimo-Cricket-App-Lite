package com.zarvimo.livecricket.stream

import com.zarvimo.livecricket.data.AudioSettings
import com.zarvimo.livecricket.render.RenderState

data class StreamConfig(
    val url: String,
    val key: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val videoBps: Int,
    val audioBps: Int,
)

/** Hand-over point between the UI process state and the foreground service. */
object StreamController {
    @Volatile var config: StreamConfig? = null
    @Volatile var renderProvider: (() -> RenderState)? = null
    @Volatile var audioProvider: (() -> AudioSettings)? = null
    @Volatile var engine: StreamEngine? = null

    fun clear() {
        config = null
        renderProvider = null
        audioProvider = null
    }
}
