package com.zarvimo.livecricket.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.zarvimo.livecricket.AppViewModel

@Composable
fun LogoScreen(vm: AppViewModel, onBack: () -> Unit) {
    var portrait by rememberSaveable { mutableStateOf(vm.stream.portrait) }
    val lg = vm.media.logo
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importChannelLogo(uri)
    }
    val corners = listOf("TOP_LEFT" to "Top left", "TOP_RIGHT" to "Top right", "BOTTOM_LEFT" to "Bottom left", "BOTTOM_RIGHT" to "Bottom right")

    ScreenScaffold("Channel Logo Settings", onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !portrait, onClick = { portrait = false }, label = { Text("Landscape") })
            FilterChip(selected = portrait, onClick = { portrait = true }, label = { Text("Portrait") })
        }
        BoardImage(
            vm, portrait, live = false,
            modifier = Modifier.then(if (portrait) Modifier.height(380.dp) else Modifier.fillMaxWidth()).clip(RoundedCornerShape(14.dp)),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Show logo and watermark", Modifier.weight(1f))
            Switch(checked = lg.visible, onCheckedChange = { on -> vm.updateLogo { it.copy(visible = on) } })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { picker.launch(arrayOf("image/png", "image/jpeg")) }) {
                Text(if (lg.path == null) "Choose logo (PNG/JPG)" else "Replace logo")
            }
            if (lg.path != null) TextButton(onClick = { vm.removeChannelLogo() }) { Text("Remove") }
        }
        Text("Position", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            corners.take(2).forEach { (k, l) -> FilterChip(selected = lg.corner == k, onClick = { vm.updateLogo { it.copy(corner = k) } }, label = { Text(l) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            corners.drop(2).forEach { (k, l) -> FilterChip(selected = lg.corner == k, onClick = { vm.updateLogo { it.copy(corner = k) } }, label = { Text(l) }) }
        }
        Text("Size ${lg.sizePct}%")
        Slider(value = lg.sizePct.toFloat(), onValueChange = { v -> vm.updateLogo { it.copy(sizePct = v.toInt()) } }, valueRange = 5f..35f)
        Text("Opacity ${lg.opacity}%")
        Slider(value = lg.opacity.toFloat(), onValueChange = { v -> vm.updateLogo { it.copy(opacity = v.toInt()) } }, valueRange = 10f..100f)
        OutlinedTextField(
            value = lg.watermark, onValueChange = { v -> vm.updateLogo { it.copy(watermark = v.take(40)) } },
            label = { Text("Channel name / watermark (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Text("PNG transparency is kept. Nothing is hardcoded: only your own logo is shown.", style = MaterialTheme.typography.bodySmall)
    }
}
