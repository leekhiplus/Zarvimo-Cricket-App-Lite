package com.zarvimo.livecricket.stream

import kotlin.math.floor
import kotlin.math.roundToInt

const val SAMPLE_RATE = 44100

/** Pure audio helpers (unit-tested). All buffers are 16-bit PCM. */
object AudioMath {
    private fun clip(v: Float): Short = v.roundToInt().coerceIn(-32768, 32767).toShort()

    /**
     * Mixes a mono microphone buffer ([mic], may be null) and interleaved stereo music into [out] (interleaved stereo).
     * Gains are linear (1.0 = unchanged). The mic is placed in both channels.
     */
    fun mix(mic: ShortArray?, micGain: Float, music: ShortArray, musicGain: Float, out: ShortArray, frames: Int) {
        for (i in 0 until frames) {
            val m = if (mic != null) mic[i] * micGain else 0f
            out[2 * i] = clip(music[2 * i] * musicGain + m)
            out[2 * i + 1] = clip(music[2 * i + 1] * musicGain + m)
        }
    }

    fun percentToGain(percent: Int): Float = (percent.coerceIn(0, 100) / 100f)
}

/** Streaming linear resampler from any rate / 1-2 channels to interleaved stereo at [SAMPLE_RATE]. */
class StereoResampler(private val srcRate: Int, private val channels: Int) {
    private val step = srcRate.toDouble() / SAMPLE_RATE
    private var pos = 0.0
    private var lastL = 0
    private var lastR = 0

    /** [src] holds [frames] frames of interleaved samples. Returns interleaved stereo samples. */
    fun process(src: ShortArray, frames: Int): ShortArray {
        if (frames <= 0) return ShortArray(0)
        val out = ArrayList<Short>((frames * 2 / step.coerceAtLeast(0.01)).toInt() + 4)
        fun sample(i: Int, ch: Int): Int = when {
            i < 0 -> if (ch == 0) lastL else lastR
            else -> src[i * channels + minOf(ch, channels - 1)].toInt()
        }
        while (true) {
            val i0 = floor(pos).toInt()
            if (i0 + 1 >= frames) break
            val f = pos - i0
            val l = sample(i0, 0) + (sample(i0 + 1, 0) - sample(i0, 0)) * f
            val r = sample(i0, 1) + (sample(i0 + 1, 1) - sample(i0, 1)) * f
            out.add(l.roundToInt().toShort())
            out.add(r.roundToInt().toShort())
            pos += step
        }
        pos -= frames
        lastL = src[(frames - 1) * channels].toInt()
        lastR = src[(frames - 1) * channels + minOf(1, channels - 1)].toInt()
        return out.toShortArray()
    }
}

/** Thread-safe ring buffer of 16-bit samples (the music decoder writes, the mixer reads). */
class ShortRing(private val capacity: Int) {
    private val buf = ShortArray(capacity)
    private var head = 0
    private var size = 0

    @Synchronized fun available(): Int = size
    @Synchronized fun free(): Int = capacity - size

    /** Writes up to [len] samples; returns how many were accepted. */
    @Synchronized fun write(src: ShortArray, off: Int, len: Int): Int {
        val n = minOf(len, capacity - size)
        for (i in 0 until n) buf[(head + size + i) % capacity] = src[off + i]
        size += n
        return n
    }

    /** Reads up to [len] samples into [dst]; returns how many were available. */
    @Synchronized fun read(dst: ShortArray, off: Int, len: Int): Int {
        val n = minOf(len, size)
        for (i in 0 until n) dst[off + i] = buf[(head + i) % capacity]
        head = (head + n) % capacity
        size -= n
        return n
    }

    @Synchronized fun clear() { head = 0; size = 0 }
}
