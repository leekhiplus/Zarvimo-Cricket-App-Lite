package com.zarvimo.livecricket.data

import org.json.JSONObject

data class BgSettings(
    val style: String = "stadium",   // stadium | dark | light | custom
    val path: String? = null,
    val fit: String = "crop",        // crop | fit
    val zoom: Float = 1f,
    val offX: Float = 0f,
    val offY: Float = 0f,
)

data class LogoSettings(
    val path: String? = null,
    val visible: Boolean = true,
    val corner: String = "TOP_RIGHT", // TOP_LEFT | TOP_RIGHT | BOTTOM_LEFT | BOTTOM_RIGHT
    val sizePct: Int = 14,
    val opacity: Int = 100,
    val watermark: String = "",
)

data class AudioSettings(
    val musicPath: String? = null,
    val musicName: String? = null,
    val loop: Boolean = true,
    val musicVol: Int = 60,
    val musicMuted: Boolean = false,
    val micEnabled: Boolean = true,
    val micVol: Int = 100,
)

data class MediaSettings(
    val bgLandscape: BgSettings = BgSettings(),
    val bgPortrait: BgSettings = BgSettings(),
    val logo: LogoSettings = LogoSettings(),
    val audio: AudioSettings = AudioSettings(),
)

data class StreamSettings(
    val portrait: Boolean = false,
    val fps: Int = 30,
    val videoKbps: Int = 0, // 0 = automatic for the chosen resolution
    val audioKbps: Int = 128,
)

object MediaJson {
    private fun JSONObject.str(k: String): String? = if (has(k) && !isNull(k)) getString(k) else null

    private fun bgToJson(b: BgSettings) = JSONObject().apply {
        put("style", b.style)
        b.path?.let { put("path", it) }
        put("fit", b.fit)
        put("zoom", b.zoom.toDouble())
        put("offX", b.offX.toDouble())
        put("offY", b.offY.toDouble())
    }

    private fun bgFrom(o: JSONObject) = BgSettings(
        style = o.optString("style", "stadium"),
        path = o.str("path"),
        fit = o.optString("fit", "crop"),
        zoom = o.optDouble("zoom", 1.0).toFloat(),
        offX = o.optDouble("offX", 0.0).toFloat(),
        offY = o.optDouble("offY", 0.0).toFloat(),
    )

    fun mediaToJson(m: MediaSettings): String = JSONObject().apply {
        put("bgL", bgToJson(m.bgLandscape))
        put("bgP", bgToJson(m.bgPortrait))
        put("logo", JSONObject().apply {
            m.logo.path?.let { put("path", it) }
            put("visible", m.logo.visible)
            put("corner", m.logo.corner)
            put("sizePct", m.logo.sizePct)
            put("opacity", m.logo.opacity)
            put("watermark", m.logo.watermark)
        })
        put("audio", JSONObject().apply {
            m.audio.musicPath?.let { put("musicPath", it) }
            m.audio.musicName?.let { put("musicName", it) }
            put("loop", m.audio.loop)
            put("musicVol", m.audio.musicVol)
            put("musicMuted", m.audio.musicMuted)
            put("micEnabled", m.audio.micEnabled)
            put("micVol", m.audio.micVol)
        })
    }.toString()

    fun mediaFromJson(text: String): MediaSettings {
        val o = JSONObject(text)
        val l = o.optJSONObject("logo") ?: JSONObject()
        val a = o.optJSONObject("audio") ?: JSONObject()
        return MediaSettings(
            bgLandscape = o.optJSONObject("bgL")?.let { bgFrom(it) } ?: BgSettings(),
            bgPortrait = o.optJSONObject("bgP")?.let { bgFrom(it) } ?: BgSettings(),
            logo = LogoSettings(
                path = l.str("path"),
                visible = l.optBoolean("visible", true),
                corner = l.optString("corner", "TOP_RIGHT"),
                sizePct = l.optInt("sizePct", 14),
                opacity = l.optInt("opacity", 100),
                watermark = l.optString("watermark", ""),
            ),
            audio = AudioSettings(
                musicPath = a.str("musicPath"),
                musicName = a.str("musicName"),
                loop = a.optBoolean("loop", true),
                musicVol = a.optInt("musicVol", 60),
                musicMuted = a.optBoolean("musicMuted", false),
                micEnabled = a.optBoolean("micEnabled", true),
                micVol = a.optInt("micVol", 100),
            ),
        )
    }

    fun streamToJson(s: StreamSettings): String = JSONObject().apply {
        put("portrait", s.portrait)
        put("fps", s.fps)
        put("videoKbps", s.videoKbps)
        put("audioKbps", s.audioKbps)
    }.toString()

    fun streamFromJson(text: String): StreamSettings {
        val o = JSONObject(text)
        return StreamSettings(
            portrait = o.optBoolean("portrait", false),
            fps = o.optInt("fps", 30),
            videoKbps = o.optInt("videoKbps", 0),
            audioKbps = o.optInt("audioKbps", 128),
        )
    }
}
