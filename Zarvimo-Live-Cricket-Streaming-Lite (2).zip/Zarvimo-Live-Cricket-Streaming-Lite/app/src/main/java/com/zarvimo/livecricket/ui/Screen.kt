package com.zarvimo.livecricket.ui

enum class Screen {
    HOME, SETUP, XI, SCORING, TEMPLATES, PREVIEW, HISTORY, SETTINGS, STREAM, BACKGROUND, LOGO, AUDIO
}
