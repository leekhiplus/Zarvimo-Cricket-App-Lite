package com.zarvimo.livecricket.stream

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.net.ConnectivityManager
import android.net.Network
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.view.Surface
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.rtmp.rtmp.RtmpClient
import com.zarvimo.livecricket.data.AudioSettings
import com.zarvimo.livecricket.render.BoardPainter
import java.nio.ByteOrder

/**
 * Real-time pipeline: BoardPainter -> encoder Surface (H.264) and microphone + music mixer -> AAC,
 * both sent through the RTMP client. The same BoardPainter draws the on-screen preview.
 *
 * Two phases like the UI: start() encodes and connects to the server ("Connected"); goLive() starts sending.
 */
class StreamEngine(
    private val ctx: Context,
    private val cfg: StreamConfig,
    private val renderProvider: () -> com.zarvimo.livecricket.render.RenderState,
    private val audioProvider: () -> AudioSettings,
) : ConnectChecker {

    private val client = RtmpClient(this)
    private var videoCodec: MediaCodec? = null
    private var audioCodec: MediaCodec? = null
    private var surface: Surface? = null
    private var record: AudioRecord? = null
    private var music: MusicSource? = null
    private var musicPath: String? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    @Volatile private var running = false
    @Volatile private var connectStarted = false
    @Volatile private var connected = false
    @Volatile private var live = false
    @Volatile private var waitKeyFrame = true
    @Volatile private var needReconnectOnNetwork = false
    @Volatile private var framesThisSecond = 0

    private val threads = mutableListOf<Thread>()
    private var startedAt = 0L

    private fun fullUrl(): String = cfg.url.trim().trimEnd('/') + "/" + cfg.key.trim()

    /** Remove the stream key (and the whole URL) from any text before it is shown or logged. */
    private fun sanitize(text: String?): String {
        var t = text ?: "Unknown error"
        if (cfg.key.isNotBlank()) t = t.replace(cfg.key.trim(), "***")
        t = t.replace(fullUrl(), "***")
        return t.take(160)
    }

    fun start() {
        if (running) return
        running = true
        StreamStatus.reset("Starting")
        StreamStatus.running = true
        startedAt = SystemClock.elapsedRealtime()

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zarvimo:stream").apply { acquire(12 * 60 * 60 * 1000L) }

        try {
            startVideo()
            startAudio()
        } catch (e: Exception) {
            fail("Encoder error: ${sanitize(e.message)}")
            return
        }
        registerNetworkCallback()
        spawn("render") { renderLoop() }
        spawn("video-drain") { videoDrainLoop() }
        spawn("audio-in") { audioInputLoop() }
        spawn("audio-drain") { audioDrainLoop() }
        StreamStatus.state = "Preparing"
    }

    fun goLive() {
        if (!running || !connected) return
        waitKeyFrame = true
        requestKeyFrame()
        live = true
        StreamStatus.live = true
        StreamStatus.state = "Live"
    }

    fun stop() {
        if (!running && videoCodec == null) return
        running = false
        live = false
        connected = false
        for (t in threads) runCatching { t.interrupt() }
        for (t in threads) if (t !== Thread.currentThread()) runCatching { t.join(1500) }
        threads.clear()
        runCatching { client.disconnect() }
        music?.stop(); music = null
        runCatching { record?.stop() }
        runCatching { record?.release() }
        record = null
        runCatching { audioCodec?.stop() }
        runCatching { audioCodec?.release() }
        audioCodec = null
        runCatching { videoCodec?.stop() }
        runCatching { videoCodec?.release() }
        videoCodec = null
        runCatching { surface?.release() }
        surface = null
        unregisterNetworkCallback()
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        wakeLock = null
        StreamStatus.running = false
        StreamStatus.connected = false
        StreamStatus.live = false
        StreamStatus.bitrateKbps = 0
        StreamStatus.fps = 0
        if (StreamStatus.error == null) StreamStatus.state = "Stopped"
    }

    private fun fail(message: String) {
        StreamStatus.error = message
        StreamStatus.state = "Error"
        stop()
    }

    private fun spawn(name: String, body: () -> Unit) {
        val t = Thread({
            try { body() } catch (e: InterruptedException) { } catch (e: Exception) {
                if (running) fail("Stream error: ${sanitize(e.message)}")
            }
        }, "zarvimo-$name")
        t.isDaemon = true
        threads.add(t)
        t.start()
    }

    // ------------------------------------------------------------------ video

    private fun startVideo() {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, cfg.width, cfg.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, cfg.videoBps)
            setInteger(MediaFormat.KEY_FRAME_RATE, cfg.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        surface = codec.createInputSurface()
        codec.start()
        videoCodec = codec
    }

    private fun requestKeyFrame() {
        runCatching {
            videoCodec?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        }
    }

    private fun renderLoop() {
        val painter = BoardPainter(ctx)
        val interval = 1000L / cfg.fps
        var next = SystemClock.uptimeMillis()
        var lastStat = SystemClock.uptimeMillis()
        while (running) {
            val s = surface ?: break
            val now = SystemClock.uptimeMillis()
            if (now >= next) {
                try {
                    val canvas: Canvas = s.lockHardwareCanvas()
                    try {
                        painter.draw(canvas, cfg.width, cfg.height, renderProvider())
                    } finally {
                        s.unlockCanvasAndPost(canvas)
                    }
                    framesThisSecond++
                } catch (e: Exception) {
                    if (!running) break
                    StreamStatus.dropped++
                }
                next += interval
                if (now - next > interval * 2) {
                    // fell behind: count skipped frames and resynchronise
                    StreamStatus.dropped += ((now - next) / interval).toInt()
                    next = now + interval
                }
            }
            if (now - lastStat >= 1000) {
                StreamStatus.fps = framesThisSecond
                framesThisSecond = 0
                lastStat = now
                StreamStatus.elapsedSec = (SystemClock.elapsedRealtime() - startedAt) / 1000
            }
            val wait = next - SystemClock.uptimeMillis()
            if (wait > 0) Thread.sleep(wait)
        }
    }

    private fun videoDrainLoop() {
        val codec = videoCodec ?: return
        val info = MediaCodec.BufferInfo()
        while (running) {
            val idx = codec.dequeueOutputBuffer(info, 10_000)
            when {
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onVideoFormat(codec.outputFormat)
                idx >= 0 -> {
                    val buf = codec.getOutputBuffer(idx)
                    val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                    if (buf != null && info.size > 0 && !isConfig && live && connected) {
                        val isKey = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
                        if (waitKeyFrame && !isKey) {
                            StreamStatus.dropped++
                        } else {
                            waitKeyFrame = false
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            client.sendVideo(buf, info)
                        }
                    }
                    codec.releaseOutputBuffer(idx, false)
                }
            }
        }
    }

    private fun onVideoFormat(f: MediaFormat) {
        val sps = f.getByteBuffer("csd-0")
        val pps = f.getByteBuffer("csd-1")
        if (sps == null || pps == null) {
            fail("The encoder did not provide stream headers.")
            return
        }
        if (connectStarted) return
        connectStarted = true
        client.setReTries(10)
        client.setVideoResolution(cfg.width, cfg.height)
        client.setFps(cfg.fps)
        client.setAudioInfo(SAMPLE_RATE, true)
        client.setVideoInfo(sps, pps, null)
        StreamStatus.state = "Connecting"
        client.connect(fullUrl())
    }

    // ------------------------------------------------------------------ audio

    private fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startAudio() {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, cfg.audioBps)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        audioCodec = codec

        if (hasMicPermission()) {
            val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min > 0) {
                @Suppress("MissingPermission")
                val rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192) * 2,
                )
                if (rec.state == AudioRecord.STATE_INITIALIZED) record = rec else rec.release()
            }
        }
    }

    private fun syncMusic(a: AudioSettings) {
        val wanted = if (a.musicMuted) null else a.musicPath
        if (wanted != musicPath) {
            music?.stop()
            music = null
            musicPath = wanted
            if (wanted != null) music = MusicSource(wanted).also { it.loop = a.loop; it.start() }
        }
        music?.loop = a.loop
    }

    private fun audioInputLoop() {
        val codec = audioCodec ?: return
        val frames = 1024
        val chunkUs = frames * 1_000_000L / SAMPLE_RATE
        val mic = ShortArray(frames)
        val musicBuf = ShortArray(frames * 2)
        val mixed = ShortArray(frames * 2)
        var micRunning = false
        val basePts = System.nanoTime() / 1000
        var written = 0L
        var nextWake = SystemClock.elapsedRealtime()

        while (running) {
            val a = audioProvider()
            syncMusic(a)

            val rec = record
            var micData: ShortArray? = null
            val wantMic = rec != null && a.micEnabled
            if (rec != null && wantMic && !micRunning) { runCatching { rec.startRecording(); micRunning = true } }
            if (rec != null && !wantMic && micRunning) { runCatching { rec.stop() }; micRunning = false }

            if (rec != null && micRunning) {
                var got = 0
                while (got < frames && running) {
                    val n = rec.read(mic, got, frames - got)
                    if (n <= 0) break
                    got += n
                }
                if (got == frames) micData = mic
            } else {
                // No microphone: pace the loop in real time.
                nextWake += chunkUs / 1000
                val wait = nextWake - SystemClock.elapsedRealtime()
                if (wait > 0) Thread.sleep(wait) else nextWake = SystemClock.elapsedRealtime()
            }

            val src = music
            if (src != null) src.read(musicBuf, frames) else java.util.Arrays.fill(musicBuf, 0.toShort())
            AudioMath.mix(
                micData, AudioMath.percentToGain(a.micVol) * 1.5f,
                musicBuf, if (a.musicMuted) 0f else AudioMath.percentToGain(a.musicVol),
                mixed, frames,
            )

            val ii = codec.dequeueInputBuffer(10_000)
            if (ii >= 0) {
                val ib = codec.getInputBuffer(ii) ?: continue
                ib.clear()
                ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(mixed, 0, frames * 2)
                codec.queueInputBuffer(ii, 0, frames * 4, basePts + written * 1_000_000L / SAMPLE_RATE, 0)
                written += frames
            }
        }
    }

    private fun audioDrainLoop() {
        val codec = audioCodec ?: return
        val info = MediaCodec.BufferInfo()
        while (running) {
            val idx = codec.dequeueOutputBuffer(info, 10_000)
            if (idx >= 0) {
                val buf = codec.getOutputBuffer(idx)
                val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                if (buf != null && info.size > 0 && !isConfig && live && connected) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    client.sendAudio(buf, info)
                }
                codec.releaseOutputBuffer(idx, false)
            }
        }
    }

    // ------------------------------------------------------------------ network

    private fun registerNetworkCallback() {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                if (running && (connected || live)) {
                    needReconnectOnNetwork = true
                    StreamStatus.state = "Network lost, waiting"
                }
            }

            override fun onAvailable(network: Network) {
                if (running && needReconnectOnNetwork) {
                    needReconnectOnNetwork = false
                    StreamStatus.state = "Reconnecting"
                    runCatching { client.reConnect(1500) }
                }
            }
        }
        runCatching { cm.registerDefaultNetworkCallback(cb); netCallback = cb }
    }

    private fun unregisterNetworkCallback() {
        val cb = netCallback ?: return
        runCatching { (ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(cb) }
        netCallback = null
    }

    // ------------------------------------------------------------------ ConnectChecker

    override fun onConnectionStarted(url: String) {
        StreamStatus.state = "Connecting"
    }

    override fun onConnectionSuccess() {
        connected = true
        waitKeyFrame = true
        requestKeyFrame()
        StreamStatus.connected = true
        StreamStatus.error = null
        StreamStatus.state = if (live) "Live" else "Connected"
    }

    override fun onConnectionFailed(reason: String) {
        connected = false
        StreamStatus.connected = false
        if (!running) return
        if (client.shouldRetry(reason)) {
            StreamStatus.state = "Reconnecting"
            StreamStatus.error = sanitize(reason)
            client.reConnect(2000)
        } else {
            StreamStatus.error = sanitize(reason)
            StreamStatus.state = "Error"
            live = false
            StreamStatus.live = false
        }
    }

    override fun onNewBitrate(bitrate: Long) {
        StreamStatus.bitrateKbps = (bitrate / 1000).toInt()
    }

    override fun onDisconnect() {
        connected = false
        StreamStatus.connected = false
        if (running && StreamStatus.error == null) StreamStatus.state = "Disconnected"
    }

    override fun onAuthError() {
        StreamStatus.error = "Authentication failed. Check the stream key."
        StreamStatus.state = "Error"
    }

    override fun onAuthSuccess() {}
}
