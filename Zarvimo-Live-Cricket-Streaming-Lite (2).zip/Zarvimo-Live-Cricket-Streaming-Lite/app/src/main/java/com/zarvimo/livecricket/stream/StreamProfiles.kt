package com.zarvimo.livecricket.stream

import android.media.MediaCodecList

data class StreamProfile(val label: String, val longSide: Int, val shortSide: Int, val autoKbps: Int)

object StreamProfiles {
    // Sizes are 16:9 and multiples of 16 where possible (some hardware encoders require alignment).
    val all = listOf(
        StreamProfile("480p", 848, 480, 1500),
        StreamProfile("720p", 1280, 720, 2500),
        StreamProfile("1080p", 1920, 1080, 5000),
    )

    fun byLabel(label: String): StreamProfile = all.firstOrNull { it.label == label } ?: all[1]

    fun width(p: StreamProfile, portrait: Boolean) = if (portrait) p.shortSide else p.longSide
    fun height(p: StreamProfile, portrait: Boolean) = if (portrait) p.longSide else p.shortSide

    fun videoBitrateBps(p: StreamProfile, userKbps: Int, fps: Int): Int {
        val kbps = if (userKbps > 0) userKbps else p.autoKbps
        val scaled = if (fps > 30) kbps * 3 / 2 else kbps
        return scaled * 1000
    }

    /** True when some H.264 hardware/software encoder on this device can encode the given size. */
    fun isSupported(w: Int, h: Int): Boolean = runCatching {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
            info.isEncoder && info.supportedTypes.any { it.equals("video/avc", ignoreCase = true) } &&
                info.getCapabilitiesForType("video/avc").videoCapabilities?.isSizeSupported(w, h) == true
        }
    }.getOrDefault(w <= 1280)

    fun supported(portrait: Boolean): List<StreamProfile> =
        all.filter { isSupported(width(it, portrait), height(it, portrait)) }
}
