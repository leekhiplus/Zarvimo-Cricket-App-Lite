package com.zarvimo.livecricket.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PorterDuff
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import com.zarvimo.livecricket.AppViewModel
import com.zarvimo.livecricket.data.ScoreboardData
import com.zarvimo.livecricket.render.BoardPainter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/**
 * Shows the broadcast picture drawn by [BoardPainter], the same renderer that feeds the YouTube stream.
 * [live] keeps redrawing (~15 fps) so score animations play; otherwise it draws once per change.
 */
@Composable
fun BoardImage(
    vm: AppViewModel,
    portrait: Boolean,
    modifier: Modifier = Modifier,
    live: Boolean = true,
    styleIndex: Int = vm.templateIndex,
    res: Float = 1f,
    dataOverride: ScoreboardData? = null,
) {
    val ctx = LocalContext.current
    val painter = remember { BoardPainter(ctx.applicationContext) }
    val w = ((if (portrait) 540 else 960) * res).toInt().coerceAtLeast(64)
    val h = ((if (portrait) 960 else 540) * res).toInt().coerceAtLeast(64)
    val bitmaps = remember(w, h) { arrayOf(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888), Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)) }
    val canvases = remember(bitmaps) { bitmaps.map { Canvas(it) } }
    var shown by remember(bitmaps) { mutableStateOf(0) }

    LaunchedEffect(bitmaps, portrait, styleIndex, live, vm.match, vm.media, dataOverride) {
        do {
            val next = 1 - shown
            withContext(Dispatchers.Default) {
                val cv = canvases[next]
                cv.drawColor(0, PorterDuff.Mode.CLEAR)
                painter.draw(cv, w, h, vm.renderState(portrait, styleIndex, dataOverride))
            }
            shown = next
            if (live) delay(66)
        } while (live && isActive)
    }

    Image(
        bitmap = bitmaps[shown].asImageBitmap(),
        contentDescription = null,
        modifier = modifier.aspectRatio(w / h.toFloat()),
    )
}
