package com.zarvimo.livecricket.stream

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder

/**
 * Decodes a local audio file (MP3/WAV/AAC/M4A) to 44.1 kHz stereo PCM on a background thread and
 * serves it to the mixer. Loops when [loop] is true. Delivers silence when it runs dry.
 */
class MusicSource(private val path: String) {
    @Volatile var loop: Boolean = true
    private val ring = ShortRing(SAMPLE_RATE * 2 * 2) // two seconds of stereo
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        running = true
        thread = Thread({ decodeLoop() }, "zarvimo-music").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
        ring.clear()
    }

    /** Fills [out] with [frames] stereo frames (zero where no decoded audio is available yet). */
    fun read(out: ShortArray, frames: Int) {
        val want = frames * 2
        val got = ring.read(out, 0, want)
        for (i in got until want) out[i] = 0
    }

    private fun decodeLoop() {
        while (running) {
            val ended = runCatching { decodeOnce() }.getOrDefault(false)
            if (!running) break
            try {
                when {
                    !ended -> Thread.sleep(500)   // decode problem or no audio track: retry quietly
                    !loop -> Thread.sleep(200)    // finished and not looping: wait until looping is switched on
                    else -> {}                    // finished and looping: start again immediately
                }
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    /** Decodes the file once. Returns true if it ended normally. */
    private fun decodeOnce(): Boolean {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(path)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; format = f; break }
            }
            if (track < 0 || format == null) return false
            ex.selectTrack(track)
            codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(format, null, null, 0)
            codec.start()

            var rate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else SAMPLE_RATE
            var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var resampler = StereoResampler(rate, channels.coerceIn(1, 2))
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (running && !outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val ib = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        resampler = StereoResampler(rate, channels.coerceIn(1, 2))
                    }
                    oi >= 0 -> {
                        val ob = codec.getOutputBuffer(oi)
                        if (ob != null && info.size > 0) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val shorts = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val total = shorts.remaining()
                            val ch = channels.coerceIn(1, 2)
                            val frames = total / ch
                            val pcm = ShortArray(frames * ch)
                            shorts.get(pcm, 0, frames * ch)
                            val stereo = resampler.process(pcm, frames)
                            var off = 0
                            while (running && off < stereo.size) {
                                val n = ring.write(stereo, off, stereo.size - off)
                                off += n
                                if (n == 0) Thread.sleep(5)
                            }
                        }
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            }
            return outputDone
        } catch (e: InterruptedException) {
            return false
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { ex.release() }
        }
    }
}
