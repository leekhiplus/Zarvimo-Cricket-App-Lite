package com.zarvimo.livecricket.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

data class Country(val code: String, val en: String, val ur: String)

/** Offline country list (assets/countries.tsv) and flag bitmaps (assets/flags/<code>.webp). */
object Countries {
    private var cache: List<Country>? = null
    private val bitmaps = LruCache<String, Bitmap>(96)
    private val composeBitmaps = LruCache<String, ImageBitmap>(96)

    @Synchronized
    fun all(ctx: Context): List<Country> {
        cache?.let { return it }
        val list = ctx.assets.open("countries.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.filter { it.isNotBlank() }.map { line ->
                val p = line.split('\t')
                Country(p[0], p[1], p.getOrElse(2) { p[1] })
            }.toList()
        }
        cache = list
        return list
    }

    fun find(ctx: Context, code: String): Country? = all(ctx).firstOrNull { it.code.equals(code, ignoreCase = true) }

    fun flagBitmap(ctx: Context, code: String): Bitmap? {
        val key = code.lowercase()
        bitmaps.get(key)?.let { return it }
        val bmp = runCatching {
            ctx.assets.open("flags/$key.webp").use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
        if (bmp != null) bitmaps.put(key, bmp)
        return bmp
    }

    fun flag(ctx: Context, code: String): ImageBitmap? {
        val key = code.lowercase()
        composeBitmaps.get(key)?.let { return it }
        val img = flagBitmap(ctx, code)?.asImageBitmap()
        if (img != null) composeBitmaps.put(key, img)
        return img
    }
}
