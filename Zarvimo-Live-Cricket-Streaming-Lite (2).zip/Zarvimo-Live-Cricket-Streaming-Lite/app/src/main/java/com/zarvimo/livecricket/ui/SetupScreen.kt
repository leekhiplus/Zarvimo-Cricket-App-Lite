package com.zarvimo.livecricket.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.livecricket.AppViewModel
import com.zarvimo.livecricket.data.Countries
import com.zarvimo.livecricket.data.TeamInfo
import com.zarvimo.livecricket.engine.MatchFormat
import com.zarvimo.livecricket.engine.Side

private fun defaultOvers(f: MatchFormat): String = when (f) {
    MatchFormat.T10 -> "10"
    MatchFormat.T20 -> "20"
    MatchFormat.ODI -> "50"
    MatchFormat.CUSTOM -> "20"
    else -> ""
}

@Composable
private fun Field(label: String, value: String, placeholder: String = "", onChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        OutlinedTextField(
            value = value, onValueChange = onChange, singleLine = true,
            placeholder = { Text(placeholder) }, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
        )
    }
}

@Composable
private fun TeamCard(label: String, t: TeamInfo, modifier: Modifier, onClick: () -> Unit) {
    GlassCard(modifier.clickable(onClick = onClick)) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(label, fontWeight = FontWeight.SemiBold)
            TeamBadge(t.countryCode, t.logoPath, 56.dp, fallback = t.name.ifBlank { "?" })
            Text(
                t.name.ifBlank { "Tap to set" }.uppercase(), fontWeight = FontWeight.Bold,
                maxLines = 1, textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun Stepper(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 56.dp, height = 44.dp).clip(RoundedCornerShape(10.dp)).background(Palette.Blue).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun SetupScreen(vm: AppViewModel, onBack: () -> Unit, onNext: () -> Unit) {
    val d = vm.draft
    val cfg = d.config()
    var editing by remember { mutableStateOf<Side?>(null) }

    ScreenScaffold("Create New Match", onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TeamCard("Team A", d.teamA, Modifier.weight(1f)) { editing = Side.A }
            Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0xFF16275A)), contentAlignment = Alignment.Center) {
                Text("VS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            TeamCard("Team B", d.teamB, Modifier.weight(1f)) { editing = Side.B }
        }

        Text("Match Format", fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MatchFormat.values().forEach { f ->
                FilterChip(
                    selected = d.format == f,
                    onClick = { vm.draft = vm.draft.copy(format = f, overs = defaultOvers(f)) },
                    label = { Text(f.label) },
                )
            }
        }

        Text("Total Overs", fontWeight = FontWeight.SemiBold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val cur = d.overs.toIntOrNull() ?: 20
            Stepper("\u2212") { if (d.oversEditable) vm.draft = vm.draft.copy(overs = (cur - 1).coerceIn(1, 100).toString()) }
            Box(
                Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    when {
                        !d.oversEditable && d.format == MatchFormat.TEST -> "No limit"
                        !d.oversEditable -> "100 balls"
                        else -> d.overs.ifBlank { "-" }
                    },
                    fontSize = 18.sp, fontWeight = FontWeight.Bold,
                )
            }
            Stepper("+") { if (d.oversEditable) vm.draft = vm.draft.copy(overs = (cur + 1).coerceIn(1, 100).toString()) }
        }
        Text(
            when {
                cfg == null -> "Enter overs between 1 and 100"
                cfg.ballsPerInnings == null -> "Test: ${cfg.maxInnings} innings, no over limit"
                else -> "Legal deliveries per innings: ${cfg.ballsPerInnings}"
            },
            color = MaterialTheme.colorScheme.primary, fontSize = 13.sp,
        )

        Field("Match Title", d.title, "${d.teamA.name.ifBlank { "Team A" }} vs ${d.teamB.name.ifBlank { "Team B" }} ${d.format.label}") { v ->
            vm.draft = vm.draft.copy(title = v)
        }
        Field("Venue (Optional)", d.venue, "Stadium / ground") { v -> vm.draft = vm.draft.copy(venue = v) }
        Field("Match Date (Optional)", d.date, "24 Apr 2025") { v -> vm.draft = vm.draft.copy(date = v) }

        Text("Batting first", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = d.battingFirst == Side.A,
                onClick = { vm.draft = vm.draft.copy(battingFirst = Side.A) },
                label = { Text(d.teamA.name.ifBlank { "Team A" }) },
            )
            FilterChip(
                selected = d.battingFirst == Side.B,
                onClick = { vm.draft = vm.draft.copy(battingFirst = Side.B) },
                label = { Text(d.teamB.name.ifBlank { "Team B" }) },
            )
        }

        PrimaryButton("Next \u2192", Palette.Green) {
            when {
                cfg == null -> vm.message = "Enter a valid number of overs (1-100)."
                d.teamA.name.isBlank() || d.teamB.name.isBlank() ->
                    vm.message = "Tap Team A and Team B to set names and flags."
                else -> onNext()
            }
        }
    }

    editing?.let { side -> TeamDialog(vm, side) { editing = null } }
}

@Composable
private fun TeamDialog(vm: AppViewModel, side: Side, onDismiss: () -> Unit) {
    val t = if (side == Side.A) vm.draft.teamA else vm.draft.teamB
    val ctx = LocalContext.current
    var picking by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLogo(uri, side)
    }
    val country = t.countryCode?.let { Countries.find(ctx, it) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (side == Side.A) "Team A" else "Team B") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = t.name, onValueChange = { v -> vm.updateTeam(side) { tm -> tm.copy(name = v) } },
                    label = { Text("Team name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TeamBadge(t.countryCode, t.logoPath, 36.dp, fallback = t.name)
                    OutlinedButton(onClick = { picking = true }, modifier = Modifier.weight(1f)) {
                        Text(country?.let { it.en } ?: "Select country / flag", maxLines = 1)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { launcher.launch(arrayOf("image/*")) }) { Text("Custom logo") }
                    if (t.logoPath != null) {
                        TextButton(onClick = { vm.updateTeam(side) { tm -> tm.copy(logoPath = null) } }) { Text("Remove") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )

    if (picking) {
        CountryPickerDialog(
            onPick = { c ->
                picking = false
                vm.updateTeam(side) { tm ->
                    tm.copy(countryCode = c?.code, name = if (c != null && tm.name.isBlank()) c.en else tm.name)
                }
            },
            onDismiss = { picking = false },
        )
    }
}
