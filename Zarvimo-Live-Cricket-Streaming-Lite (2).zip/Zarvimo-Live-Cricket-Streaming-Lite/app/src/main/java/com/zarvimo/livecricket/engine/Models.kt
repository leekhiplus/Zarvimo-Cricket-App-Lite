package com.zarvimo.livecricket.engine

enum class Side {
    A, B;

    fun other(): Side = if (this == A) B else A
}

data class Player(val id: Int, val name: String)

data class Team(val name: String, val players: List<Player>) {
    init {
        require(players.size >= 2) { "A team needs at least 2 players" }
        require(players.map { it.id }.toSet().size == players.size) { "Duplicate player ids" }
    }

    fun hasPlayer(id: Int): Boolean = players.any { it.id == id }
}

enum class MatchFormat(val label: String) {
    T10("T10"), T20("T20"), ODI("ODI"), TEST("Test"), THE_HUNDRED("The Hundred"), CUSTOM("Custom Overs")
}

/**
 * Playing conditions. [ballsPerInnings] is null for Test matches (no over limit).
 * [endChangeBalls] is the number of legal balls after which the batters change ends
 * (equals [ballsPerOver] except in The Hundred, where it is 10 with 5-ball sets).
 */
data class MatchConfig(
    val format: MatchFormat,
    val ballsPerOver: Int,
    val ballsPerInnings: Int?,
    val maxInnings: Int,
    val maxWicketsToEnd: Int = 10,
    val endChangeBalls: Int = ballsPerOver,
    val allowConsecutiveOvers: Boolean = false,
) {
    init {
        require(ballsPerOver > 0) { "ballsPerOver must be positive" }
        require(endChangeBalls > 0) { "endChangeBalls must be positive" }
        require(ballsPerInnings == null || ballsPerInnings > 0) { "ballsPerInnings must be positive" }
        require(maxInnings == 2 || maxInnings == 4) { "maxInnings must be 2 or 4" }
    }

    companion object {
        fun forFormat(format: MatchFormat, customOvers: Int? = null): MatchConfig = when (format) {
            MatchFormat.TEST -> MatchConfig(format, 6, null, 4)
            MatchFormat.THE_HUNDRED -> MatchConfig(
                format, ballsPerOver = 5, ballsPerInnings = 100, maxInnings = 2,
                endChangeBalls = 10, allowConsecutiveOvers = true,
            )
            else -> {
                val overs = customOvers ?: when (format) {
                    MatchFormat.T10 -> 10
                    MatchFormat.T20 -> 20
                    MatchFormat.ODI -> 50
                    else -> throw IllegalArgumentException("Custom format needs an overs value")
                }
                require(overs in 1..100) { "Overs must be between 1 and 100" }
                MatchConfig(format, 6, overs * 6, 2)
            }
        }
    }
}

enum class DeliveryType(val isLegal: Boolean) {
    NORMAL(true), WIDE(false), NO_BALL(false), BYE(true), LEG_BYE(true), PENALTY(false), DEAD(false)
}

enum class WicketType(val label: String, val bowlerCredited: Boolean) {
    BOWLED("Bowled", true),
    CAUGHT("Caught", true),
    LBW("LBW", true),
    RUN_OUT("Run out", false),
    STUMPED("Stumped", true),
    HIT_WICKET("Hit wicket", true),
    RETIRED_OUT("Retired out", false),
    HANDLED_BALL("Handled the ball", false),
    OBSTRUCTING_FIELD("Obstructing the field", false),
    HIT_BALL_TWICE("Hit the ball twice", false),
}

/**
 * One delivery. Meaning of [runs] by [type]:
 * NORMAL / NO_BALL: runs off the bat (a no ball adds 1 penalty run on top);
 * WIDE: extra runs run in addition to the 1 penalty run;
 * BYE / LEG_BYE: byes or leg byes run; PENALTY: penalty runs awarded; DEAD: must be 0.
 * [dismissed] is the player id of the dismissed batter (defaults to the striker).
 */
data class Delivery(
    val type: DeliveryType = DeliveryType.NORMAL,
    val runs: Int = 0,
    val wicket: WicketType? = null,
    val dismissed: Int? = null,
) {
    val label: String
        get() {
            val w = if (wicket != null) "W" else ""
            val plus = if (runs > 0) "+$runs" else ""
            return when (type) {
                DeliveryType.NORMAL -> if (wicket != null) (if (runs > 0) "$runs$w" else w) else runs.toString()
                DeliveryType.WIDE -> "Wd$plus$w"
                DeliveryType.NO_BALL -> "Nb$plus$w"
                DeliveryType.BYE -> "${runs}b$w"
                DeliveryType.LEG_BYE -> "${runs}lb$w"
                DeliveryType.PENALTY -> "P$runs"
                DeliveryType.DEAD -> "DB"
            }
        }
}

enum class Slot { STRIKER, NON_STRIKER }

sealed interface Action {
    data class Ball(val delivery: Delivery) : Action
    data class SetBowler(val playerId: Int) : Action
    /** Puts a batter into a vacant crease slot. */
    data class SetBatter(val playerId: Int, val slot: Slot) : Action
    data object SwapStrike : Action
    /** A batter at the crease retires out (counts as a wicket). */
    data class RetireOut(val playerId: Int) : Action
    /** Test matches only. */
    data object Declare : Action
}
