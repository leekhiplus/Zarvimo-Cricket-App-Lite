package com.zarvimo.livecricket

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.zarvimo.livecricket.data.AudioSettings
import com.zarvimo.livecricket.data.Backup
import com.zarvimo.livecricket.data.BgSettings
import com.zarvimo.livecricket.data.LogoSettings
import com.zarvimo.livecricket.data.MediaSettings
import com.zarvimo.livecricket.data.SQUAD_SIZE
import com.zarvimo.livecricket.data.SavedMatch
import com.zarvimo.livecricket.data.ScoreboardData
import com.zarvimo.livecricket.data.SetupDraft
import com.zarvimo.livecricket.data.Store
import com.zarvimo.livecricket.data.StreamSettings
import com.zarvimo.livecricket.data.TeamInfo
import com.zarvimo.livecricket.engine.Action
import com.zarvimo.livecricket.engine.CricketMatch
import com.zarvimo.livecricket.engine.Delivery
import com.zarvimo.livecricket.engine.Side
import com.zarvimo.livecricket.render.RenderState
import com.zarvimo.livecricket.ui.Templates
import java.io.File
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var draft by mutableStateOf(SetupDraft())
    var meta by mutableStateOf<SavedMatch?>(null)
        private set
    var match by mutableStateOf<CricketMatch?>(null)
        private set
    var message by mutableStateOf<String?>(null)
    var paused by mutableStateOf(false)
    var history by mutableStateOf<List<SavedMatch>>(emptyList())
        private set
    var templateIndex by mutableStateOf(store.templateIndex)
        private set
    var themeMode by mutableStateOf(store.themeMode)
        private set
    var savedTeams by mutableStateOf(store.savedTeams())
        private set

    // Broadcast look and sound
    var media by mutableStateOf(store.loadMedia())
        private set
    var stream by mutableStateOf(store.loadStream())
        private set

    // Streaming credentials. The key is stored encrypted with an Android Keystore key.
    var rtmpUrl by mutableStateOf(store.rtmpUrl)
        private set
    var resolution by mutableStateOf(store.resolution)
        private set
    var streamKey by mutableStateOf(store.loadKey())
        private set

    private var cacheKey: Any? = null
    private var cacheData: ScoreboardData? = null

    init {
        store.lastMatchId?.let { id -> store.load(id)?.let { runCatching { open(it) } } }
    }

    // ---- broadcast settings ------------------------------------------------------------------

    fun updateRtmpUrl(v: String) { rtmpUrl = v; store.rtmpUrl = v }
    fun updateResolution(v: String) { resolution = v; store.resolution = v }
    fun updateStreamKey(v: String) { streamKey = v; store.saveKey(v) }

    fun updateStream(f: (StreamSettings) -> StreamSettings) { stream = f(stream); store.saveStream(stream) }

    fun updateMedia(f: (MediaSettings) -> MediaSettings) { media = f(media); store.saveMedia(media) }
    fun updateBg(portrait: Boolean, f: (BgSettings) -> BgSettings) = updateMedia {
        if (portrait) it.copy(bgPortrait = f(it.bgPortrait)) else it.copy(bgLandscape = f(it.bgLandscape))
    }
    fun updateLogo(f: (LogoSettings) -> LogoSettings) = updateMedia { it.copy(logo = f(it.logo)) }
    fun updateAudio(f: (AudioSettings) -> AudioSettings) = updateMedia { it.copy(audio = f(it.audio)) }

    private fun saveScaledImage(uri: Uri, maxDim: Int, dirName: String, prefix: String, png: Boolean): String? {
        val ctx = getApplication<Application>()
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > maxDim || bounds.outHeight / sample > maxDim) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: error("unreadable")
            val dir = File(ctx.filesDir, dirName).apply { mkdirs() }
            val file = File(dir, "${prefix}_${System.currentTimeMillis()}.${if (png) "png" else "jpg"}")
            file.outputStream().use {
                bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, it)
            }
            file.absolutePath
        }.getOrNull()
    }

    private fun deleteQuietly(path: String?) { if (path != null) runCatching { File(path).delete() } }

    fun importBackground(uri: Uri, portrait: Boolean) {
        val path = saveScaledImage(uri, 1920, "media", "bg", png = false)
        if (path == null) { message = "Could not load that image."; return }
        val old = if (portrait) media.bgPortrait.path else media.bgLandscape.path
        updateBg(portrait) { it.copy(style = "custom", path = path, zoom = 1f, offX = 0f, offY = 0f) }
        deleteQuietly(old)
    }

    fun removeBackground(portrait: Boolean) {
        val old = if (portrait) media.bgPortrait.path else media.bgLandscape.path
        updateBg(portrait) { it.copy(style = "stadium", path = null) }
        deleteQuietly(old)
    }

    fun importChannelLogo(uri: Uri) {
        val path = saveScaledImage(uri, 512, "media", "logo", png = true)
        if (path == null) { message = "Could not load that image."; return }
        val old = media.logo.path
        updateLogo { it.copy(path = path) }
        deleteQuietly(old)
    }

    fun removeChannelLogo() {
        val old = media.logo.path
        updateLogo { it.copy(path = null) }
        deleteQuietly(old)
    }

    fun importMusic(uri: Uri) {
        val ctx = getApplication<Application>()
        runCatching {
            var name = "music"
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: name
            }
            val ext = name.substringAfterLast('.', "").lowercase()
            require(ext in setOf("mp3", "wav", "aac", "m4a")) { "Choose an MP3, WAV, AAC or M4A file." }
            val dir = File(ctx.filesDir, "media").apply { mkdirs() }
            val file = File(dir, "music_${System.currentTimeMillis()}.$ext")
            ctx.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { input.copyTo(it) } }
                ?: error("unreadable")
            val old = media.audio.musicPath
            updateAudio { it.copy(musicPath = file.absolutePath, musicName = name) }
            deleteQuietly(old)
        }.onFailure { message = it.message ?: "Could not load that audio file." }
    }

    fun removeMusic() {
        val old = media.audio.musicPath
        updateAudio { it.copy(musicPath = null, musicName = null) }
        deleteQuietly(old)
    }

    // ---- setup -----------------------------------------------------------------------------

    fun updateTeam(side: Side, f: (TeamInfo) -> TeamInfo) {
        draft = if (side == Side.A) draft.copy(teamA = f(draft.teamA)) else draft.copy(teamB = f(draft.teamB))
    }

    fun importLogo(uri: Uri, side: Side) {
        val path = saveScaledImage(uri, 1024, "logos", "team", png = true)
        if (path == null) { message = "Could not load that image."; return }
        updateTeam(side) { it.copy(logoPath = path) }
    }

    fun startMatch(): Boolean {
        val d = draft
        val cfg = d.config()
        if (cfg == null) { message = "Enter a valid number of overs (1-100)."; return false }
        if (d.teamA.name.isBlank() || d.teamB.name.isBlank()) { message = "Enter both team names."; return false }
        val title = d.title.ifBlank { "${d.teamA.name} vs ${d.teamB.name}" }
        val base = SavedMatch(
            id = UUID.randomUUID().toString(), title = title, venue = d.venue, date = d.date,
            format = d.format, overs = if (d.oversEditable) d.overs.toIntOrNull() else null,
            teamA = d.teamA, teamB = d.teamB, battingFirst = d.battingFirst,
            innings = emptyList(), manualResult = null, updatedAt = System.currentTimeMillis(),
        )
        return runCatching {
            val m = base.toMatch().startNextInnings()
            meta = base
            paused = false
            commit(m)
        }.onFailure { message = it.message }.isSuccess
    }

    // ---- scoring ---------------------------------------------------------------------------

    private fun commit(m: CricketMatch) {
        val base = meta ?: return
        val saved = base.copy(
            innings = m.innings.map { it.actions },
            manualResult = m.manualResult,
            updatedAt = System.currentTimeMillis(),
        )
        meta = saved
        match = m
        store.save(saved)
        store.lastMatchId = saved.id
    }

    private fun mutate(block: (CricketMatch) -> CricketMatch) {
        val m = match ?: return
        try {
            commit(block(m))
        } catch (e: IllegalArgumentException) {
            message = e.message ?: "Invalid action"
        } catch (e: IllegalStateException) {
            message = e.message ?: "Invalid action"
        }
    }

    fun perform(a: Action) {
        if (paused) { message = "Match is paused. Resume to continue scoring."; return }
        mutate { m -> m.updateCurrent((m.current ?: error("No innings")).perform(a)) }
    }

    fun undo() = mutate { m -> m.updateCurrent((m.current ?: error("No innings")).undoLastBall()) }

    fun editBall(index: Int, d: Delivery) =
        mutate { m -> m.updateCurrent((m.current ?: error("No innings")).editBall(index, d)) }

    fun nextInnings() = mutate { it.startNextInnings() }

    fun declareDraw() = mutate { it.withManualResult("Match drawn") }

    /** Scoreboard data for the current match (or a sample when no match exists). Safe to call from any thread. */
    fun boardData(): ScoreboardData {
        val m = match
        val md = meta
        if (m == null || md == null || m.innings.isEmpty()) return ScoreboardData.sample()
        if (cacheKey === m) cacheData?.let { return it }
        val d = ScoreboardData.from(md, m)
        cacheKey = m
        cacheData = d
        return d
    }

    fun renderState(portrait: Boolean, styleIndex: Int, override: ScoreboardData? = null): RenderState =
        RenderState(override ?: boardData(), Templates[styleIndex.coerceIn(0, Templates.lastIndex)], portrait, media)

    // ---- history, teams, settings ----------------------------------------------------------

    fun open(saved: SavedMatch) {
        val m = saved.toMatch()
        meta = saved
        match = m
        paused = false
        store.lastMatchId = saved.id
    }

    fun refreshHistory() { history = store.list() }

    fun deleteMatch(id: String) {
        store.delete(id)
        if (meta?.id == id) { meta = null; match = null }
        refreshHistory()
    }

    fun saveTeam(t: TeamInfo) {
        if (t.name.isBlank()) { message = "Enter a team name before saving."; return }
        savedTeams = (savedTeams.filterNot { it.name.equals(t.name, ignoreCase = true) } + t).sortedBy { it.name }
        store.writeSavedTeams(savedTeams)
    }

    fun deleteSavedTeam(name: String) {
        savedTeams = savedTeams.filterNot { it.name == name }
        store.writeSavedTeams(savedTeams)
    }

    fun selectTemplate(i: Int) { templateIndex = i; store.templateIndex = i }

    fun setTheme(mode: String) { themeMode = mode; store.themeMode = mode }

    fun backup(uri: Uri) {
        runCatching { Backup.export(getApplication<Application>(), store, uri) }
            .onSuccess { message = "Backup saved ($it matches)." }
            .onFailure { message = "Backup failed: ${it.message}" }
    }

    fun restore(uri: Uri) {
        runCatching { Backup.restore(getApplication<Application>(), store, uri) }
            .onSuccess {
                savedTeams = store.savedTeams()
                stream = store.loadStream()
                refreshHistory()
                message = "Restored $it matches."
            }
            .onFailure { message = "Restore failed: ${it.message}" }
    }

    companion object { const val MAX_PLAYERS = SQUAD_SIZE }
}
