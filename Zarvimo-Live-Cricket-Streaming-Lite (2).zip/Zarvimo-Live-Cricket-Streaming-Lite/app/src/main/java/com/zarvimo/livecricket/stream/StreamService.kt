package com.zarvimo.livecricket.stream

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.zarvimo.livecricket.MainActivity
import com.zarvimo.livecricket.R

/** Foreground service that keeps the encoder and RTMP session alive with the screen locked or the app minimised. */
class StreamService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startStreaming()
            ACTION_GO_LIVE -> StreamController.engine?.goLive()
            ACTION_STOP -> stopStreaming()
        }
        return START_NOT_STICKY
    }

    private fun startStreaming() {
        val cfg = StreamController.config
        val render = StreamController.renderProvider
        val audio = StreamController.audioProvider
        if (cfg == null || render == null || audio == null) {
            stopSelf()
            return
        }
        showForeground()
        StreamController.engine?.stop()
        val engine = StreamEngine(applicationContext, cfg, render, audio)
        StreamController.engine = engine
        engine.start()
    }

    private fun stopStreaming() {
        StreamController.engine?.stop()
        StreamController.engine = null
        StreamController.clear()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun showForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Live streaming", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, StreamService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Zarvimo is streaming")
            .setContentText("Tap to return to the app")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        val micGranted = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val type = if (micGranted) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    override fun onDestroy() {
        StreamController.engine?.stop()
        StreamController.engine = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.zarvimo.livecricket.START"
        const val ACTION_GO_LIVE = "com.zarvimo.livecricket.GO_LIVE"
        const val ACTION_STOP = "com.zarvimo.livecricket.STOP"
        private const val CHANNEL = "stream"
        private const val NOTIFICATION_ID = 7
    }
}
