package com.zarvimo.livecricket.data

import com.zarvimo.livecricket.engine.Action
import com.zarvimo.livecricket.engine.CricketMatch
import com.zarvimo.livecricket.engine.MatchConfig
import com.zarvimo.livecricket.engine.MatchFormat
import com.zarvimo.livecricket.engine.Player
import com.zarvimo.livecricket.engine.Side
import com.zarvimo.livecricket.engine.Team

const val SQUAD_SIZE = 11

/** Editable team data: always 11 player slots (blank slots become "Player n"). */
data class TeamInfo(
    val name: String,
    val countryCode: String?,
    val logoPath: String?,
    val players: List<String>,
    val captain: Int?,
    val keeper: Int?,
) {
    fun finalNames(): List<String> =
        List(SQUAD_SIZE) { i -> players.getOrNull(i)?.trim()?.takeIf { it.isNotEmpty() } ?: "Player ${i + 1}" }

    fun toTeam(): Team = Team(
        name.ifBlank { "Team" },
        finalNames().mapIndexed { i, n -> Player(i + 1, n) },
    )

    companion object {
        fun blank() = TeamInfo("", null, null, List(SQUAD_SIZE) { "" }, null, null)
    }
}

data class SetupDraft(
    val title: String = "",
    val venue: String = "",
    val date: String = todayString(),
    val format: MatchFormat = MatchFormat.T20,
    val overs: String = "20",
    val teamA: TeamInfo = TeamInfo.blank(),
    val teamB: TeamInfo = TeamInfo.blank(),
    val battingFirst: Side = Side.A,
) {
    val oversEditable: Boolean get() = format != MatchFormat.TEST && format != MatchFormat.THE_HUNDRED

    fun config(): MatchConfig? = runCatching {
        MatchConfig.forFormat(format, if (oversEditable) overs.toIntOrNull() else null)
    }.getOrNull()
}

data class SavedMatch(
    val id: String,
    val title: String,
    val venue: String,
    val date: String,
    val format: MatchFormat,
    val overs: Int?,
    val teamA: TeamInfo,
    val teamB: TeamInfo,
    val battingFirst: Side,
    val innings: List<List<Action>>,
    val manualResult: String?,
    val updatedAt: Long,
) {
    /** Rebuilds the live match by replaying every stored action. */
    fun toMatch(): CricketMatch {
        var m = CricketMatch.create(MatchConfig.forFormat(format, overs), teamA.toTeam(), teamB.toTeam(), battingFirst)
        for (acts in innings) {
            m = m.startNextInnings()
            var inn = m.current!!
            for (a in acts) inn = inn.perform(a)
            m = m.updateCurrent(inn)
        }
        manualResult?.let { m = m.withManualResult(it) }
        return m
    }
}

fun todayString(): String = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.US).format(java.util.Date())
