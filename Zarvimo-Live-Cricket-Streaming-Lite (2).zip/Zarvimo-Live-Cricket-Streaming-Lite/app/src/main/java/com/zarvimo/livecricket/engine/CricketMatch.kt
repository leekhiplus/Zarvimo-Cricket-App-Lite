package com.zarvimo.livecricket.engine

import kotlin.math.max

data class MatchResult(val winner: Side?, val text: String)

/**
 * Multi-innings match: 2 innings for limited overs, 4 for Test (no follow-on).
 * Batting order alternates. The chasing target is computed when an innings starts.
 */
class CricketMatch private constructor(
    val config: MatchConfig,
    val teamA: Team,
    val teamB: Team,
    val battingFirst: Side,
    val innings: List<Innings>,
    val manualResult: String?,
) {
    companion object {
        fun create(config: MatchConfig, teamA: Team, teamB: Team, battingFirst: Side = Side.A) =
            CricketMatch(config, teamA, teamB, battingFirst, emptyList(), null)
    }

    fun team(side: Side): Team = if (side == Side.A) teamA else teamB

    fun battingSide(inningsIndex: Int): Side = if (inningsIndex % 2 == 0) battingFirst else battingFirst.other()

    val current: Innings? get() = innings.lastOrNull()

    /** Target for innings [i] (0-based); requires earlier innings to exist. Null when there is no chase. */
    fun targetFor(i: Int): Int? = when {
        config.maxInnings == 2 && i == 1 -> innings[0].state.runs + 1
        config.maxInnings == 4 && i == 3 ->
            max(1, innings[0].state.runs + innings[2].state.runs - innings[1].state.runs + 1)
        else -> null
    }

    fun startNextInnings(): CricketMatch {
        require(result == null) { "The match is already finished" }
        val cur = current
        require(cur == null || cur.status != InningsStatus.IN_PROGRESS) { "The current innings is still in progress" }
        require(innings.size < config.maxInnings) { "All innings have been played" }
        val i = innings.size
        val bat = battingSide(i)
        val next = Innings.start(config, team(bat), team(bat.other()), if (i == 0) null else targetFor(i))
        return CricketMatch(config, teamA, teamB, battingFirst, innings + next, manualResult)
    }

    fun updateCurrent(updated: Innings): CricketMatch {
        require(innings.isNotEmpty()) { "No innings in progress" }
        return CricketMatch(config, teamA, teamB, battingFirst, innings.dropLast(1) + updated, manualResult)
    }

    /** For outcomes the engine cannot know, such as a Test draw. */
    fun withManualResult(text: String) = CricketMatch(config, teamA, teamB, battingFirst, innings, text)

    val result: MatchResult?
        get() {
            manualResult?.let { return MatchResult(null, it) }
            val last = innings.lastOrNull() ?: return null
            val idx = innings.size - 1
            if (last.status == InningsStatus.IN_PROGRESS || idx != config.maxInnings - 1) return null
            val target = last.target ?: return null
            val chaser = battingSide(idx)
            val other = chaser.other()
            val runs = last.state.runs
            return when {
                runs >= target -> {
                    val w = last.maxWickets - last.state.wickets
                    MatchResult(chaser, "${team(chaser).name} won by $w wicket${if (w == 1) "" else "s"}")
                }
                runs == target - 1 -> MatchResult(null, "Match tied")
                else -> {
                    val margin = target - 1 - runs
                    MatchResult(other, "${team(other).name} won by $margin run${if (margin == 1) "" else "s"}")
                }
            }
        }
}
