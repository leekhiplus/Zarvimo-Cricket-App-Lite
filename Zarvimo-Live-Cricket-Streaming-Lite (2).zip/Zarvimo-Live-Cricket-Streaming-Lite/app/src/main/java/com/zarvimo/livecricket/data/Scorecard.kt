package com.zarvimo.livecricket.data

import com.zarvimo.livecricket.engine.CricketMatch
import com.zarvimo.livecricket.engine.Innings

object Scorecard {
    private fun overs(balls: Int, perOver: Int) = "${balls / perOver}.${balls % perOver}"

    fun inningsLine(inn: Innings): String =
        "${inn.battingTeam.name} ${inn.state.runs}/${inn.state.wickets} (${inn.oversText})"

    fun summary(m: CricketMatch): String = m.innings.joinToString("  |  ") { inningsLine(it) }

    fun statusText(m: CricketMatch): String = m.result?.text ?: "In progress"

    /** Plain-text scorecard for export/share. */
    fun text(meta: SavedMatch, m: CricketMatch): String = buildString {
        appendLine(meta.title)
        appendLine("${m.teamA.name} vs ${m.teamB.name}  (${meta.format.label})")
        if (meta.venue.isNotBlank()) appendLine("Venue: ${meta.venue}")
        if (meta.date.isNotBlank()) appendLine("Date: ${meta.date}")
        appendLine("Result: ${statusText(m)}")
        m.innings.forEachIndexed { idx, inn ->
            appendLine()
            appendLine("Innings ${idx + 1}: ${inningsLine(inn)}")
            val bat = inn.battingTeam
            val bowl = inn.bowlingTeam
            inn.state.batters.forEach { (id, st) ->
                val name = bat.players.firstOrNull { it.id == id }?.name ?: "?"
                val how = st.dismissal?.label ?: "not out"
                appendLine("  $name  $how  ${st.runs} (${st.balls})  4s:${st.fours} 6s:${st.sixes}")
            }
            val e = inn.state.extras
            appendLine("  Extras: ${e.total} (wd ${e.wides}, nb ${e.noBalls}, b ${e.byes}, lb ${e.legByes}, pen ${e.penalty})")
            if (inn.state.fall.isNotEmpty()) {
                appendLine("  Fall of wickets: " + inn.state.fall.joinToString(", ") { f ->
                    val n = bat.players.firstOrNull { it.id == f.batterId }?.name ?: "?"
                    "${f.wicketNumber}-${f.score} ($n)"
                })
            }
            inn.state.bowlers.forEach { (id, b) ->
                val name = bowl.players.firstOrNull { it.id == id }?.name ?: "?"
                appendLine("  $name  ${overs(b.legalBalls, inn.config.ballsPerOver)} ov  ${b.runs} runs  ${b.wickets} wkts")
            }
        }
    }
}
