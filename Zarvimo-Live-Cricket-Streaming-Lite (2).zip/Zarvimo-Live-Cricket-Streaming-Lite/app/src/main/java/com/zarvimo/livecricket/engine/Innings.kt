package com.zarvimo.livecricket.engine

import kotlin.math.max
import kotlin.math.min

data class BatterStat(
    val runs: Int = 0,
    val balls: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0,
    val dismissal: WicketType? = null,
    val dismissedByBowler: Int? = null,
) {
    val isOut: Boolean get() = dismissal != null
    val strikeRate: Double get() = if (balls == 0) 0.0 else runs * 100.0 / balls
}

data class BowlerStat(
    val legalBalls: Int = 0,
    val runs: Int = 0,
    val wickets: Int = 0,
    val wides: Int = 0,
    val noBalls: Int = 0,
)

data class Extras(
    val wides: Int = 0,
    val noBalls: Int = 0,
    val byes: Int = 0,
    val legByes: Int = 0,
    val penalty: Int = 0,
) {
    val total: Int get() = wides + noBalls + byes + legByes + penalty
}

data class FallOfWicket(
    val wicketNumber: Int,
    val score: Int,
    val legalBalls: Int,
    val batterId: Int,
    val type: WicketType,
)

data class BallRecord(
    val index: Int,
    val overIndex: Int,
    val delivery: Delivery,
    val strikerId: Int?,
    val nonStrikerId: Int?,
    val bowlerId: Int?,
    val runsAdded: Int,
    val legal: Boolean,
    val label: String,
)

data class InningsState(
    val runs: Int = 0,
    val wickets: Int = 0,
    val legalBalls: Int = 0,
    val extras: Extras = Extras(),
    val striker: Int? = null,
    val nonStriker: Int? = null,
    val bowler: Int? = null,
    val lastOverBowler: Int? = null,
    val batters: Map<Int, BatterStat> = emptyMap(),
    val bowlers: Map<Int, BowlerStat> = emptyMap(),
    val fall: List<FallOfWicket> = emptyList(),
    val balls: List<BallRecord> = emptyList(),
    val partnershipRuns: Int = 0,
    val partnershipBalls: Int = 0,
    val declared: Boolean = false,
)

enum class InningsStatus { IN_PROGRESS, ALL_OUT, OVERS_COMPLETE, TARGET_ACHIEVED, DECLARED }

data class ChaseInfo(
    val target: Int,
    val runsNeeded: Int,
    val ballsRemaining: Int?,
    val requiredRate: Double?,
)

/**
 * One innings, built by replaying an immutable list of [Action]s. Because the state is
 * always derived from the action list, undo and editing a previous delivery are a replay.
 * All methods return a new Innings and throw IllegalArgumentException on illegal input.
 */
class Innings private constructor(
    val config: MatchConfig,
    val battingTeam: Team,
    val bowlingTeam: Team,
    val target: Int?,
    val actions: List<Action>,
    val state: InningsState,
) {
    companion object {
        fun start(config: MatchConfig, battingTeam: Team, bowlingTeam: Team, target: Int? = null): Innings =
            Innings(config, battingTeam, bowlingTeam, target, emptyList(), InningsState())

        private val NO_BALL_WICKETS = setOf(
            WicketType.RUN_OUT, WicketType.HANDLED_BALL, WicketType.OBSTRUCTING_FIELD, WicketType.HIT_BALL_TWICE,
        )
        private val WIDE_WICKETS = setOf(
            WicketType.RUN_OUT, WicketType.STUMPED, WicketType.HIT_WICKET, WicketType.OBSTRUCTING_FIELD,
        )
    }

    val maxWickets: Int get() = min(config.maxWicketsToEnd, battingTeam.players.size - 1)

    val status: InningsStatus
        get() = when {
            target != null && state.runs >= target -> InningsStatus.TARGET_ACHIEVED
            state.declared -> InningsStatus.DECLARED
            state.wickets >= maxWickets -> InningsStatus.ALL_OUT
            config.ballsPerInnings != null && state.legalBalls >= config.ballsPerInnings -> InningsStatus.OVERS_COMPLETE
            else -> InningsStatus.IN_PROGRESS
        }

    val oversCompleted: Int get() = state.legalBalls / config.ballsPerOver
    val ballsInCurrentOver: Int get() = state.legalBalls % config.ballsPerOver
    val oversText: String get() = "$oversCompleted.$ballsInCurrentOver"

    val currentRunRate: Double
        get() = if (state.legalBalls == 0) 0.0 else state.runs * 6.0 / state.legalBalls

    /** Labels of the last six recorded deliveries (illegal ones included; penalty and dead balls excluded). */
    val lastSix: List<String>
        get() = state.balls
            .filter { it.delivery.type != DeliveryType.PENALTY && it.delivery.type != DeliveryType.DEAD }
            .takeLast(6)
            .map { it.label }

    val chase: ChaseInfo?
        get() {
            val t = target ?: return null
            val need = max(0, t - state.runs)
            val remaining = config.ballsPerInnings?.let { max(0, it - state.legalBalls) }
            val rate = if (remaining != null && remaining > 0) need * 6.0 / remaining else null
            return ChaseInfo(t, need, remaining, rate)
        }

    fun perform(action: Action): Innings {
        require(status == InningsStatus.IN_PROGRESS) { "This innings is already complete" }
        return Innings(config, battingTeam, bowlingTeam, target, actions + action, reduce(action))
    }

    /** Removes the last delivery and every action after it. */
    fun undoLastBall(): Innings {
        val idx = actions.indexOfLast { it is Action.Ball }
        require(idx >= 0) { "No delivery to undo" }
        return replay(actions.subList(0, idx))
    }

    /** Replaces the [ballNumber]-th delivery (0-based) and replays everything after it. */
    fun editBall(ballNumber: Int, newDelivery: Delivery): Innings {
        var seen = -1
        val edited = actions.map { a ->
            if (a is Action.Ball) {
                seen++
                if (seen == ballNumber) Action.Ball(newDelivery) else a
            } else a
        }
        require(ballNumber in 0..seen) { "No such delivery" }
        return replay(edited)
    }

    private fun replay(list: List<Action>): Innings {
        var inn = start(config, battingTeam, bowlingTeam, target)
        for (a in list) inn = inn.perform(a)
        return inn
    }

    private fun reduce(a: Action): InningsState {
        val s = state
        return when (a) {
            is Action.Ball -> ball(s, a.delivery)
            is Action.SetBowler -> {
                require(bowlingTeam.hasPlayer(a.playerId)) { "Bowler is not in the bowling team" }
                require(config.allowConsecutiveOvers || s.lastOverBowler != a.playerId) {
                    "The same bowler cannot bowl consecutive overs"
                }
                s.copy(bowler = a.playerId, bowlers = s.bowlers + (a.playerId to (s.bowlers[a.playerId] ?: BowlerStat())))
            }
            is Action.SetBatter -> {
                require(battingTeam.hasPlayer(a.playerId)) { "Batter is not in the batting team" }
                val existing = s.batters[a.playerId]
                require(existing?.isOut != true) { "Batter is already out" }
                val current = if (a.slot == Slot.STRIKER) s.striker else s.nonStriker
                val other = if (a.slot == Slot.STRIKER) s.nonStriker else s.striker
                require(current == null) { "That crease slot is not vacant" }
                require(other != a.playerId) { "Batter is already at the other end" }
                val nb = s.batters + (a.playerId to (existing ?: BatterStat()))
                if (a.slot == Slot.STRIKER) s.copy(striker = a.playerId, batters = nb)
                else s.copy(nonStriker = a.playerId, batters = nb)
            }
            Action.SwapStrike -> s.copy(striker = s.nonStriker, nonStriker = s.striker)
            is Action.RetireOut -> {
                require(a.playerId == s.striker || a.playerId == s.nonStriker) { "Batter is not at the crease" }
                val wickets = s.wickets + 1
                s.copy(
                    wickets = wickets,
                    striker = if (s.striker == a.playerId) null else s.striker,
                    nonStriker = if (s.nonStriker == a.playerId) null else s.nonStriker,
                    batters = s.batters + (a.playerId to (s.batters[a.playerId] ?: BatterStat())
                        .copy(dismissal = WicketType.RETIRED_OUT)),
                    fall = s.fall + FallOfWicket(wickets, s.runs, s.legalBalls, a.playerId, WicketType.RETIRED_OUT),
                    partnershipRuns = 0,
                    partnershipBalls = 0,
                )
            }
            Action.Declare -> {
                require(config.maxInnings == 4) { "Declarations only apply to Test matches" }
                s.copy(declared = true)
            }
        }
    }

    private fun record(s: InningsState, d: Delivery, overIndex: Int, added: Int, legal: Boolean) = BallRecord(
        index = s.balls.size, overIndex = overIndex, delivery = d,
        strikerId = s.striker, nonStrikerId = s.nonStriker, bowlerId = s.bowler,
        runsAdded = added, legal = legal, label = d.label,
    )

    private fun ball(s: InningsState, d: Delivery): InningsState {
        require(d.runs in 0..9) { "Runs must be between 0 and 9" }
        val overIndex = s.legalBalls / config.ballsPerOver

        if (d.type == DeliveryType.DEAD) {
            require(d.runs == 0 && d.wicket == null && d.dismissed == null) { "A dead ball has no runs or wicket" }
            return s.copy(balls = s.balls + record(s, d, overIndex, 0, false))
        }
        if (d.type == DeliveryType.PENALTY) {
            require(d.runs > 0 && d.wicket == null && d.dismissed == null) { "Penalty needs runs and no wicket" }
            return s.copy(
                runs = s.runs + d.runs,
                extras = s.extras.copy(penalty = s.extras.penalty + d.runs),
                balls = s.balls + record(s, d, overIndex, d.runs, false),
            )
        }

        val striker = requireNotNull(s.striker) { "Select the striker first" }
        val nonStriker = requireNotNull(s.nonStriker) { "Select the non-striker first" }
        val bowler = requireNotNull(s.bowler) { "Select the bowler first" }

        val w = d.wicket
        if (w == null) {
            require(d.dismissed == null) { "Dismissed batter given without a wicket" }
        } else {
            require(w != WicketType.RETIRED_OUT) { "Use RetireOut for retired batters" }
            when (d.type) {
                DeliveryType.NO_BALL -> require(w in NO_BALL_WICKETS) { "${w.label} is not possible off a no ball" }
                DeliveryType.WIDE -> require(w in WIDE_WICKETS) { "${w.label} is not possible off a wide" }
                else -> {}
            }
            val who = d.dismissed ?: striker
            require(who == striker || (who == nonStriker && w == WicketType.RUN_OUT)) { "Invalid dismissed batter" }
        }

        val legal = d.type.isLegal
        val added = when (d.type) {
            DeliveryType.WIDE, DeliveryType.NO_BALL -> 1 + d.runs
            else -> d.runs
        }
        val offBat = d.type == DeliveryType.NORMAL || d.type == DeliveryType.NO_BALL

        val extras = when (d.type) {
            DeliveryType.WIDE -> s.extras.copy(wides = s.extras.wides + 1 + d.runs)
            DeliveryType.NO_BALL -> s.extras.copy(noBalls = s.extras.noBalls + 1)
            DeliveryType.BYE -> s.extras.copy(byes = s.extras.byes + d.runs)
            DeliveryType.LEG_BYE -> s.extras.copy(legByes = s.extras.legByes + d.runs)
            else -> s.extras
        }

        val sb = s.batters[striker] ?: BatterStat()
        val newSb = sb.copy(
            runs = sb.runs + if (offBat) d.runs else 0,
            balls = sb.balls + if (d.type != DeliveryType.WIDE) 1 else 0,
            fours = sb.fours + if (offBat && d.runs == 4) 1 else 0,
            sixes = sb.sixes + if (offBat && d.runs == 6) 1 else 0,
        )
        var batters = s.batters + (striker to newSb)

        val bs = s.bowlers[bowler] ?: BowlerStat()
        val charged = when (d.type) {
            DeliveryType.NORMAL -> d.runs
            DeliveryType.WIDE, DeliveryType.NO_BALL -> 1 + d.runs
            else -> 0
        }
        var newBs = bs.copy(
            legalBalls = bs.legalBalls + if (legal) 1 else 0,
            runs = bs.runs + charged,
            wides = bs.wides + if (d.type == DeliveryType.WIDE) 1 else 0,
            noBalls = bs.noBalls + if (d.type == DeliveryType.NO_BALL) 1 else 0,
        )

        val newLegal = s.legalBalls + if (legal) 1 else 0
        val score = s.runs + added
        var wickets = s.wickets
        var fall = s.fall
        var pRuns = s.partnershipRuns + added
        var pBalls = s.partnershipBalls + if (legal) 1 else 0
        var dismissedId: Int? = null

        if (w != null) {
            val who = d.dismissed ?: striker
            dismissedId = who
            wickets += 1
            batters = batters + (who to (batters[who] ?: BatterStat())
                .copy(dismissal = w, dismissedByBowler = if (w.bowlerCredited) bowler else null))
            if (w.bowlerCredited) newBs = newBs.copy(wickets = newBs.wickets + 1)
            fall = fall + FallOfWicket(wickets, score, newLegal, who, w)
            pRuns = 0
            pBalls = 0
        }

        // Positions: runs rotate first, then the dismissed batter leaves, then end-of-over changes.
        var st: Int? = striker
        var ns: Int? = nonStriker
        if (d.runs % 2 == 1) { st = nonStriker; ns = striker }
        if (dismissedId != null) {
            if (st == dismissedId) st = null else if (ns == dismissedId) ns = null
        }
        var bowlerNext: Int? = bowler
        var lastOver = s.lastOverBowler
        if (legal && newLegal % config.endChangeBalls == 0) { val t = st; st = ns; ns = t }
        if (legal && newLegal % config.ballsPerOver == 0) { lastOver = bowler; bowlerNext = null }

        return s.copy(
            runs = score,
            wickets = wickets,
            legalBalls = newLegal,
            extras = extras,
            striker = st,
            nonStriker = ns,
            bowler = bowlerNext,
            lastOverBowler = lastOver,
            batters = batters,
            bowlers = s.bowlers + (bowler to newBs),
            fall = fall,
            balls = s.balls + record(s, d, overIndex, added, legal),
            partnershipRuns = pRuns,
            partnershipBalls = pBalls,
        )
    }
}
