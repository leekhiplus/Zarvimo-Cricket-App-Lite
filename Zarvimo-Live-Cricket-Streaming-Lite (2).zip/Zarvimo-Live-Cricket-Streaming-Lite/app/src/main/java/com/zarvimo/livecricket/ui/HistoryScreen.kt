package com.zarvimo.livecricket.ui

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zarvimo.livecricket.AppViewModel
import com.zarvimo.livecricket.data.Scorecard

@Composable
fun HistoryScreen(vm: AppViewModel, onBack: () -> Unit, onOpen: () -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.refreshHistory() }
    var deleteId by remember { mutableStateOf<String?>(null) }

    ScreenScaffold("Match History", onBack, scroll = false) {
        if (vm.history.isEmpty()) Text("No saved matches yet.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(vm.history, key = { it.id }) { sm ->
                val m = remember(sm.id, sm.updatedAt) { runCatching { sm.toMatch() }.getOrNull() }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TeamBadge(sm.teamA.countryCode, sm.teamA.logoPath, 24.dp, fallback = sm.teamA.name)
                            Spacer(Modifier.width(8.dp))
                            TeamBadge(sm.teamB.countryCode, sm.teamB.logoPath, 24.dp, fallback = sm.teamB.name)
                            Spacer(Modifier.width(12.dp))
                            Text(sm.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        }
                        Text("${sm.teamA.name} vs ${sm.teamB.name}  \u2022  ${sm.format.label}")
                        if (m != null) {
                            Text(Scorecard.summary(m))
                            Text(Scorecard.statusText(m), color = MaterialTheme.colorScheme.primary)
                        } else {
                            Text("This saved match could not be read.")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { vm.open(sm); onOpen() }, enabled = m != null) {
                                Text(if (m?.result == null) "Resume" else "Open")
                            }
                            OutlinedButton(
                                enabled = m != null,
                                onClick = {
                                    if (m != null) {
                                        val intent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_SUBJECT, sm.title)
                                            putExtra(Intent.EXTRA_TEXT, Scorecard.text(sm, m))
                                        }
                                        ctx.startActivity(Intent.createChooser(intent, "Export scorecard"))
                                    }
                                },
                            ) { Text("Export") }
                            TextButton(onClick = { deleteId = sm.id }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }

    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null },
            title = { Text("Delete match?") },
            text = { Text("This permanently removes the saved match from this phone.") },
            confirmButton = { TextButton(onClick = { vm.deleteMatch(id); deleteId = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancel") } },
        )
    }
}
