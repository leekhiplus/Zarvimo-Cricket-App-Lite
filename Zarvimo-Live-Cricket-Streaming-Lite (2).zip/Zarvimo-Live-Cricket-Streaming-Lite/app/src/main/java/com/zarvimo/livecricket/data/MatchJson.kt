package com.zarvimo.livecricket.data

import com.zarvimo.livecricket.engine.Action
import com.zarvimo.livecricket.engine.Delivery
import com.zarvimo.livecricket.engine.DeliveryType
import com.zarvimo.livecricket.engine.MatchFormat
import com.zarvimo.livecricket.engine.Side
import com.zarvimo.livecricket.engine.Slot
import com.zarvimo.livecricket.engine.WicketType
import org.json.JSONArray
import org.json.JSONObject

object MatchJson {
    fun actionToJson(a: Action): JSONObject {
        val o = JSONObject()
        when (a) {
            is Action.Ball -> {
                o.put("t", "ball")
                o.put("type", a.delivery.type.name)
                o.put("runs", a.delivery.runs)
                a.delivery.wicket?.let { o.put("w", it.name) }
                a.delivery.dismissed?.let { o.put("d", it) }
            }
            is Action.SetBowler -> { o.put("t", "bowler"); o.put("id", a.playerId) }
            is Action.SetBatter -> { o.put("t", "batter"); o.put("id", a.playerId); o.put("slot", a.slot.name) }
            Action.SwapStrike -> o.put("t", "swap")
            is Action.RetireOut -> { o.put("t", "retire"); o.put("id", a.playerId) }
            Action.Declare -> o.put("t", "declare")
        }
        return o
    }

    fun actionFromJson(o: JSONObject): Action = when (val t = o.getString("t")) {
        "ball" -> Action.Ball(
            Delivery(
                DeliveryType.valueOf(o.getString("type")),
                o.getInt("runs"),
                if (o.has("w")) WicketType.valueOf(o.getString("w")) else null,
                if (o.has("d")) o.getInt("d") else null,
            ),
        )
        "bowler" -> Action.SetBowler(o.getInt("id"))
        "batter" -> Action.SetBatter(o.getInt("id"), Slot.valueOf(o.getString("slot")))
        "swap" -> Action.SwapStrike
        "retire" -> Action.RetireOut(o.getInt("id"))
        "declare" -> Action.Declare
        else -> throw IllegalArgumentException("Unknown action type: $t")
    }

    fun teamToJson(t: TeamInfo): JSONObject = JSONObject().apply {
        put("name", t.name)
        t.countryCode?.let { put("code", it) }
        t.logoPath?.let { put("logo", it) }
        put("players", JSONArray(t.players))
        t.captain?.let { put("captain", it) }
        t.keeper?.let { put("keeper", it) }
    }

    fun teamFromJson(o: JSONObject): TeamInfo {
        val arr = o.getJSONArray("players")
        return TeamInfo(
            name = o.getString("name"),
            countryCode = if (o.has("code")) o.getString("code") else null,
            logoPath = if (o.has("logo")) o.getString("logo") else null,
            players = List(arr.length()) { arr.getString(it) },
            captain = if (o.has("captain")) o.getInt("captain") else null,
            keeper = if (o.has("keeper")) o.getInt("keeper") else null,
        )
    }

    fun toJson(m: SavedMatch): String = JSONObject().apply {
        put("id", m.id)
        put("title", m.title)
        put("venue", m.venue)
        put("date", m.date)
        put("format", m.format.name)
        m.overs?.let { put("overs", it) }
        put("teamA", teamToJson(m.teamA))
        put("teamB", teamToJson(m.teamB))
        put("battingFirst", m.battingFirst.name)
        put("innings", JSONArray().also { all ->
            m.innings.forEach { acts -> all.put(JSONArray().also { arr -> acts.forEach { arr.put(actionToJson(it)) } }) }
        })
        m.manualResult?.let { put("manualResult", it) }
        put("updatedAt", m.updatedAt)
    }.toString()

    fun fromJson(text: String): SavedMatch {
        val o = JSONObject(text)
        val inningsArr = o.getJSONArray("innings")
        return SavedMatch(
            id = o.getString("id"),
            title = o.getString("title"),
            venue = o.optString("venue", ""),
            date = o.optString("date", ""),
            format = MatchFormat.valueOf(o.getString("format")),
            overs = if (o.has("overs")) o.getInt("overs") else null,
            teamA = teamFromJson(o.getJSONObject("teamA")),
            teamB = teamFromJson(o.getJSONObject("teamB")),
            battingFirst = Side.valueOf(o.getString("battingFirst")),
            innings = List(inningsArr.length()) { i ->
                val arr = inningsArr.getJSONArray(i)
                List(arr.length()) { j -> actionFromJson(arr.getJSONObject(j)) }
            },
            manualResult = if (o.has("manualResult")) o.getString("manualResult") else null,
            updatedAt = o.getLong("updatedAt"),
        )
    }
}
