package com.zarvimo.livecricket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Tile(val title: String, val icon: String, val top: Color, val bottom: Color, val target: Screen?)

private val tiles = listOf(
    Tile("Create\nNew Match", "\u2795", Color(0xFF3B7BFF), Color(0xFF1B3FBF), Screen.SETUP),
    Tile("Live\nScoring", "\uD83E\uDDEE", Color(0xFF3DBE4B), Color(0xFF1E8A32), Screen.SCORING),
    Tile("Templates", "\uD83C\uDFA8", Color(0xFF9A4DEB), Color(0xFF5B25B5), Screen.TEMPLATES),
    Tile("Background", "\uD83D\uDDBC\uFE0F", Color(0xFFFFA726), Color(0xFFE06A00), Screen.BACKGROUND),
    Tile("Channel\nLogo", "\uD83C\uDFF7\uFE0F", Color(0xFF26A69A), Color(0xFF00695C), Screen.LOGO),
    Tile("Audio\nStudio", "\uD83C\uDFB5", Color(0xFF2AA7C9), Color(0xFF1C6E96), Screen.AUDIO),
    Tile("Live\nPreview", "\uD83D\uDCFA", Color(0xFF3B8BFF), Color(0xFF1B49C9), Screen.PREVIEW),
    Tile("YouTube\nStreaming", "\uD83D\uDCE1", Color(0xFFE53935), Color(0xFFA81C1C), Screen.STREAM),
    Tile("Match\nHistory", "\uD83D\uDD58", Color(0xFF3DBE4B), Color(0xFF1E8A32), Screen.HISTORY),
    Tile("App\nSettings", "\u2699\uFE0F", Color(0xFF5C6BC0), Color(0xFF303F9F), Screen.SETTINGS),
)

@Composable
fun HomeScreen(onNavigate: (Screen) -> Unit) {
    var notice by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            ZarvimoLogo(Modifier.weight(1f))
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Color(0x332F8CFF))
                    .border(1.dp, Color(0x663B82F6), CircleShape).clickable { onNavigate(Screen.SETTINGS) },
                contentAlignment = Alignment.Center,
            ) { Text("\u2699\uFE0F", fontSize = 22.sp) }
        }
        Spacer(Modifier.height(4.dp))
        tiles.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { tile ->
                    GradientTile(
                        tile.title, tile.icon, tile.top, tile.bottom,
                        Modifier.weight(1f).height(124.dp),
                    ) { if (tile.target != null) onNavigate(tile.target) else notice = tile.title.replace("\n", " ") }
                }
            }
        }
    }

    notice?.let { title ->
        AlertDialog(
            onDismissRequest = { notice = null },
            confirmButton = { TextButton(onClick = { notice = null }) { Text("OK") } },
            title = { Text(title) },
            text = { Text("Background, logo and audio are built in the next stage.") },
        )
    }
}
