package com.zarvimo.livecricket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.livecricket.AppViewModel
import com.zarvimo.livecricket.data.SQUAD_SIZE
import com.zarvimo.livecricket.data.TeamInfo
import com.zarvimo.livecricket.engine.Side

private fun teamOf(vm: AppViewModel, side: Side): TeamInfo = if (side == Side.A) vm.draft.teamA else vm.draft.teamB

@Composable
private fun XiColumn(vm: AppViewModel, side: Side, active: Boolean, modifier: Modifier, onSelect: () -> Unit, onEdit: (Int) -> Unit) {
    val t = teamOf(vm, side)
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.clip(shape).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
            .border(if (active) 2.dp else 1.dp, if (active) Palette.Blue else Color(0x443B82F6), shape),
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onSelect).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TeamBadge(t.countryCode, t.logoPath, 26.dp, fallback = t.name)
            Text(t.name.ifBlank { if (side == Side.A) "Team A" else "Team B" }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        for (i in 0 until SQUAD_SIZE) {
            val raw = t.players.getOrElse(i) { "" }.trim()
            val tags = listOfNotNull(if (t.captain == i) "C" else null, if (t.keeper == i) "WK" else null)
            val label = (if (raw.isEmpty()) "Player ${i + 1}" else raw) + if (tags.isEmpty()) "" else " (${tags.joinToString(", ")})"
            Text(
                "${i + 1}  $label",
                modifier = Modifier.fillMaxWidth().clickable { onEdit(i) }.padding(horizontal = 10.dp, vertical = 7.dp),
                fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (raw.isEmpty()) Color(0xFF8A99BD) else MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
fun XiScreen(vm: AppViewModel, onBack: () -> Unit, onStart: () -> Unit) {
    var active by remember { mutableStateOf(Side.A) }
    var editIdx by remember { mutableStateOf<Int?>(null) }
    var showPaste by remember { mutableStateOf(false) }
    var showLoad by remember { mutableStateOf(false) }

    ScreenScaffold("Playing XI", onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            XiColumn(vm, Side.A, active == Side.A, Modifier.weight(1f), { active = Side.A }) { i -> active = Side.A; editIdx = i }
            XiColumn(vm, Side.B, active == Side.B, Modifier.weight(1f), { active = Side.B }) { i -> active = Side.B; editIdx = i }
        }
        Text(
            "Tap a team name to select it, then use the buttons. Tap a player to edit, set captain or wicketkeeper.",
            fontSize = 12.sp,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showPaste = true }) { Text("Paste names") }
            OutlinedButton(onClick = { showLoad = true }) { Text("Saved teams") }
            OutlinedButton(onClick = { vm.saveTeam(teamOf(vm, active)) }) { Text("Save team") }
        }
        PrimaryButton("Start Match \u2192", Palette.Green) { if (vm.startMatch()) onStart() }
    }

    editIdx?.let { i -> PlayerEditDialog(vm, active, i) { editIdx = null } }

    if (showPaste) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPaste = false },
            title = { Text("Paste player names") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text("One per line or comma separated") },
                    modifier = Modifier.fillMaxWidth(), minLines = 6,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val names = text.split(Regex("[\\n,;]+")).map { it.trim() }.filter { it.isNotEmpty() }.take(SQUAD_SIZE)
                    vm.updateTeam(active) { tm -> tm.copy(players = List(SQUAD_SIZE) { names.getOrElse(it) { "" } }) }
                    showPaste = false
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { showPaste = false }) { Text("Cancel") } },
        )
    }

    if (showLoad) {
        AlertDialog(
            onDismissRequest = { showLoad = false },
            title = { Text("Saved teams") },
            text = {
                Column {
                    if (vm.savedTeams.isEmpty()) Text("No saved teams yet.")
                    vm.savedTeams.forEach { st ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { vm.updateTeam(active) { st.copy() }; showLoad = false }, modifier = Modifier.weight(1f)) {
                                Text(st.name, modifier = Modifier.fillMaxWidth())
                            }
                            TextButton(onClick = { vm.deleteSavedTeam(st.name) }) { Text("Delete") }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showLoad = false }) { Text("Close") } },
        )
    }
}

@Composable
private fun PlayerEditDialog(vm: AppViewModel, side: Side, i: Int, onDismiss: () -> Unit) {
    val t = teamOf(vm, side)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Player ${i + 1}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = t.players.getOrElse(i) { "" },
                    onValueChange = { v -> vm.updateTeam(side) { tm -> tm.copy(players = tm.players.toMutableList().also { it[i] = v }) } },
                    label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Captain", Modifier.weight(1f))
                    Switch(checked = t.captain == i, onCheckedChange = { on -> vm.updateTeam(side) { tm -> tm.copy(captain = if (on) i else null) } })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Wicketkeeper", Modifier.weight(1f))
                    Switch(checked = t.keeper == i, onCheckedChange = { on -> vm.updateTeam(side) { tm -> tm.copy(keeper = if (on) i else null) } })
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
        dismissButton = {
            TextButton(onClick = {
                vm.updateTeam(side) { tm ->
                    tm.copy(
                        players = tm.players.toMutableList().also { it[i] = "" },
                        captain = if (tm.captain == i) null else tm.captain,
                        keeper = if (tm.keeper == i) null else tm.keeper,
                    )
                }
                onDismiss()
            }) { Text("Remove") }
        },
    )
}
