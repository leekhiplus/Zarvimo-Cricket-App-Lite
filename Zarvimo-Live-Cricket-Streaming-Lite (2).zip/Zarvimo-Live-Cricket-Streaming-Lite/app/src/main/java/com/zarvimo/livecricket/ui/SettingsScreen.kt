package com.zarvimo.livecricket.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zarvimo.livecricket.AppViewModel
import com.zarvimo.livecricket.stream.StreamProfiles

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val version = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) vm.backup(uri)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.restore(uri)
    }

    ScreenScaffold("Settings", onBack) {
        Text("Theme", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("system" to "System", "dark" to "Dark", "light" to "Light").forEach { (k, label) ->
                FilterChip(selected = vm.themeMode == k, onClick = { vm.setTheme(k) }, label = { Text(label) })
            }
        }
        Text("Default scoreboard template", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Templates.forEachIndexed { i, t ->
                FilterChip(selected = vm.templateIndex == i, onClick = { vm.selectTemplate(i) }, label = { Text(t.name) })
            }
        }
        Text("Default video orientation", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !vm.stream.portrait, onClick = { vm.updateStream { it.copy(portrait = false) } }, label = { Text("Landscape") })
            FilterChip(selected = vm.stream.portrait, onClick = { vm.updateStream { it.copy(portrait = true) } }, label = { Text("Portrait") })
        }
        Text("Default resolution", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StreamProfiles.all.forEach { p ->
                FilterChip(selected = vm.resolution == p.label, onClick = { vm.updateResolution(p.label) }, label = { Text(p.label) })
            }
        }
        Text("Audio, background and logo settings are in Audio Studio, Background and Channel Logo.", style = MaterialTheme.typography.bodySmall)

        Text("Local backup", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { backupLauncher.launch("zarvimo-backup.zip") }) { Text("Back up") }
            OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/zip", "application/octet-stream")) }) { Text("Restore") }
        }
        Text(
            "Backs up saved matches, saved teams and stream options. Images, music and the stream key are not included.",
            style = MaterialTheme.typography.bodySmall,
        )
        Text("Zarvimo Live Cricket Streaming Lite", style = MaterialTheme.typography.titleSmall)
        Text("Version $version")
    }
}
