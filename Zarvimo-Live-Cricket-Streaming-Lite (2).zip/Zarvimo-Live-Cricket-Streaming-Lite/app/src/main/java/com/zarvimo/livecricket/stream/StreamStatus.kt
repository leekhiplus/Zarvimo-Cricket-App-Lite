package com.zarvimo.livecricket.stream

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Observable streaming state shown on the YouTube Streaming screen. Written from engine threads. */
object StreamStatus {
    var state by mutableStateOf("Idle")
    var running by mutableStateOf(false)      // engine started (service up)
    var connected by mutableStateOf(false)    // RTMP session established
    var live by mutableStateOf(false)         // frames are being sent
    var error by mutableStateOf<String?>(null)
    var elapsedSec by mutableStateOf(0L)
    var bitrateKbps by mutableStateOf(0)
    var fps by mutableStateOf(0)
    var dropped by mutableStateOf(0)

    fun reset(newState: String = "Idle") {
        state = newState
        connected = false
        live = false
        error = null
        elapsedSec = 0
        bitrateKbps = 0
        fps = 0
        dropped = 0
    }
}
