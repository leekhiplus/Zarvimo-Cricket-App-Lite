package com.zarvimo.livecricket.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.zarvimo.livecricket.AppViewModel

private val IMAGE_TYPES = arrayOf("image/jpeg", "image/png", "image/webp")

@Composable
fun BackgroundScreen(vm: AppViewModel, onBack: () -> Unit) {
    var portrait by rememberSaveable { mutableStateOf(vm.stream.portrait) }
    val bg = if (portrait) vm.media.bgPortrait else vm.media.bgLandscape
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importBackground(uri, portrait)
    }

    ScreenScaffold("Background Settings", onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !portrait, onClick = { portrait = false }, label = { Text("Landscape") })
            FilterChip(selected = portrait, onClick = { portrait = true }, label = { Text("Portrait") })
        }
        BoardImage(
            vm, portrait, live = false,
            modifier = Modifier.then(if (portrait) Modifier.height(380.dp) else Modifier.fillMaxWidth()).clip(RoundedCornerShape(14.dp)),
        )

        Text("Style", fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("stadium" to "Stadium", "dark" to "Dark", "light" to "Light").forEach { (k, label) ->
                FilterChip(selected = bg.style == k, onClick = { vm.updateBg(portrait) { it.copy(style = k) } }, label = { Text(label) })
            }
            FilterChip(
                selected = bg.style == "custom",
                onClick = { if (bg.path != null) vm.updateBg(portrait) { it.copy(style = "custom") } else picker.launch(IMAGE_TYPES) },
                label = { Text("Custom image") },
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { picker.launch(IMAGE_TYPES) }) { Text(if (bg.path == null) "Choose image" else "Replace image") }
            if (bg.path != null) TextButton(onClick = { vm.removeBackground(portrait) }) { Text("Remove") }
        }

        if (bg.style == "custom" && bg.path != null) {
            Text("Fit", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = bg.fit == "crop", onClick = { vm.updateBg(portrait) { it.copy(fit = "crop") } }, label = { Text("Fill (crop)") })
                FilterChip(selected = bg.fit == "fit", onClick = { vm.updateBg(portrait) { it.copy(fit = "fit") } }, label = { Text("Fit whole image") })
            }
            Text("Zoom ${"%.1f".format(bg.zoom)}x")
            Slider(value = bg.zoom, onValueChange = { v -> vm.updateBg(portrait) { it.copy(zoom = v) } }, valueRange = 1f..3f)
            Text("Horizontal position")
            Slider(value = bg.offX, onValueChange = { v -> vm.updateBg(portrait) { it.copy(offX = v) } }, valueRange = -1f..1f)
            Text("Vertical position")
            Slider(value = bg.offY, onValueChange = { v -> vm.updateBg(portrait) { it.copy(offY = v) } }, valueRange = -1f..1f)
            TextButton(onClick = { vm.updateBg(portrait) { it.copy(zoom = 1f, offX = 0f, offY = 0f) } }) { Text("Reset zoom and position") }
        }
        Text(
            "Landscape and portrait have separate backgrounds. Supported: JPG, PNG, WebP.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
