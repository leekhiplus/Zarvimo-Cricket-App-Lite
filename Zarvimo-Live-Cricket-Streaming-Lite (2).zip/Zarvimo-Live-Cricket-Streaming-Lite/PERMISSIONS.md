# Android permissions

| Permission | Why | When |
|---|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | Send the live stream to YouTube (RTMP) and detect network loss | Only used while streaming. Scoring, flags, templates, history are fully offline |
| `RECORD_AUDIO` | Live voice commentary | Asked when you turn the microphone on or connect; optional (streaming works with music only) |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MICROPHONE`, `FOREGROUND_SERVICE_DATA_SYNC` | Keep streaming with the screen locked or the app minimised | While streaming. Type is `microphone` when the mic is allowed, else `dataSync` |
| `POST_NOTIFICATIONS` (Android 13+) | Show the "streaming" notification with a Stop button | Asked when you connect |
| `WAKE_LOCK` | Keep the CPU awake while streaming | While streaming |

No advertising, analytics or registration. Images and audio are chosen with the system file picker (no storage permission).
The stream key is encrypted with an Android Keystore key and never written to logs or error messages.
