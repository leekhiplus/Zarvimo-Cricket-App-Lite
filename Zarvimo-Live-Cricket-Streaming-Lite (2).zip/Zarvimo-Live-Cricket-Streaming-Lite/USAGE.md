# Quick usage guide

1. **Create New Match**: tap Team A / Team B to set name, flag (or custom logo); choose format and overs; Next.
2. **Playing XI** (optional): tap a player to edit, set captain/wicketkeeper; paste a list; save teams for reuse. Start Match.
3. **Live Scoring**: pick the striker, non-striker and bowler, then tap runs. Wide / No Ball / Bye / Leg Bye apply to the next run button. W opens the wicket dialog. More has penalty, dead ball, retire out, bowler change, pause and ball-by-ball edit. Undo removes the last ball.
4. **Templates / Live Preview**: pick one of 10 scoreboards; preview in landscape or portrait.
5. **Background / Channel Logo / Audio Studio**: set your picture, logo position/size/opacity, music, and microphone volume.
6. **YouTube Streaming**: paste the RTMP URL and your stream key from YouTube Studio, choose resolution, Connect, then Start Live. Press Go Live in YouTube Studio when its preview appears.
7. **Match History**: resume, export the scorecard as text, or delete.
